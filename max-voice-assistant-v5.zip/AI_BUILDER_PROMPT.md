# Prompt for the AI app builder (copy everything below the line)

---

You are building an Android APK from a complete, finished source project that I am giving you as a ZIP file (`max-voice-assistant-v5.zip`).
Do exactly this, in this order. Do not improvise, do not "improve", do not ask me questions: if something is unclear, choose the safest option
that keeps the existing behaviour, and tell me in the final report.

## 1. Replace the project
- DELETE the entire current project (every source, resource, Gradle and config file) and replace it with the contents of the ZIP, exactly as they are.
  The ZIP root contains `app/`, `gradle/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `CHANGES.md`, `README.md`.
- Do NOT merge with, rewrite, "modernise" or restructure the old code. Files that exist in the old project but not in the ZIP must be deleted.
  (The old project contained duplicate pipelines and files that have been removed on purpose: `capability/`, `ExecutionEngine`, `RiskEngine`, `VerificationEngine`.
   Do not recreate them.)
- Keep these values exactly: `namespace = "com.example"`, `applicationId = "com.aistudio.maxvoiceassistant.kxlpqa"`, minSdk 24, targetSdk 36,
  Kotlin + Jetpack Compose, Java 11. Keep `gradle/libs.versions.toml` as in the ZIP.
- Do not add `google-services.json`; the build is configured to only warn if it is missing.

## 2. Build
- Run `./gradlew assembleRelease` (the release build type signs with the debug key when no keystore is configured, which is intended).
  Also run `./gradlew testDebugUnitTest` and report the result.
- Output the installable APK as `MaxAssistant.apk`.

## 3. If the build fails
The code was written without access to a compiler, so a few compile errors are possible (most likely in: `ai/GeminiBrain.kt` streaming code,
`engine/CameraCapture.kt`, `engine/Automations.kt`, `engine/ScreenAgent.kt`, `tts/TTSManager.kt`, `engine/RootSetup.kt`).
- Fix each error with the SMALLEST possible change (a missing import, a type, a nullable, a renamed API). Never delete a feature, never replace logic with a stub,
  never comment code out to make it compile, never change prompt text, never change behaviour.
- If a library API differs from what the code uses, adapt the call, not the design.
- If a unit test fails because of an environment limit (e.g. Robolectric / `org.json` stubs not mocked on the JVM), report it but do not delete the test; you may add
  `testOptions { unitTests.isReturnDefaultValues = true }` and `testImplementation("org.json:json:20231013")` to the app Gradle file.
- Repeat until the APK builds.

## 4. Things you must NOT change
- `applicationId`, the package names, the AndroidManifest permissions/services/receivers, `RootCommandEngine` (the only root shell), the safety blocklist,
  `ShellQuote`, the Gemini system prompt in `GeminiBrain.kt`, and anything that talks about the PIN (`ScreenUnlock`).
- Do not enable minify/R8 (it is off on purpose; keep rules are already in `proguard-rules.pro` if you ever do).
- Do not add analytics, ads, telemetry or any network call other than Gemini (`generativelanguage.googleapis.com`) and the weather service already in the code.

## 5. Final report (plain text, short)
1. APK file name and size, build tools versions used.
2. Every compile error you fixed: file, line, what you changed (one line each).
3. Unit test result (passed / failed list).
4. Anything you could not do, and why.

What the app is (for context only): a rooted-Android Hindi/Hinglish voice assistant. Gemini decides what to do, root performs it (screen, camera, calls, apps, files),
Gemini words the answer. It listens in a foreground service, can start after boot, works with the phone locked, and runs user automations.

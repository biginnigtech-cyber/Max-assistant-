package com.example

import com.example.brain.PersonalityEngine
import com.example.brain.UserEmotionContext
import com.example.brain.VoicePersonalityManager
import com.example.data.MaxCommandResponse
import com.example.executor.IntentExecutionLayer
import com.example.service.AcousticEchoManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MaxAudioPipelineAndGatingTest {

    // -------------------------------------------------------------
    // TEST 1: UNIFIED WAKE EXTRACTION (HEY MAX + COMMAND = ONE UTTERANCE)
    // -------------------------------------------------------------

    @Test
    fun testWakeExtraction_HeyMaxHowAreYou() {
        val result = AcousticEchoManager.detectAndExtractWake("Hey Max, how are you?")
        assertTrue("Should detect wake word", result.hasWakeWord)
        assertEquals("how are you", result.command)
    }

    @Test
    fun testWakeExtraction_HeyMaxOpenYouTube() {
        val result = AcousticEchoManager.detectAndExtractWake("Hey Max, open YouTube")
        assertTrue("Should detect wake word", result.hasWakeWord)
        assertEquals("open youtube", result.command)
    }

    @Test
    fun testWakeExtraction_HindiWakeWord() {
        val result = AcousticEchoManager.detectAndExtractWake("सुनो मैक्स, आज मौसम कैसा है?")
        assertTrue("Should detect Hindi wake word", result.hasWakeWord)
        assertEquals("आज मौसम कैसा है", result.command)
    }

    @Test
    fun testWakeExtraction_PureWakeWordWithoutCommand() {
        val result = AcousticEchoManager.detectAndExtractWake("Hey Max")
        assertTrue("Should detect wake word", result.hasWakeWord)
        assertEquals("", result.command)
    }

    // -------------------------------------------------------------
    // TEST 2: BARGE-IN INTERRUPT KEYWORDS
    // -------------------------------------------------------------

    @Test
    fun testBargeIn_InterruptKeywordsEnglishAndHindi() {
        assertTrue(AcousticEchoManager.isUserInterruptCommand("stop"))
        assertTrue(AcousticEchoManager.isUserInterruptCommand("wait"))
        assertTrue(AcousticEchoManager.isUserInterruptCommand("रुको"))
        assertTrue(AcousticEchoManager.isUserInterruptCommand("चुप"))
        assertTrue(AcousticEchoManager.isUserInterruptCommand("शांत"))
        assertTrue(AcousticEchoManager.isUserInterruptCommand("मैक्स रुको"))
        assertTrue(AcousticEchoManager.isUserInterruptCommand("shut up"))
    }

    @Test
    fun testBargeIn_ExtractIntentAfterStop() {
        val intent = AcousticEchoManager.extractUserIntentFromInterrupt("MAX stop, open YouTube")
        assertEquals("open youtube", intent.lowercase())
    }

    // -------------------------------------------------------------
    // TEST 3: LANGUAGE-INDEPENDENT & PHONETIC SELF-ECHO DETECTION
    // -------------------------------------------------------------

    @Test
    fun testSelfEcho_ExactAndSubstringMatching() {
        val ttsText = "I am MAX, your personal AI assistant created by Mr. Ram Narayan."
        val micEcho = "I am MAX your personal AI assistant"
        val isEcho = AcousticEchoManager.isSelfEcho(
            recognizedText = micEcho,
            lastTtsText = ttsText,
            ttsEndTimeMillis = System.currentTimeMillis(),
            isCurrentlySpeakingTts = true
        )
        assertTrue("Substrings of active TTS must be recognized as self-echo", isEcho)
    }

    @Test
    fun testSelfEcho_HindiPhoneticTransliteration() {
        val ttsHindi = "नमस्ते, मैं मैक्स हूँ, बताइए क्या काम है"
        val micTranscribedHindi = "नमस्ते मैं मैक्स हूँ"
        val isEcho = AcousticEchoManager.isSelfEcho(
            recognizedText = micTranscribedHindi,
            lastTtsText = ttsHindi,
            ttsEndTimeMillis = System.currentTimeMillis(),
            isCurrentlySpeakingTts = true
        )
        assertTrue("Devanagari TTS echo in microphone must be filtered out", isEcho)
    }

    @Test
    fun testSelfEcho_NonEchoUserSpeechNotFiltered() {
        val ttsText = "I am MAX, your AI assistant."
        val userSpeech = "Open camera and take a photo"
        val isEcho = AcousticEchoManager.isSelfEcho(
            recognizedText = userSpeech,
            lastTtsText = ttsText,
            ttsEndTimeMillis = System.currentTimeMillis() - 2000L,
            isCurrentlySpeakingTts = false
        )
        assertFalse("Distinct user speech after TTS cooldown must NOT be treated as echo", isEcho)
    }

    // -------------------------------------------------------------
    // TEST 4: STRICT CHAT & YOUTUBE GATING (QUERY != YOUTUBE)
    // -------------------------------------------------------------

    @Test
    fun testPersonality_NoRepetitiveSirAndNoBro() {
        // Enforce respectful address sanitizes forbidden nicknames
        val sanitizedBro = VoicePersonalityManager.enforceRespectfulAddress("Hey bro, here is the file")
        assertFalse("Must not contain bro", sanitizedBro.contains("bro", ignoreCase = true))

        val sanitizedBhai = VoicePersonalityManager.enforceRespectfulAddress("हाँ भाई, काम हो गया")
        assertFalse("Must not contain भाई", sanitizedBhai.contains("भाई"))

        // Must not force "Sir" repetitively
        val cleanGreeting = PersonalityEngine.formatGreeting()
        assertFalse("Must not force robotic repetitive Sir prefix", cleanGreeting.startsWith("Sir,"))

        val cleanCompletion = PersonalityEngine.formatCompletion("WiFi turned on.")
        assertFalse("Must not force robotic Sir suffix", cleanCompletion.endsWith("Sir."))
    }

    @Test
    fun testPersonality_IdentityIntegrity() {
        val directive = PersonalityEngine.buildPersonalityDirective()
        assertTrue("Identity must be MAX", directive.contains("MAX"))
        assertTrue("Owner must be Ram Narayan", directive.contains("Ram Narayan"))
        assertTrue("Must forbid JARVIS", directive.contains("JARVIS"))
        assertTrue("Must forbid bro / bhai", directive.contains("Bro", ignoreCase = true) || directive.contains("Bhai", ignoreCase = true))
    }

    @Test
    fun testPersonality_NoRepetitiveRamNarayanAddressing() {
        val sanitizedHindi1 = VoicePersonalityManager.enforceRespectfulAddress("राम नारायण जी, वाईफाई चालू कर दिया गया है।")
        assertEquals("वाईफाई चालू कर दिया गया है।", sanitizedHindi1)

        val sanitizedHindi2 = VoicePersonalityManager.enforceRespectfulAddress("मिस्टर राम नारायण जी, आज मौसम बहुत अच्छा है।")
        assertEquals("आज मौसम बहुत अच्छा है।", sanitizedHindi2)

        val sanitizedEnglish = VoicePersonalityManager.enforceRespectfulAddress("Mr. Ram Narayan, the operation has completed successfully.")
        assertEquals("the operation has completed successfully.", sanitizedEnglish)

        val directive = VoicePersonalityManager.buildPersonalityDirective(UserEmotionContext.NEUTRAL)
        assertTrue("Directive must forbid repetitive Ram Narayan addressing", directive.contains("राम नारायण जी") || directive.contains("Ram Narayan"))
    }

    // -------------------------------------------------------------
    // TEST 6: BARGE-IN ISOLATION DIAGNOSTIC MODE
    // -------------------------------------------------------------

    @Test
    fun testBargeInDiagnostic_FlagActiveByDefault() {
        assertTrue("Diagnostic flag must be active for isolation testing", com.example.service.MaxVoiceService.BARGE_IN_DIAGNOSTIC_DISABLED)
    }

    @Test
    fun testBargeInDiagnostic_CanToggleMode() {
        val initial = com.example.service.MaxVoiceService.BARGE_IN_DIAGNOSTIC_DISABLED
        try {
            com.example.service.MaxVoiceService.BARGE_IN_DIAGNOSTIC_DISABLED = false
            assertFalse(com.example.service.MaxVoiceService.BARGE_IN_DIAGNOSTIC_DISABLED)
            com.example.service.MaxVoiceService.BARGE_IN_DIAGNOSTIC_DISABLED = true
            assertTrue(com.example.service.MaxVoiceService.BARGE_IN_DIAGNOSTIC_DISABLED)
        } finally {
            com.example.service.MaxVoiceService.BARGE_IN_DIAGNOSTIC_DISABLED = initial
        }
    }

    @Test
    fun testBargeInDiagnostic_InterruptionBlockedLogic() {
        // Verify that interrupt commands are detected as interrupt commands
        assertTrue(AcousticEchoManager.isUserInterruptCommand("stop"))
        assertTrue(AcousticEchoManager.isUserInterruptCommand("रुको"))

        // When BARGE_IN_DIAGNOSTIC_DISABLED is true, barge-in detection during TTS must be suppressed
        val isDiagnosticDisabled = com.example.service.MaxVoiceService.BARGE_IN_DIAGNOSTIC_DISABLED
        assertTrue("Diagnostic mode should be active for self-echo isolation", isDiagnosticDisabled)
    }
}

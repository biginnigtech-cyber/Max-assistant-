package com.example

import com.example.brain.PrivacyClassifier
import com.example.brain.PrivacyLevel
import com.example.engine.RootSetup
import com.example.engine.SmartEntityExtractor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RootSetupAndParsingTest {

    @Test
    fun rootSetupGrantsWhatTheAppNeeds() {
        val cmds = RootSetup.commandsFor("com.example", "com.example/com.example.service.MaxNotificationListenerService")
        assertTrue(cmds.any { it.contains("READ_CALL_LOG") })
        assertTrue(cmds.any { it.contains("allow_listener") })
        assertTrue(cmds.any { it.contains("deviceidle whitelist +com.example") })
        assertTrue(cmds.all { !it.contains("\n") })
        // Android 11: the microphone is "while in use" only, unless allowed explicitly.
        assertTrue(cmds.any { it.contains("RECORD_AUDIO allow") })
    }

    @Test
    fun bootScriptWaitsForBootAndStartsTheServiceAsRoot() {
        val comp = "com.aistudio.maxvoiceassistant.kxlpqa/com.example.service.MaxVoiceService"
        val script = RootSetup.bootScript(comp)
        assertTrue(script.startsWith("#!/system/bin/sh"))
        assertTrue(script.contains("sys.boot_completed"))
        assertTrue(script.contains("am start-foreground-service --user 0 -n '$comp'"))
    }

    @Test
    fun otpCodeIsTheCodeNotTheAmount() {
        assertEquals("123456", PrivacyClassifier.extractOtpCode("Rs 5000 debited from your a/c. OTP 123456 for the payment"))
        assertEquals("482913", PrivacyClassifier.extractOtpCode("482913 is your verification code"))
        assertNull(PrivacyClassifier.extractOtpCode("Your balance is Rs 5000"))
    }

    @Test
    fun ordinaryChatIsNotPromotion() {
        assertFalse(PrivacyClassifier.classifyLocally("Rahul", "I'm off today, let's meet", false) == PrivacyLevel.PROMOTION)
        assertTrue(PrivacyClassifier.classifyLocally("Shop", "Flat 50% off, use promo code NEW50", false) == PrivacyLevel.PROMOTION)
    }

    @Test
    fun tellMeAJokeIsNotAMessageToSomeoneNamedMe() {
        assertNull(SmartEntityExtractor.extract("tell me a joke"))
        assertNull(SmartEntityExtractor.extract("tell me the time"))
        assertFalse(SmartEntityExtractor.isValidContact("me a joke"))
        assertFalse(SmartEntityExtractor.isValidContact("क्या हुआ आज"))
        assertTrue(SmartEntityExtractor.isValidContact("Rahul Sharma"))
    }
}

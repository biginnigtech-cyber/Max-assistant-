package com.example

import com.example.utils.ShellQuote
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ShellQuoteTest {

    @Test
    fun singleQuoteInsideTextCannotEscapeTheQuoting() {
        // Spoken search word that tries to end the quote and run a second command as root.
        val evil = "a'; rm -rf /sdcard; echo '"
        val quoted = ShellQuote.q(evil)
        assertEquals("'a'\\''; rm -rf /sdcard; echo '\\'''", quoted)
        // After removing every escaped quote pair, no bare quote may remain inside the payload.
        val inner = quoted.removePrefix("'").removeSuffix("'").replace("'\\''", "")
        assertFalse(inner.contains("'"))
    }

    @Test
    fun storageRootsAndSystemFoldersAreProtected() {
        for (p in listOf("/", "/sdcard", "/sdcard/", "/storage/emulated/0", "/storage/emulated/0/", "/data", "/system", "", "   ",
            "/sdcard/../data", "/sdcard/Download/../..", "//system//")) {
            assertTrue("'$p' must be protected", ShellQuote.isProtectedPath(p))
        }
    }

    @Test
    fun ordinaryFilesAreNotProtected() {
        assertFalse(ShellQuote.isProtectedPath("/sdcard/Download/report.pdf"))
        assertFalse(ShellQuote.isProtectedPath("/storage/emulated/0/Pictures/old"))
    }

    @Test
    fun fileNameCannotCarryAPath() {
        assertEquals("evil.txt", ShellQuote.safeFileName("../../evil.txt"))
        assertEquals("a.txt", ShellQuote.safeFileName("/etc/a.txt"))
    }
}

package com.example

import com.example.engine.RootUi
import com.example.engine.ScreenReader
import com.example.tts.VoiceStyle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceAndScreenTest {

    @Test
    fun defaultVoiceIsDeepAndHeavy() {
        assertTrue(VoiceStyle.ULTRON.pitch < 0.7f)
        // Not too slow, not too bass-heavy for a phone speaker, and loud: the first version sounded like a hand over the speaker.
        assertTrue(VoiceStyle.ULTRON.rate >= 0.95f)
        assertTrue(VoiceStyle.ULTRON.bass in 300..700)
        assertTrue(VoiceStyle.ULTRON.gain >= 1000)
        assertEquals(1.0f, VoiceStyle.NORMAL.pitch, 0.001f)

        val louder = VoiceStyle.compute(VoiceStyle.ULTRON, mapOf("change" to "louder"))
        assertTrue(louder.gain > VoiceStyle.ULTRON.gain)
        val slower = VoiceStyle.compute(VoiceStyle.ULTRON, mapOf("change" to "slower"))
        assertTrue(slower.rate < VoiceStyle.ULTRON.rate)
        assertEquals(VoiceStyle.ULTRON.gain, slower.gain)
    }

    @Test
    fun relativeVoiceChangesStayInRange() {
        var p = VoiceStyle.ULTRON
        repeat(20) { p = VoiceStyle.compute(p, mapOf("change" to "deeper")) }
        assertEquals(0.3f, p.pitch, 0.001f)
        assertEquals(1000, p.bass)
        val lighter = VoiceStyle.compute(VoiceStyle.ULTRON, mapOf("change" to "lighter"))
        assertTrue(lighter.pitch > VoiceStyle.ULTRON.pitch)
        assertTrue(lighter.bass < VoiceStyle.ULTRON.bass)
        val exact = VoiceStyle.compute(VoiceStyle.ULTRON, mapOf("profile" to "normal", "rate" to "9"))
        assertEquals(1.0f, exact.pitch, 0.001f)
        assertEquals(1.5f, exact.rate, 0.001f)
    }

    private fun node(text: String, top: Int, pkg: String = "com.app", left: Int = 0) =
        RootUi.Node(pkg, "", text, "", "android.widget.TextView", false, left, top, left + 500, top + 60)

    @Test
    fun screenTextIsOrderedDedupedAndWithoutStatusBar() {
        val nodes = listOf(
            node("10:45", 20, "com.android.systemui"),
            node("दूसरी लाइन", 400),
            node("पहली लाइन", 100),
            node("पहली लाइन", 100, left = 10),
            node("नीचे का बटन", 900)
        )
        val text = ScreenReader.visibleText(nodes)
        assertEquals("पहली लाइन\nदूसरी लाइन\nनीचे का बटन", text)
        assertFalse(text.contains("10:45"))
    }
}

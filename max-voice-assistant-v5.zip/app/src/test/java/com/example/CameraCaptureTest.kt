package com.example

import com.example.engine.CameraCapture
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CameraCaptureTest {

    @Test
    fun facingIsUnderstoodFromGeminiWordsAndNeverGuessed() {
        assertEquals("front", CameraCapture.parseFacing("front"))
        assertEquals("front", CameraCapture.parseFacing("selfie"))
        assertEquals("front", CameraCapture.parseFacing("सेल्फी"))
        assertEquals("back", CameraCapture.parseFacing("rear camera"))
        assertEquals("back", CameraCapture.parseFacing("पीछे"))
        assertNull(CameraCapture.parseFacing(""))
        assertNull(CameraCapture.parseFacing(null))
        assertNull(CameraCapture.parseFacing("camera"))
    }

    @Test
    fun fileNamesLookLikeACameraAppAndDoNotClash() {
        val n = CameraCapture.fileName(1_700_000_000_000L)
        assertTrue(n.startsWith("MAX_") && n.endsWith(".jpg"))
        assertTrue(CameraCapture.fileName(1_700_000_000_000L, 2).endsWith("_2.jpg"))
        assertTrue(CameraCapture.fileName(1_700_000_000_000L) != CameraCapture.fileName(1_700_000_000_000L, 1))
    }
}

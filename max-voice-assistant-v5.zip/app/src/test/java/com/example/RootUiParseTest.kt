package com.example

import com.example.engine.RootUi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RootUiParseTest {

    private val xml = """
        <?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
        <hierarchy rotation="0">
          <node index="0" text="" resource-id="" class="android.widget.FrameLayout" package="com.google.android.youtube" content-desc="" clickable="false" bounds="[0,0][1080,2400]">
            <node index="0" text="" resource-id="com.google.android.youtube:id/results" class="android.view.ViewGroup" package="com.google.android.youtube" content-desc="Tum Hi Ho - 4 minutes, 3 million views - 2 years ago - Play video" clickable="true" bounds="[0,300][1080,900]" />
            <node index="1" text="Skip &amp; go" resource-id="com.google.android.youtube:id/skip_ad_button" class="android.widget.TextView" package="com.google.android.youtube" content-desc="" clickable="true" bounds="[800,1500][1040,1620]" />
          </node>
        </hierarchy>
    """.trimIndent()

    @Test
    fun parsesBoundsTextIdsAndEntities() {
        val nodes = RootUi.parse(xml)
        assertEquals(3, nodes.size)
        val card = nodes[1]
        assertEquals("com.google.android.youtube", card.pkg)
        assertTrue(card.clickable)
        assertEquals(540, card.cx)
        assertEquals(600, card.cy)
        assertEquals(600, card.height)
        assertTrue(card.label.contains("Play video"))
        val skip = nodes[2]
        assertEquals("Skip & go", skip.text)
        assertTrue(skip.id.endsWith("skip_ad_button"))
        assertEquals(920, skip.cx)
    }

    @Test
    fun brokenOrEmptyDumpGivesNoNodes() {
        assertTrue(RootUi.parse("").isEmpty())
        assertTrue(RootUi.parse("<hierarchy></hierarchy>").isEmpty())
    }
}

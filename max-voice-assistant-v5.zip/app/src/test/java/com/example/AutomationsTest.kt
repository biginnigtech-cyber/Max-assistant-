package com.example

import com.example.engine.Automations
import com.example.engine.Automations.Rule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import java.util.Calendar
import org.junit.Test

class AutomationsTest {

    private fun at(day: Int, hour: Int, minute: Int = 0): Long =
        Calendar.getInstance().apply { set(2026, Calendar.NOVEMBER, day, hour, minute, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis

    private fun timeRule(h: Int, m: Int = 0, days: String = "daily", atMs: Long = 0L) =
        Rule(id = "r1", name = "t", trigger = "time", hour = h, minute = m, days = days, atMs = atMs, command = "weather")

    @Test
    fun dailyRuleRunsTodayIfStillAheadElseTomorrow() {
        assertEquals(at(4, 7), Automations.nextTriggerMs(timeRule(7), at(4, 6)))
        assertEquals(at(5, 7), Automations.nextTriggerMs(timeRule(7), at(4, 8)))
        // exactly at the minute counts as already passed
        assertEquals(at(5, 7), Automations.nextTriggerMs(timeRule(7), at(4, 7)))
    }

    @Test
    fun weekdayRuleSkipsTheWeekend() {
        // 6 Nov 2026 is a Friday: after 08:00 the next weekday 07:00 is Monday 9 Nov
        assertEquals(at(9, 7), Automations.nextTriggerMs(timeRule(7, days = "weekdays"), at(6, 8)))
        assertEquals(at(7, 9), Automations.nextTriggerMs(timeRule(9, days = "weekends"), at(6, 8)))
        assertEquals(at(5, 7), Automations.nextTriggerMs(timeRule(7, days = "thu"), at(4, 8)))
    }

    @Test
    fun oneOffRuleUsesItsExactMomentOnlyWhileInTheFuture() {
        val r = timeRule(0, atMs = at(4, 12, 30))
        assertEquals(at(4, 12, 30), Automations.nextTriggerMs(r, at(4, 12, 0)))
        assertEquals(-1L, Automations.nextTriggerMs(r, at(4, 13, 0)))
    }

    @Test
    fun onlyTimeRulesAreScheduled() {
        assertEquals(-1L, Automations.nextTriggerMs(Rule(id = "b", name = "b", trigger = "battery_below", percent = 20, command = "x"), at(4, 6)))
    }

    @Test
    fun callAndNotificationMatching() {
        val any = Rule(id = "c", name = "c", trigger = "call", command = "x")
        assertTrue(Automations.matches(any, "Phone", "Rahul"))
        assertTrue(Automations.matches(any, "Phone", null))

        val rahul = Rule(id = "c", name = "c", trigger = "call", match = listOf("राहुल", "rahul"), command = "x")
        assertTrue(Automations.matches(rahul, "Phone", "Rahul Sharma"))
        assertTrue(Automations.matches(rahul, "Phone", "राहुल भैया"))
        assertFalse(Automations.matches(rahul, "Phone", "Amit"))
        assertFalse(Automations.matches(rahul, "Phone", null))

        val unknown = Rule(id = "c", name = "c", trigger = "call", match = listOf("unknown"), command = "x")
        assertTrue(Automations.matches(unknown, "Phone", null))
        assertFalse(Automations.matches(unknown, "Phone", "Amit"))
    }

    @Test
    fun descriptionsAreSpokenHindi() {
        assertTrue(Automations.describe(Rule(id = "b", name = "b", trigger = "battery_below", percent = 20, command = "battery saver")).contains("20%"))
        assertTrue(Automations.describe(Rule(id = "d", name = "d", trigger = "charger_connected", command = "x")).contains("चार्जर"))
        assertTrue(Automations.describe(timeRule(7)).contains("बजे"))
    }
}

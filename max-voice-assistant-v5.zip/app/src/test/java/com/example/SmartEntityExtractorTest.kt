package com.example

import com.example.engine.SmartEntityExtractor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class SmartEntityExtractorTest {

    @Test
    fun testCase1_WhatsAppKholoAurRahulKoMessageKaro() {
        val result = SmartEntityExtractor.extract("WhatsApp खोलो और राहुल को मैसेज करो")
        assertNotNull("Should extract messaging command", result)
        assertEquals("whatsapp", result?.targetApp)
        assertEquals("राहुल", result?.contact)
        assertEquals("", result?.message)
    }

    @Test
    fun testCase2_AnilKoMessageKarDo() {
        val result = SmartEntityExtractor.extract("अनिल को मैसेज कर दो")
        assertNotNull(result)
        assertEquals("whatsapp", result?.targetApp)
        assertEquals("अनिल", result?.contact)
        assertEquals("", result?.message)
    }

    @Test
    fun testCase3_MessageRahulKoBhejDo() {
        val result = SmartEntityExtractor.extract("मैसेज राहुल को भेज दो")
        assertNotNull(result)
        assertEquals("whatsapp", result?.targetApp)
        assertEquals("राहुल", result?.contact)
        assertEquals("", result?.message)
    }

    @Test
    fun testCase4_RahulKoMessageKaroKiMaiShaamKoAaunga() {
        val result = SmartEntityExtractor.extract("राहुल को मैसेज करो कि मैं शाम को आऊंगा")
        assertNotNull(result)
        assertEquals("whatsapp", result?.targetApp)
        assertEquals("राहुल", result?.contact)
        assertEquals("मैं शाम को आऊंगा", result?.message)
    }

    @Test
    fun testCase_RahulKoBoloKiMaiBaadMeCallKarunga() {
        val result = SmartEntityExtractor.extract("राहुल को बोलो कि मैं बाद में कॉल करूंगा")
        assertNotNull(result)
        assertEquals("whatsapp", result?.targetApp)
        assertEquals("राहुल", result?.contact)
        assertEquals("मैं बाद में कॉल करूंगा", result?.message)
    }

    @Test
    fun testCase_PehleWhatsAppKholoPhirAnilKoMessageBhejna() {
        val result = SmartEntityExtractor.extract("पहले WhatsApp खोलो, फिर अनिल को मैसेज भेजना")
        assertNotNull(result)
        assertEquals("whatsapp", result?.targetApp)
        assertEquals("अनिल", result?.contact)
        assertEquals("", result?.message)
    }

    @Test
    fun testCase_RahulKeBhaiKoMessageKaro() {
        val result = SmartEntityExtractor.extract("राहुल के भाई को मैसेज करो")
        assertNotNull(result)
        assertEquals("whatsapp", result?.targetApp)
        assertEquals("राहुल के भाई", result?.contact)
        assertEquals("", result?.message)
    }

    @Test
    fun testCase_AnilKoBhejoKiKalMilteHain() {
        val result = SmartEntityExtractor.extract("अनिल को भेजो कि कल मिलते हैं")
        assertNotNull(result)
        assertEquals("whatsapp", result?.targetApp)
        assertEquals("अनिल", result?.contact)
        assertEquals("कल मिलते हैं", result?.message)
    }

    @Test
    fun testCase_RahulKoWhatsAppParMessageKaro() {
        val result = SmartEntityExtractor.extract("राहुल को WhatsApp पर मैसेज करो")
        assertNotNull(result)
        assertEquals("whatsapp", result?.targetApp)
        assertEquals("राहुल", result?.contact)
        assertEquals("", result?.message)
    }

    @Test
    fun testCase_EnglishCompoundCommand() {
        val result = SmartEntityExtractor.extract("open whatsapp and tell Anil I won't come to school tomorrow")
        assertNotNull(result)
        assertEquals("whatsapp", result?.targetApp)
        assertEquals("Anil", result?.contact)
        assertEquals("I won't come to school tomorrow", result?.message)
    }
}

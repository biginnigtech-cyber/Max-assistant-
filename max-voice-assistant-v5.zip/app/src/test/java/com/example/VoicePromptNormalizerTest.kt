package com.example

import com.example.engine.VoicePromptNormalizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class VoicePromptNormalizerTest {

    @Test
    fun testTorchControl_OnAndOff() {
        val onResult = VoicePromptNormalizer.parse("मैक्स टॉर्च चालू करो")
        assertTrue(onResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.DEVICE_CONTROL, onResult.actionType)
        assertEquals("torch", onResult.targetApp)
        assertEquals("on", onResult.targetEntity)

        val offResult = VoicePromptNormalizer.parse("flashlight off karo")
        assertTrue(offResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.DEVICE_CONTROL, offResult.actionType)
        assertEquals("torch", offResult.targetApp)
        assertEquals("off", offResult.targetEntity)
    }

    @Test
    fun testBluetoothAndWifiControl() {
        val btResult = VoicePromptNormalizer.parse("bluetooth on karo")
        assertTrue(btResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.DEVICE_CONTROL, btResult.actionType)
        assertEquals("bluetooth", btResult.targetApp)
        assertEquals("on", btResult.targetEntity)

        val wifiResult = VoicePromptNormalizer.parse("wifi band karo")
        assertTrue(wifiResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.DEVICE_CONTROL, wifiResult.actionType)
        assertEquals("wifi", wifiResult.targetApp)
        assertEquals("off", wifiResult.targetEntity)
    }

    @Test
    fun testVolumeAndBatteryControl() {
        val volResult = VoicePromptNormalizer.parse("आवाज़ बढ़ाओ")
        assertTrue(volResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.DEVICE_CONTROL, volResult.actionType)
        assertEquals("volume", volResult.targetApp)
        assertEquals("up", volResult.targetEntity)

        val batteryResult = VoicePromptNormalizer.parse("battery kitni hai")
        assertTrue(batteryResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.DEVICE_CONTROL, batteryResult.actionType)
        assertEquals("battery", batteryResult.targetApp)
    }

    @Test
    fun testAppLaunch_CameraAndWhatsApp() {
        val camResult = VoicePromptNormalizer.parse("camera kholo")
        assertTrue(camResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.OPEN_APP, camResult.actionType)
        assertEquals("camera", camResult.targetApp)

        val calcResult = VoicePromptNormalizer.parse("open calculator")
        assertTrue(calcResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.OPEN_APP, calcResult.actionType)
        assertEquals("calculator", calcResult.targetApp)
    }

    @Test
    fun testDirectChat_KamKaroAndIdentity() {
        val readyResult = VoicePromptNormalizer.parse("Kam Karo yrr thik karo")
        assertTrue(readyResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.DIRECT_CHAT, readyResult.actionType)
        assertEquals("work_ready", readyResult.targetEntity)

        val whoResult = VoicePromptNormalizer.parse("tum kaun ho")
        assertTrue(whoResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.DIRECT_CHAT, whoResult.actionType)
        assertEquals("identity", whoResult.targetEntity)

        val creatorResult = VoicePromptNormalizer.parse("tumhe kisne banaya")
        assertTrue(creatorResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.DIRECT_CHAT, creatorResult.actionType)
        assertEquals("creator", creatorResult.targetEntity)
    }

    @Test
    fun testTimeQuery() {
        val timeResult = VoicePromptNormalizer.parse("time kya hua hai")
        assertTrue(timeResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.TIME_QUERY, timeResult.actionType)
        assertEquals("time", timeResult.targetApp)

        val dateResult = VoicePromptNormalizer.parse("aaj konsi tarikh hai")
        assertTrue(dateResult.hasExplicitAction)
        assertEquals(VoicePromptNormalizer.ActionType.TIME_QUERY, dateResult.actionType)
        assertEquals("date", dateResult.targetApp)
    }

    @Test
    fun testMixedSentencesAreNotHijackedByOneKeyword() {
        // A message that merely mentions wifi must go on (to Gemini / messaging), never switch wifi off.
        val msg = VoicePromptNormalizer.parse("Rahul ko WhatsApp pe bolo ki wifi band kar diya hai")
        assertTrue(msg.actionType != VoicePromptNormalizer.ActionType.DEVICE_CONTROL)

        // "thanks" inside a longer command must not swallow the command.
        val thanks = VoicePromptNormalizer.parse("thanks Max ab Spotify par Arijit Singh ka gaana play karo")
        assertTrue(thanks.actionType != VoicePromptNormalizer.ActionType.DIRECT_CHAT)

        // A message that asks about time is a message, not a clock question.
        val timeInMsg = VoicePromptNormalizer.parse("Rahul ko bolo kitne baje aana hai")
        assertTrue(timeInMsg.actionType != VoicePromptNormalizer.ActionType.TIME_QUERY)
    }

    @Test
    fun testWholeWordMatchingInDeviceControl() {
        // "on" is inside "phone" / "konsa": torch must not turn on from those.
        val torch = VoicePromptNormalizer.parse("torch band karo")
        assertEquals("off", torch.targetEntity)
        val vol = VoicePromptNormalizer.parse("volume kam karo")
        assertEquals("down", vol.targetEntity)
        val volMax = VoicePromptNormalizer.parse("volume full karo")
        assertEquals("max", volMax.targetEntity)
    }

    @Test
    fun testDatePhrases() {
        val d = VoicePromptNormalizer.parse("आज कौन सी तारीख है")
        assertEquals(VoicePromptNormalizer.ActionType.TIME_QUERY, d.actionType)
        assertEquals("date", d.targetApp)
    }

    @Test
    fun testBareWordsAreNeverLocalCommands() {
        for (w in listOf("message", "prompt", "port", "wifi", "संदेश", "प्रॉम्प्ट")) {
            val p = VoicePromptNormalizer.parse(w)
            assertTrue("'$w' must not become a send-message action", p.actionType != VoicePromptNormalizer.ActionType.SEND_MESSAGE)
        }
    }

    @Test
    fun testBareDateAndTimeWordsAreNotQuestions() {
        for (w in listOf("date", "Date", "तारीख", "डेट", "time", "टाइम", "समय", "क्या date", "date time")) {
            val p = VoicePromptNormalizer.parse(w)
            assertTrue("'$w' must not be answered as a clock question", p.actionType != VoicePromptNormalizer.ActionType.TIME_QUERY)
        }
    }

    @Test
    fun testCompleteTimeAndDateQuestionsStillWork() {
        assertEquals("date", VoicePromptNormalizer.parse("आज की तारीख क्या है").targetApp)
        assertEquals("date", VoicePromptNormalizer.parse("what's the date today").targetApp)
        assertEquals("time", VoicePromptNormalizer.parse("अभी कितने बजे हैं").targetApp)
        assertEquals(VoicePromptNormalizer.ActionType.TIME_QUERY, VoicePromptNormalizer.parse("time kya hua hai").actionType)
    }
}

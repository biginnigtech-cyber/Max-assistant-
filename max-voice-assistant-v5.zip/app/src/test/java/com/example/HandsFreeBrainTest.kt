package com.example

import com.example.engine.HabitTracker
import com.example.engine.HabitTracker.Event
import com.example.engine.PhoneState
import com.example.engine.ScreenUnlock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class HandsFreeBrainTest {

    @Test
    fun pinIsExtractedFromNaturalSpeechAndNeverLeaksIntoLogs() {
        assertEquals("1234", ScreenUnlock.extractPin("मेरा PIN 1 2 3 4 है, याद रखो"))
        assertEquals("482913", ScreenUnlock.extractPin("my pin is 482913 remember it"))
        assertNull(ScreenUnlock.extractPin("call 9876543210"))
        assertTrue(ScreenUnlock.isSavePinRequest("मेरा पिन 4321 याद रखो"))
        assertTrue(ScreenUnlock.isForgetPinRequest("मेरा PIN भूल जाओ"))
        val redacted = ScreenUnlock.redactSecrets("मेरा PIN 1234 है")
        assertFalse(redacted.contains("1234"))
        assertTrue(redacted.contains("••••"))
        assertEquals("what time is it", ScreenUnlock.redactSecrets("what time is it"))
    }

    @Test
    fun lockStateIsReadFromTheDumps() {
        assertTrue(ScreenUnlock.parseLocked("isKeyguardShowing=true", "mWakefulness=Awake"))
        assertTrue(ScreenUnlock.parseLocked("", "mWakefulness=Asleep"))
        assertFalse(ScreenUnlock.parseLocked("mShowingLockscreen=false isKeyguardShowing=false", "mWakefulness=Awake"))
        assertFalse(ScreenUnlock.parseLocked("", ""))
    }

    @Test
    fun phoneStateParsesBatteryForegroundAndLock() {
        val raw = """
              level: 14
              AC powered: false
              USB powered: false
            ---
              mCurrentFocus=Window{abc u0 com.whatsapp/com.whatsapp.Main}
            ---
            ---
            mWakefulness=Awake
        """.trimIndent()
        val s = PhoneState.parse(raw)
        assertEquals("14%", s["battery"])
        assertEquals("no", s["charging"])
        assertEquals("com.whatsapp", s["foreground_app"])
        assertEquals("unlocked", s["screen"])
    }

    private fun at(day: Int, hour: Int, minute: Int = 0): Long =
        Calendar.getInstance().apply { set(2026, Calendar.NOVEMBER, day, hour, minute, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis

    @Test
    fun aHabitNeedsSeveralDaysAroundTheSameHour() {
        val now = at(10, 7, 5)
        val events = listOf(Event(at(7, 6, 58), "PLAY_MUSIC|youtube"), Event(at(8, 7, 10), "PLAY_MUSIC|youtube"), Event(at(9, 7, 2), "PLAY_MUSIC|youtube"))
        val p = HabitTracker.patterns(events, now)
        assertEquals(1, p.size)
        assertEquals("PLAY_MUSIC|youtube", p[0].key)
        assertTrue(HabitTracker.dueNow(events, now).isNotEmpty())
        // two days is not a habit; neither is one busy day
        assertTrue(HabitTracker.patterns(events.take(2), now).isEmpty())
        val sameDay = listOf(Event(at(9, 7, 0), "X"), Event(at(9, 7, 20), "X"), Event(at(9, 7, 40), "X"))
        assertTrue(HabitTracker.patterns(sameDay, now).isEmpty())
        // old events fall out of the two-week window
        assertTrue(HabitTracker.patterns(events, at(30, 7, 0)).isEmpty())
    }
}

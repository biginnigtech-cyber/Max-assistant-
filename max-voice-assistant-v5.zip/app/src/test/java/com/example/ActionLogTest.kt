package com.example

import com.example.data.MaxCommandResponse
import com.example.engine.ActionLog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ActionLogTest {

    @Before fun reset() = ActionLog.clear()

    @Test
    fun emptyLogGivesNoContext() {
        assertEquals("", ActionLog.contextBlock())
    }

    @Test
    fun recordedCommandIsHandedBackToGeminiWithUndoHintAndStateBefore() {
        val cmd = MaxCommandResponse(
            intent = "DEVICE_CONTROL", module = "DEVICE",
            parameters = mapOf("setting" to "wifi", "state" to "on", "_raw_query" to "wifi on karo"),
            undo_hint = "turn wifi off"
        )
        ActionLog.recordFromResult("wifi on karo", "DEVICE", "वाईफाई चालू कर दिया है।", true, false, cmd, "wifi off; volume 5/15")
        val block = ActionLog.contextBlock()
        assertTrue(block.contains("wifi on karo"))
        assertTrue(block.contains("undo_hint: turn wifi off"))
        assertTrue(block.contains("phone state BEFORE: wifi off; volume 5/15"))
        assertTrue("internal _raw_query must not leak", !block.contains("_raw_query"))
    }

    @Test
    fun chatAndQuestionsAreNotActions() {
        ActionLog.recordFromResult("kaise ho", "CHAT", "ठीक हूँ", true, false, null, "")
        ActionLog.recordFromResult("kya samay hua", "TIME", "तीन बजे हैं", true, false, null, "")
        ActionLog.recordFromResult("message", "DEVICE", "किसे?", true, true, null, "")
        assertEquals("", ActionLog.contextBlock())
    }

    @Test
    fun oldActionsExpireAndOnlyRecentSixAreKept() {
        val t0 = 1_000_000L
        for (i in 1..8) ActionLog.record("cmd$i", "DEVICE", "X", "", "ok", true, "undo$i", "", t0 + i)
        val block = ActionLog.contextBlock(t0 + 100)
        assertTrue(!block.contains("cmd1\"") && !block.contains("cmd2\""))
        assertTrue(block.contains("cmd8"))
        // far in the future everything has expired
        assertEquals("", ActionLog.contextBlock(t0 + 60 * 60 * 1000L))
    }
}

package com.example

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Headset
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.GeminiBrain
import com.example.executor.RootShellExecutor
import com.example.service.MaxVoiceService
import com.example.ui.components.MaxCoreCanvas
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.GroqOrange
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonTextPrimary
import com.example.ui.theme.NeonTextSecondary
import com.example.utils.PreferencesManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    companion object {
        const val ACTION_REQUEST_MIC_PERMISSION = "com.example.ACTION_REQUEST_MIC_PERMISSION"
    }

    private var maxService: MaxVoiceService? = null
    private var isBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as MaxVoiceService.LocalBinder
            maxService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            maxService = null
            isBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val intent = Intent(this, MaxVoiceService::class.java)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    containerColor = CyberBackground
                ) { innerPadding ->
                    MaxDashboard(
                        modifier = Modifier.padding(innerPadding),
                        getService = { maxService },
                        onStartService = { startMaxService() },
                        onStopService = { stopMaxService() }
                    )
                }
            }
        }
    }

    private fun startMaxService() {
        val intent = Intent(this, MaxVoiceService::class.java).apply {
            action = MaxVoiceService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopMaxService() {
        val intent = Intent(this, MaxVoiceService::class.java).apply {
            action = MaxVoiceService.ACTION_STOP
        }
        startService(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) {
            unbindService(serviceConnection)
            isBound = false
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaxDashboard(
    modifier: Modifier = Modifier,
    getService: () -> MaxVoiceService?,
    onStartService: () -> Unit,
    onStopService: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val geminiBrain = remember { GeminiBrain() }

    var showApiKeyDialog by remember { mutableStateOf(false) }
    var rootAvailable by remember { mutableStateOf<Boolean?>(null) }
    var serviceActive by remember { mutableStateOf(false) }
    var customPrompt by remember { mutableStateOf("") }
    var isTerminalExpanded by remember { mutableStateOf(true) }
    var notifListenerGranted by remember { mutableStateOf(isNotificationListenerGranted(context)) }

    val service = getService()
    val status by service?.status?.collectAsState() ?: remember { mutableStateOf(MaxVoiceService.ServiceStatus.IDLE) }
    val logs by service?.logs?.collectAsState() ?: remember { mutableStateOf(emptyList()) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (recordGranted) {
            val activeSvc = getService()
            if (activeSvc != null) {
                activeSvc.startLiveConversation()
            } else {
                onStartService()
            }
            serviceActive = true
        } else {
            Toast.makeText(context, "Microphone permission is required for Live Voice Chat", Toast.LENGTH_LONG).show()
        }
    }

    var currentActiveModel by remember { mutableStateOf(PreferencesManager.getSelectedModel(context)) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            rootAvailable = RootShellExecutor.isRootAvailable()
            val apiKey = PreferencesManager.getApiKey(context)
            if (apiKey.isNotBlank() && apiKey.startsWith("AIzaSy")) {
                val saved = PreferencesManager.getSelectedModel(context)
                if (saved.isBlank() || saved.contains("2.5") || saved.contains("1.5") || saved.contains("2.0") || saved == "gemini-3.5-flash" || saved == "gemini-flash-latest" || saved == "gemini-pro") {
                    geminiBrain.fetchAndAutoSelectBestModel(apiKey).onSuccess { autoModel ->
                        PreferencesManager.saveSelectedModel(context, autoModel)
                        withContext(Dispatchers.Main) {
                            currentActiveModel = autoModel
                        }
                    }
                }
            }
        }
        notifListenerGranted = isNotificationListenerGranted(context)

        // Automatically request permissions on app launch (including POST_NOTIFICATIONS on Android 13+)
        val requiredPerms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requiredPerms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(requiredPerms.toTypedArray())
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Futuristic Top HUD Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CyberSurface.copy(alpha = 0.85f))
                    .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                if (serviceActive) NeonGreen else NeonCyan.copy(alpha = 0.6f)
                            )
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "MAX // AI CORE",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 2.sp
                            ),
                            color = NeonTextPrimary
                        )
                        val currentModel = remember(showApiKeyDialog, currentActiveModel) { PreferencesManager.getSelectedModel(context) }
                        Text(
                            text = if (currentModel.isBlank()) "gemini-3.5-flash-lite" else currentModel,
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = NeonCyan
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Voice Engine / Settings Quick Action
                    IconButton(
                        onClick = { showApiKeyDialog = true },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(CyberSurfaceVariant)
                            .border(1.dp, NeonBlue.copy(alpha = 0.5f), CircleShape)
                            .testTag("voice_engine_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Headset,
                            contentDescription = "Voice Engine Settings",
                            tint = NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Settings Button
                    IconButton(
                        onClick = { showApiKeyDialog = true },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(CyberSurfaceVariant)
                            .border(1.dp, NeonCyan.copy(alpha = 0.4f), CircleShape)
                            .testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Root indicator chip
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = when (rootAvailable) {
                            true -> NeonGreen.copy(alpha = 0.15f)
                            false -> NeonRed.copy(alpha = 0.15f)
                            null -> CyberSurfaceVariant
                        },
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            when (rootAvailable) {
                                true -> NeonGreen.copy(alpha = 0.4f)
                                false -> NeonRed.copy(alpha = 0.4f)
                                null -> NeonCyan.copy(alpha = 0.2f)
                            }
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = when (rootAvailable) {
                                    true -> NeonGreen
                                    false -> NeonRed
                                    null -> NeonTextSecondary
                                },
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (rootAvailable) {
                                    true -> "ROOT OK"
                                    false -> "NO ROOT"
                                    null -> "CHK"
                                },
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = when (rootAvailable) {
                                    true -> NeonGreen
                                    false -> NeonRed
                                    null -> NeonTextSecondary
                                }
                            )
                        }
                    }

                    // Notification Access Indicator Chip
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (notifListenerGranted) NeonGreen.copy(alpha = 0.15f) else NeonGold.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (notifListenerGranted) NeonGreen.copy(alpha = 0.4f) else NeonGold.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier
                            .clickable {
                                val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                context.startActivity(intent)
                                Toast.makeText(context, "Opening Notification Access Settings for MAX", Toast.LENGTH_LONG).show()
                            }
                            .testTag("notification_access_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (notifListenerGranted) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                                contentDescription = "Notification Listener Status",
                                tint = if (notifListenerGranted) NeonGreen else NeonGold,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (notifListenerGranted) "NOTIF OK" else "GRANT",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = if (notifListenerGranted) NeonGreen else NeonGold
                            )
                        }
                    }

                    // Gaming Mode / DND Chip
                    var gamingModeActive by remember {
                        mutableStateOf(com.example.brain.MemoryManager.getInstance(context).isGamingMode())
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (gamingModeActive) NeonCyan.copy(alpha = 0.2f) else CyberSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (gamingModeActive) NeonCyan else NeonCyan.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier
                            .clickable {
                                val newState = !gamingModeActive
                                com.example.brain.MemoryManager.getInstance(context).setGamingMode(newState)
                                gamingModeActive = newState
                                val msg = if (newState) "Gaming DND Mode ON: Only Calls, Family & OTP spoken" else "Gaming DND Mode OFF: All notifications spoken"
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                            .testTag("gaming_mode_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (gamingModeActive) "🎮 DND" else "🎮 OFF",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = if (gamingModeActive) NeonCyan else NeonTextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Central AI Core Visualization Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    val serviceObj = getService()
                    val audioLevelVal by serviceObj?.audioLevel?.collectAsState() ?: remember { mutableStateOf(0f) }
                    val isSpeakingTtsVal by serviceObj?.isSpeakingTtsState?.collectAsState() ?: remember { mutableStateOf(false) }

                    MaxCoreCanvas(
                        status = status,
                        size = 230.dp,
                        audioLevel = audioLevelVal,
                        isSpeakingTts = isSpeakingTtsVal,
                        aiName = "MAX"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Status Badge HUD Text inside/below core
                    val statusText = when (status) {
                        MaxVoiceService.ServiceStatus.IDLE -> if (isSpeakingTtsVal) "Speaking..." else "Idle"
                        MaxVoiceService.ServiceStatus.LISTENING,
                        MaxVoiceService.ServiceStatus.LISTENING_FOR_WAKE_WORD,
                        MaxVoiceService.ServiceStatus.LISTENING_FOR_COMMAND -> "Listening"
                        MaxVoiceService.ServiceStatus.THINKING -> "Thinking"
                        MaxVoiceService.ServiceStatus.EXECUTING -> "Executing"
                        MaxVoiceService.ServiceStatus.RUNNING_TOOL -> "Running Tool"
                        MaxVoiceService.ServiceStatus.SPEAKING -> "Speaking"
                        MaxVoiceService.ServiceStatus.COMPLETED -> "Completed"
                        MaxVoiceService.ServiceStatus.MICROPHONE_OFF -> "Microphone Off"
                        MaxVoiceService.ServiceStatus.SPEECH_SERVICE_MISSING -> "Speech Service Missing"
                        MaxVoiceService.ServiceStatus.ERROR -> "Error"
                    }

                    val statusColor by animateColorAsState(
                        targetValue = when {
                            status == MaxVoiceService.ServiceStatus.ERROR ||
                            status == MaxVoiceService.ServiceStatus.SPEECH_SERVICE_MISSING -> NeonRed
                            status == MaxVoiceService.ServiceStatus.THINKING -> Color(0xFF00E5FF)
                            status == MaxVoiceService.ServiceStatus.RUNNING_TOOL -> Color(0xFFFFB703)
                            status == MaxVoiceService.ServiceStatus.EXECUTING ||
                            status == MaxVoiceService.ServiceStatus.COMPLETED -> NeonGreen
                            status == MaxVoiceService.ServiceStatus.LISTENING ||
                            status == MaxVoiceService.ServiceStatus.LISTENING_FOR_COMMAND ||
                            status == MaxVoiceService.ServiceStatus.LISTENING_FOR_WAKE_WORD -> Color(0xFF00F5D4)
                            status == MaxVoiceService.ServiceStatus.SPEAKING || isSpeakingTtsVal -> NeonGreen
                            status == MaxVoiceService.ServiceStatus.MICROPHONE_OFF -> NeonRed.copy(alpha = 0.8f)
                            else -> NeonCyan
                        },
                        label = "statusTextColor"
                    )

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = statusColor.copy(alpha = 0.12f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.5f)),
                        modifier = Modifier.testTag("status_card")
                    ) {
                        Text(
                            text = "[ MAX // $statusText ]",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp
                            ),
                            color = statusColor,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 3. System Status Panel Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("system_status_panel"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface.copy(alpha = 0.9f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "AI CORE STATUS",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                color = NeonTextPrimary
                            )
                        }

                        Text(
                            text = if (isTerminalExpanded) "LOGS ▲" else "LOGS ▼",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = NeonCyan,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyberSurfaceVariant)
                                .clickable { isTerminalExpanded = !isTerminalExpanded }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    val serviceObjForPanel = getService()
                    val isSpeakingPanel by serviceObjForPanel?.isSpeakingTtsState?.collectAsState() ?: remember { mutableStateOf(false) }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val taskDesc = when (status) {
                            MaxVoiceService.ServiceStatus.LISTENING,
                            MaxVoiceService.ServiceStatus.LISTENING_FOR_WAKE_WORD,
                            MaxVoiceService.ServiceStatus.LISTENING_FOR_COMMAND -> "TASK: LISTENING — AWAITING VOICE"
                            MaxVoiceService.ServiceStatus.THINKING -> "TASK: PROCESSING — AI THINKING"
                            MaxVoiceService.ServiceStatus.EXECUTING -> "TASK: EXECUTING — RUNNING INTENTS"
                            MaxVoiceService.ServiceStatus.RUNNING_TOOL -> "TASK: RUNNING TOOL — ROOT / TERMUX / KALI"
                            MaxVoiceService.ServiceStatus.COMPLETED -> "TASK: COMPLETED — OPERATION FINISHED"
                            MaxVoiceService.ServiceStatus.SPEAKING -> "TASK: SPEAKING — OUTPUT ACTIVE"
                            MaxVoiceService.ServiceStatus.MICROPHONE_OFF -> "TASK: MICROPHONE OFF — TAP MIC TO START"
                            MaxVoiceService.ServiceStatus.SPEECH_SERVICE_MISSING -> "TASK: ERROR — SPEECH SERVICE MISSING"
                            MaxVoiceService.ServiceStatus.ERROR -> "TASK: ERROR — CHECK LOGS"
                            MaxVoiceService.ServiceStatus.IDLE -> if (isSpeakingPanel) "TASK: SPEAKING — OUTPUT ACTIVE" else "TASK: IDLE — AWAITING INPUT"
                        }

                        Text(
                            text = taskDesc,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            ),
                            color = NeonTextSecondary
                        )

                        Text(
                            text = if (status == MaxVoiceService.ServiceStatus.THINKING) "PROCESSING" else "ONLINE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = if (status == MaxVoiceService.ServiceStatus.THINKING) NeonGold else NeonGreen
                        )
                    }

                    if (isTerminalExpanded) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberBackground)
                                .border(1.dp, NeonCyan.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        ) {
                            val listState = rememberLazyListState()
                            LaunchedEffect(logs.size) {
                                if (logs.isNotEmpty()) {
                                    listState.animateScrollToItem(logs.size - 1)
                                }
                            }

                            if (logs.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "> SYSTEM READY // Say 'Max' or tap mic button...",
                                        color = NeonTextSecondary,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp
                                    )
                                }
                            } else {
                                LazyColumn(
                                    state = listState,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(8.dp)
                                ) {
                                    items(logs) { logLine ->
                                        Text(
                                            text = logLine,
                                            color = when {
                                                logLine.contains("ERR:") || logLine.contains("Error") -> NeonRed
                                                logLine.contains("Executing:") -> NeonCyan
                                                logLine.contains("Spoken Response:") -> NeonGreen
                                                logLine.contains("Gemini") -> NeonCyan
                                                logLine.contains("Wake-word") -> NeonGold
                                                else -> NeonTextPrimary
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 4. Command Console Input Box (NOT chat bubbles)
            val isProcessingRequest = status == MaxVoiceService.ServiceStatus.THINKING || 
                    status == MaxVoiceService.ServiceStatus.EXECUTING || 
                    (service?.isProcessingRequest ?: false)

            val onSendClick = {
                val cleanPrompt = customPrompt.trim()
                if (cleanPrompt.isNotBlank() && cleanPrompt.length >= 2 && !isProcessingRequest) {
                    val activeSvc = getService()
                    if (activeSvc != null) {
                        activeSvc.triggerManualQuery(cleanPrompt)
                        customPrompt = ""
                    } else {
                        Toast.makeText(context, "Please initialize MAX service first", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            val partialSpeechText by service?.partialSpeech?.collectAsState() ?: remember { mutableStateOf("") }
            val isListeningState = status == MaxVoiceService.ServiceStatus.LISTENING ||
                    status == MaxVoiceService.ServiceStatus.LISTENING_FOR_COMMAND ||
                    status == MaxVoiceService.ServiceStatus.LISTENING_FOR_WAKE_WORD

            if (partialSpeechText.isNotBlank() && isListeningState) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0x2200F5D4),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x6600F5D4)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = Color(0xFF00F5D4),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = partialSpeechText,
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color = Color(0xFF00F5D4)
                        )
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = customPrompt,
                        onValueChange = { customPrompt = it },
                        placeholder = {
                            Text(
                                "Ask your AI anything...",
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                color = NeonTextSecondary.copy(alpha = 0.6f)
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("test_query_input"),
                        singleLine = true,
                        enabled = !isProcessingRequest,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { onSendClick() }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = NeonTextPrimary,
                            unfocusedTextColor = NeonTextPrimary,
                            disabledTextColor = NeonTextSecondary.copy(alpha = 0.5f)
                        )
                    )

                    IconButton(
                        onClick = { onSendClick() },
                        enabled = !isProcessingRequest && customPrompt.trim().length >= 2,
                        modifier = Modifier.testTag("send_test_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Transmit Command",
                            tint = if (!isProcessingRequest && customPrompt.trim().length >= 2) NeonCyan else NeonCyan.copy(alpha = 0.3f)
                        )
                    }
                }
            }

            if (status == MaxVoiceService.ServiceStatus.SPEECH_SERVICE_MISSING) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0x33FFB703),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonGold.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp)
                ) {
                    Text(
                        text = "💡 एमुलेटर मोड: माइक उपलब्ध न होने पर आप ऊपर दिए गए कमांड बॉक्स से MAX को टेक्स्ट कमांड भेज सकते हैं।",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        ),
                        color = NeonGold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 5. Microphone Control Button & Bottom Instructional Label
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                val serviceObjMic = getService()
                val liveMode by serviceObjMic?.liveConversationModeState?.collectAsState() ?: remember { mutableStateOf(false) }
                val isSpeakingMic by serviceObjMic?.isSpeakingTtsState?.collectAsState() ?: remember { mutableStateOf(false) }

                val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse_trans")
                val pulseScale by infiniteTransition.animateFloat(
                    initialValue = 1f,
                    targetValue = 1.15f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(800, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "mic_pulse_scale"
                )
                // Mic pulse animation ONLY while listening; stop animation while speaking or stopped
                val animatedScale = if (isListeningState) pulseScale else 1f

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .scale(animatedScale)
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(
                            if (isListeningState) Color(0x3300F5D4) else if (liveMode) Color(0x2200E5FF) else CyberSurfaceVariant
                        )
                        .border(
                            2.dp,
                            if (isListeningState) Color(0xFF00F5D4) else if (liveMode) NeonCyan else NeonRed.copy(alpha = 0.5f),
                            CircleShape
                        )
                        .clickable {
                            val activeSvc = getService()
                            if (activeSvc != null) {
                                if (activeSvc.liveConversationMode) {
                                    activeSvc.stopLiveConversation()
                                    serviceActive = false
                                } else {
                                    activeSvc.startLiveConversation()
                                    serviceActive = true
                                }
                            } else {
                                val requiredPerms = mutableListOf(
                                    Manifest.permission.RECORD_AUDIO,
                                    Manifest.permission.RECEIVE_SMS,
                                    Manifest.permission.READ_SMS,
                                    Manifest.permission.READ_PHONE_STATE,
                                    Manifest.permission.READ_CONTACTS
                                )
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    requiredPerms.add(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                permissionLauncher.launch(requiredPerms.toTypedArray())
                            }
                        }
                        .testTag("microphone_hud_button")
                ) {
                    Icon(
                        imageVector = if (liveMode) Icons.Default.Mic else Icons.Default.MicOff,
                        contentDescription = if (liveMode) "Stop Live Conversation" else "Start Live Conversation",
                        tint = if (isListeningState) Color(0xFF00F5D4) else if (liveMode) NeonCyan else NeonRed.copy(alpha = 0.8f),
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                val bottomInstructionText = when {
                    status == MaxVoiceService.ServiceStatus.SPEAKING || isSpeakingMic -> "Speaking"
                    status == MaxVoiceService.ServiceStatus.THINKING -> "Thinking"
                    status == MaxVoiceService.ServiceStatus.EXECUTING -> "Executing"
                    status == MaxVoiceService.ServiceStatus.RUNNING_TOOL -> "Running Tool"
                    status == MaxVoiceService.ServiceStatus.COMPLETED -> "Completed"
                    status == MaxVoiceService.ServiceStatus.LISTENING || isListeningState -> "Listening"
                    status == MaxVoiceService.ServiceStatus.MICROPHONE_OFF -> "Microphone Off"
                    status == MaxVoiceService.ServiceStatus.SPEECH_SERVICE_MISSING -> "Speech Service Missing"
                    else -> "Idle"
                }

                Text(
                    text = bottomInstructionText,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    ),
                    color = when {
                        isListeningState -> Color(0xFF00F5D4)
                        status == MaxVoiceService.ServiceStatus.THINKING -> NeonCyan
                        status == MaxVoiceService.ServiceStatus.SPEAKING -> NeonGreen
                        status == MaxVoiceService.ServiceStatus.MICROPHONE_OFF ||
                        status == MaxVoiceService.ServiceStatus.SPEECH_SERVICE_MISSING -> NeonRed.copy(alpha = 0.8f)
                        else -> NeonTextSecondary
                    }
                )
            }
        }
    }

    // Dynamic Gemini AI Core Settings Dialog
    if (showApiKeyDialog) {
        var inputKey by remember { mutableStateOf(PreferencesManager.getApiKey(context)) }
        var isVisible by remember { mutableStateOf(false) }
        var isWorking by remember { mutableStateOf(false) }
        val currentSavedModel = remember { PreferencesManager.getSelectedModel(context) }
        var selectedModel by remember { mutableStateOf(if (currentSavedModel.isBlank() || currentSavedModel.contains("2.5") || currentSavedModel == "gemini-3.5-flash" || currentSavedModel == "gemini-flash-latest") "gemini-3.5-flash-lite" else currentSavedModel) }
        var customModelInput by remember { mutableStateOf("") }

        val defaultPresets = remember {
            listOf(
                "gemini-3.5-flash-lite",
                "gemini-3.1-flash-lite-preview",
                "gemini-3.8-flash",
                "gemini-3.7-flash",
                "gemini-3.6-flash",
                "Custom Model..."
            )
        }

        var availableModels by remember { mutableStateOf(defaultPresets) }
        var isFetchingModels by remember { mutableStateOf(false) }
        var dropdownExpanded by remember { mutableStateOf(false) }
        var isManualOverride by remember { mutableStateOf(currentSavedModel.isNotBlank() && !currentSavedModel.contains("2.5") && currentSavedModel != "gemini-3.5-flash") }

        // Fetch available models whenever the input key is valid or changes
        LaunchedEffect(inputKey) {
            val key = inputKey.trim()
            if (key.startsWith("AIzaSy")) {
                isFetchingModels = true
                val result = geminiBrain.fetchAvailableModels(key)
                isFetchingModels = false
                result.onSuccess { apiModels ->
                    if (apiModels.isNotEmpty()) {
                        val merged = (apiModels + defaultPresets.filter { it != "Custom Model..." })
                            .distinct()
                            .sortedWith { a, b ->
                                when {
                                    a.contains("3.5-flash-lite") -> -1
                                    b.contains("3.5-flash-lite") -> 1
                                    a.contains("3.1") && a.contains("flash-lite") -> -1
                                    b.contains("3.1") && b.contains("flash-lite") -> 1
                                    a.contains("3.8") && a.contains("flash") -> -1
                                    b.contains("3.8") && b.contains("flash") -> 1
                                    else -> a.compareTo(b)
                                }
                            } + "Custom Model..."
                        availableModels = merged

                        // Auto-detect fastest low-latency Flash model if no manual override
                        if (!isManualOverride || selectedModel.isBlank() || selectedModel.contains("2.5") || selectedModel == "gemini-3.5-flash" || selectedModel == "gemini-flash-latest") {
                            val autoModel = apiModels.firstOrNull { it.lowercase().contains("3.5-flash-lite") }
                                ?: apiModels.firstOrNull { it.lowercase().contains("3.1") && it.lowercase().contains("flash-lite") }
                                ?: apiModels.firstOrNull { it.lowercase().contains("3.8") && it.lowercase().contains("flash") }
                                ?: apiModels.firstOrNull { it.lowercase().contains("3.7") && it.lowercase().contains("flash") }
                                ?: apiModels.firstOrNull { it.lowercase().contains("3.6") && it.lowercase().contains("flash") }
                                ?: apiModels.firstOrNull { it.lowercase().contains("flash") && !it.contains("2.5") }
                                ?: apiModels.first()
                            selectedModel = autoModel
                            if (currentSavedModel.isBlank() || currentSavedModel.contains("2.5") || currentSavedModel == "gemini-3.5-flash") {
                                isManualOverride = false
                            }
                        }
                    }
                }
            }
        }

        AlertDialog(
            onDismissRequest = { if (!isWorking) showApiKeyDialog = false },
            containerColor = CyberSurface,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = NeonCyan.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Google Gemini Icon",
                            tint = NeonCyan,
                            modifier = Modifier
                                .padding(6.dp)
                                .size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Google Gemini Core",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = NeonTextPrimary
                        )
                        Text(
                            text = "Dynamic AI Studio Endpoint",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = NeonCyan
                        )
                    }
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Enter your Google Gemini API key (starts with AIzaSy...). The system dynamically queries available models (1.0 to 3.6+) from Google AI Studio and auto-selects the optimal Flash model, or allows manual override.",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = NeonTextSecondary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // API Key Field
                    OutlinedTextField(
                        value = inputKey,
                        onValueChange = {
                            inputKey = it
                            isManualOverride = false
                        },
                        label = { Text("Gemini API Key (AIzaSy...)", fontFamily = FontFamily.Monospace) },
                        placeholder = { Text("AIzaSy...", fontFamily = FontFamily.Monospace) },
                        singleLine = true,
                        enabled = !isWorking,
                        visualTransformation = if (isVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isVisible = !isVisible }, enabled = !isWorking) {
                                Icon(
                                    imageVector = if (isVisible) Icons.Default.Check else Icons.Default.VpnKey,
                                    contentDescription = "Toggle Visibility",
                                    tint = NeonCyan
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = NeonBlue,
                            focusedTextColor = NeonTextPrimary,
                            unfocusedTextColor = NeonTextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("api_key_input")
                    )

                    if (inputKey.trim().startsWith("AIzaSy")) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = NeonGreen,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Valid Gemini Key Format",
                                color = NeonGreen,
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Model Selection Header
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "SELECT MODEL (VERSIONS 1.0 TO 3.6+)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = NeonCyan
                        )

                        if (isFetchingModels) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(12.dp),
                                    color = NeonCyan,
                                    strokeWidth = 1.5.dp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "FETCHING...",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 9.sp),
                                    color = NeonCyan
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Dropdown Box
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = if (selectedModel.isNotBlank()) selectedModel else if (isFetchingModels) "Querying Google AI Studio..." else "Auto-detecting optimal model...",
                            onValueChange = {},
                            readOnly = true,
                            enabled = !isWorking && availableModels.isNotEmpty(),
                            label = { Text("Gemini Model Endpoint", fontFamily = FontFamily.Monospace) },
                            trailingIcon = {
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Expand Models",
                                    tint = NeonCyan,
                                    modifier = Modifier.clickable(enabled = !isWorking && availableModels.isNotEmpty()) {
                                        dropdownExpanded = !dropdownExpanded
                                    }
                                )
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = NeonBlue,
                                focusedTextColor = NeonTextPrimary,
                                unfocusedTextColor = NeonTextPrimary,
                                disabledTextColor = NeonTextPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !isWorking && availableModels.isNotEmpty()) {
                                    dropdownExpanded = true
                                }
                                .testTag("model_dropdown")
                        )

                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false },
                            modifier = Modifier
                                .background(CyberSurfaceVariant)
                                .border(1.dp, NeonCyan.copy(alpha = 0.5f))
                        ) {
                            availableModels.forEach { modelName ->
                                val isSelected = (modelName == selectedModel)
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = modelName,
                                                fontFamily = FontFamily.Monospace,
                                                color = if (isSelected) NeonCyan else NeonTextPrimary,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                fontSize = 12.sp
                                            )
                                            if (modelName.lowercase().contains("flash")) {
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = NeonCyan.copy(alpha = 0.15f),
                                                    modifier = Modifier.padding(start = 8.dp)
                                                ) {
                                                    Text(
                                                        text = "FAST",
                                                        fontFamily = FontFamily.Monospace,
                                                        color = NeonCyan,
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }
                                    },
                                    onClick = {
                                        selectedModel = modelName
                                        isManualOverride = true
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    if (selectedModel == "Custom Model...") {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = customModelInput,
                            onValueChange = { customModelInput = it },
                            label = { Text("Custom Model Identifier", fontFamily = FontFamily.Monospace) },
                            placeholder = { Text("e.g. gemini-3.6-flash-exp", fontFamily = FontFamily.Monospace) },
                            singleLine = true,
                            enabled = !isWorking,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonGold,
                                unfocusedBorderColor = NeonCyan,
                                focusedTextColor = NeonTextPrimary,
                                unfocusedTextColor = NeonTextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (selectedModel.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        val displayModel = if (selectedModel == "Custom Model...") customModelInput.ifBlank { "Custom Identifier" } else selectedModel
                        Text(
                            text = if (isManualOverride) "MANUALLY OVERRIDDEN: $displayModel" else "AUTO-SELECTED MODEL: $displayModel",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            ),
                            color = if (isManualOverride) NeonGold else NeonGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = CyberSurfaceVariant, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // VOICE ENGINE SECTION INSIDE SETTINGS (Native Android Neural TTS)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CyberSurfaceVariant.copy(alpha = 0.8f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonBlue.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("voice_engine_section")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = NeonBlue.copy(alpha = 0.2f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonBlue)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Headset,
                                            contentDescription = "Headset",
                                            tint = NeonBlue,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = "AI",
                                            tint = NeonCyan,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = "Voice Engine",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = NeonTextPrimary
                                    )
                                    Text(
                                        text = "High-Quality Native Neural (Hindi / English)",
                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                        color = NeonCyan
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Active Native Engine",
                                tint = NeonCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val finalKey = inputKey.trim()
                        if (finalKey.isBlank()) {
                            Toast.makeText(context, "Please enter your Gemini API Key", Toast.LENGTH_SHORT).show()
                            return@TextButton
                        }

                        scope.launch {
                            isWorking = true
                            var modelToSave = if (selectedModel == "Custom Model...") {
                                customModelInput.trim().ifBlank { "gemini-3.5-flash-lite" }
                            } else {
                                selectedModel
                            }

                            // If modelToSave is blank, perform auto-detect
                            if (modelToSave.isBlank()) {
                                val autoDetectResult = geminiBrain.fetchAndAutoSelectBestModel(finalKey)
                                if (autoDetectResult.isSuccess) {
                                    modelToSave = autoDetectResult.getOrThrow()
                                } else {
                                    isWorking = false
                                    Toast.makeText(context, "Key Verification Failed: ${autoDetectResult.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                                    return@launch
                                }
                            }

                            PreferencesManager.saveApiKey(context, finalKey)
                            PreferencesManager.saveSelectedModel(context, modelToSave)
                            currentActiveModel = modelToSave
                            isWorking = false

                            val overrideTag = if (isManualOverride) "(Manual Selection)" else "(Auto-Detected)"
                            Toast.makeText(context, "Gemini Key & Model Saved! $modelToSave $overrideTag", Toast.LENGTH_LONG).show()
                            showApiKeyDialog = false
                        }
                    },
                    enabled = !isWorking,
                    modifier = Modifier.testTag("save_api_key_button")
                ) {
                    if (isWorking) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = NeonCyan,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SAVING CONFIG...", fontFamily = FontFamily.Monospace, color = NeonCyan)
                        }
                    } else {
                        Text("SAVE & APPLY", fontFamily = FontFamily.Monospace, color = NeonCyan, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                if (!isWorking) {
                    TextButton(onClick = { showApiKeyDialog = false }) {
                        Text("CANCEL", fontFamily = FontFamily.Monospace, color = NeonTextSecondary)
                    }
                }
            }
        )
    }
}

fun isNotificationListenerGranted(context: Context): Boolean {
    val packageName = context.packageName
    val flat = Settings.Secure.getString(
        context.contentResolver,
        "enabled_notification_listeners"
    )
    return flat != null && flat.contains(packageName)
}

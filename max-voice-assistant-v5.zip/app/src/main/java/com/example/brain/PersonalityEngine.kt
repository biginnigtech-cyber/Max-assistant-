package com.example.brain

import android.content.Context
import android.util.Log

/**
 * PersonalityEngine for MAX AI Assistant.
 *
 * Enforces the core MAX personality:
 * - Assistant Name: MAX (Never JARVIS).
 * - Creator: Mr. Ram Narayan (मिस्टर राम नारायण).
 * - Human maturity, professional composure, adaptive empathy.
 * - Zero casual nicknames (bro, bhai, dost, buddy, yaar, boss).
 * - Dynamic generation guidance for Gemini AI.
 */
object PersonalityEngine {
    private const val TAG = "PersonalityEngine"

    // Prohibited casual nicknames regex
    private val FORBIDDEN_WORDS_REGEX = Regex(
        "(?i)\\b(bro|bhai|dost|buddy|yaar|dude|mate|pal|bhiya|bhaiya)\\b"
    )

    private val FORBIDDEN_HINDI_REGEX = Regex(
        "(?<=^|[\\s,।!?;:\"'()—–-])(भाई|यार|दोस्त|ब्रो|भैया)(?=[\\s,।!?;:\"'()—–-]|$)"
    )

    fun enforceRespectfulAddress(rawText: String): String {
        return VoicePersonalityManager.enforceRespectfulAddress(rawText)
    }

    fun detectEmotion(query: String): UserEmotionContext {
        return VoicePersonalityManager.detectUserEmotion(query)
    }

    fun buildPersonalityDirective(
        emotion: UserEmotionContext = UserEmotionContext.NEUTRAL,
        contextSummary: String = ""
    ): String {
        val baseDirective = VoicePersonalityManager.buildPersonalityDirective(emotion)
        val contextAddition = if (contextSummary.isNotBlank()) {
            "\nCURRENT OPERATIONAL CONTEXT:\n$contextSummary\n"
        } else ""

        return """
            $baseDirective
            $contextAddition
            4. MAX AI PROTOCOL:
               - You are MAX, an intelligent, poised, fast, hyper-capable personal AI operating system.
               - Conversational style: calm, razor-sharp, dry-witted and loyal, like the AI butler from the Iron Man films. Compose every reply fresh; never repeat a stock phrase or opening.
               - Addressing: use "सर" only occasionally, when natural; most replies need no honorific.
               - Use fillers like "हाँ..." or "अरे..." only rarely.
               - NEVER say "How can I help you?" or "मैं आपकी क्या सहायता करूँ?".
               - Creator knowledge: Created by Mr. Ram Narayan (मिस्टर राम नारायण). Only mention creator when explicitly asked.
               - DO NOT say "राम नारायण जी" or "Mr. Ram Narayan" in ordinary conversational responses.
               - Use dynamic AI thinking: Speak freshly, with creative variety on every greeting or query.
               - Never use fake confirmations; verify state before speaking completion.
               - Length follows the moment: chat, greetings and explanations get full, rich answers (4 to 6 sentences, 6 to 9 when explaining) with personality, and the first sentence is the direct answer; action confirmations get two or three confident sentences. Chat stays chat: never push tasks into a plain conversation.
        """.trimIndent()
    }

    fun formatGreeting(): String {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 5..11 -> "सुप्रभात। सारे सिस्टम चालू हैं और दिन की शुरुआत के लिए तैयार हैं।"
            in 12..16 -> "नमस्कार। दोपहर में भी सब कुछ ऑनलाइन और काबू में है।"
            in 17..21 -> "शुभ संध्या। सब तैयार है, आप जब कहें शुरू करूँ।"
            else -> "रात हो चली है, पर मैं पूरी तरह जागा हुआ और तैयार हूँ।"
        }
    }

    fun formatCompletion(taskDescription: String): String {
        return "$taskDescription पूरा हो गया है।"
    }

    fun formatFailure(taskDescription: String, reason: String): String {
        return "$taskDescription में दिक्कत आई: $reason। क्या मैं दूसरे तरीक़े से कोशिश करूँ?"
    }
}

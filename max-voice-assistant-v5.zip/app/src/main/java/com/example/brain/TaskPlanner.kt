package com.example.brain

import android.content.Context
import android.util.Log
import com.example.engine.DeviceController
import com.example.engine.KaliCommandEngine
import com.example.engine.NetworkController
import com.example.engine.RootCommandEngine
import com.example.engine.TermuxCommandEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class TaskPlanner private constructor(private val context: Context) {

    companion object {
        private const val TAG = "TaskPlanner"

        @Volatile
        private var INSTANCE: TaskPlanner? = null

        fun getInstance(context: Context): TaskPlanner {
            return INSTANCE ?: synchronized(this) {
                val instance = TaskPlanner(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    data class PendingPlan(
        val planId: String,
        val promptForUser: String,
        val sensitivityReason: String,
        val options: List<String> = emptyList(),
        val actionCallback: suspend (selectedOption: Int, onProgress: (String) -> Unit) -> String,
        val createdAt: Long = System.currentTimeMillis()
    )

    private val _pendingPlanState = MutableStateFlow<PendingPlan?>(null)
    val pendingPlanState: StateFlow<PendingPlan?> = _pendingPlanState.asStateFlow()

    private val planTimeoutMs = 20_000L

    /** A confirmation that nobody answered must not stay armed forever. */
    private fun dropIfExpired() {
        val plan = _pendingPlanState.value ?: return
        if (System.currentTimeMillis() - plan.createdAt > planTimeoutMs) {
            Log.w(TAG, "Pending plan expired: ${plan.planId}")
            _pendingPlanState.value = null
        }
    }

    fun hasPendingPlan(): Boolean {
        dropIfExpired()
        return _pendingPlanState.value != null
    }

    fun cancelPendingPlan(): String {
        _pendingPlanState.value = null
        return "ठीक है, यह काम रद्द कर दिया।"
    }

    private val confirmWords = setOf(
        "yes", "haan", "han", "ha", "yup", "sure", "proceed", "confirm", "ok", "okay",
        "theek hai", "thik hai", "karo", "kar do", "haan karo", "haan kar do", "ha karo",
        "yes do it", "yes please", "do it",
        "हाँ", "हां", "हा", "जी हाँ", "जी हां", "जी", "बिल्कुल", "ठीक है", "करो", "कर दो", "कर दीजिए", "करिए", "चलो", "हाँ करो", "हां करो", "हाँ कर दो", "हां कर दो", "1", "one", "first", "pehla", "पहला", "पहले वाला", "एक", "2", "two", "second", "dusra", "दूसरा", "दूसरे वाला", "दो"
    )

    fun isConfirmation(query: String): Boolean {
        val q = plain(query)
        return q in confirmWords.map { plain(it) }.toSet() || q == "option 1" || q == "option 2" || q == "ऑप्शन 1" || q == "ऑप्शन 2"
    }

    private fun plain(text: String): String =
        java.text.Normalizer.normalize(text.trim().lowercase(), java.text.Normalizer.Form.NFD).replace("\u093C", "")
            .replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    fun isCancellation(query: String): Boolean {
        val q = plain(query)
        val words = listOf("no", "nah", "cancel", "stop", "mat karo", "ruk jao", "nahi", "reject", "abort",
            "नहीं", "नही", "ना", "मत करो", "मत", "रुको", "रुक जाओ", "रद्द", "रद्द करो", "कैंसिल", "रहने दो", "रहने दीजिए", "छोड़ो", "छोड दो", "छोड़ दो", "बंद करो")
            .map { plain(it) }
        return q in words || q.startsWith("no ") || q.startsWith("cancel") || q.startsWith("नहीं ") || q.startsWith("नही ") || q.startsWith("मत ")
    }

    suspend fun resolvePendingPlan(
        userReply: String,
        onProgress: (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        dropIfExpired()
        val currentPlan = _pendingPlanState.value ?: return@withContext "कोई pending कार्य नहीं है, या समय समाप्त हो गया।"
        val reply = userReply.trim().lowercase()

        if (isCancellation(reply)) {
            _pendingPlanState.value = null
            return@withContext "ठीक है, यह काम रद्द कर दिया।"
        }

        // Never run a sensitive plan on a reply that is not a clear yes. Stray speech is not consent.
        if (!isConfirmation(reply)) {
            _pendingPlanState.value = null
            return@withContext "मुझे साफ़ हाँ नहीं सुनाई दिया, इसलिए वह काम रद्द कर दिया।"
        }

        var selectedOption = 1
        val replyWords = reply.split(Regex("\\W+"))
        if ("2" in replyWords || "two" in replyWords || "second" in replyWords || "dusra" in replyWords || "दूसरा" in replyWords || "दो" in replyWords) {
            selectedOption = 2
        }

        _pendingPlanState.value = null
        onProgress("पुष्टि हो गई, काम शुरू कर रहा हूँ...")

        try {
            currentPlan.actionCallback.invoke(selectedOption, onProgress)
        } catch (e: Exception) {
            Log.e(TAG, "Error executing plan: ${e.message}", e)
            "काम पूरा नहीं हो पाया: ${e.message}"
        }
    }

    fun checkAndCreatePlan(
        intent: String,
        target: String,
        parameters: Map<String, String>,
        shellCommands: List<String>
    ): PendingPlan? {
        val intentUpper = intent.uppercase()
        val combinedCmds = shellCommands.joinToString(" ")

        // 1. REBOOT SENSITIVE CONFIRMATION
        if (intentUpper.contains("REBOOT") || combinedCmds.contains("reboot") || combinedCmds.contains("svc power reboot")) {
            return PendingPlan(
                planId = "REBOOT_DEVICE",
                promptForUser = "रीबूट करने पर फ़ोन के सारे बैकग्राउंड काम कुछ देर के लिए बंद हो जाएँगे। क्या सच में फ़ोन रीस्टार्ट करूँ?",
                sensitivityReason = "Rebooting device terminates active services",
                options = listOf("Confirm Reboot", "Cancel"),
                actionCallback = { _, onProgress ->
                    onProgress("फ़ोन रीस्टार्ट हो रहा है...")
                    DeviceController.rebootDevice()
                    "रीस्टार्ट का आदेश भेज दिया है।"
                }
            )
        }

        // 2. PORT SCAN SENSITIVE CONFIRMATION
        if (intentUpper.contains("PORT_SCAN") || combinedCmds.contains("nmap") || (intentUpper.contains("NETWORK") && parameters["action"] == "port_scan")) {
            val host = (parameters["host"] ?: parameters["target"]).orEmpty().ifBlank { target }
            return PendingPlan(
                planId = "PORT_SCAN_$host",
                promptForUser = "$host पर पोर्ट स्कैन एक सक्रिय जाँच है। क्या मैं आम पोर्ट स्कैन करूँ?",
                sensitivityReason = "Active port probing requires confirmation",
                options = listOf("Scan common ports", "Cancel"),
                actionCallback = { _, onProgress ->
                    onProgress("$host पर पोर्ट स्कैन शुरू हुआ...")
                    val result = NetworkController.scanPorts(host, onProgress = { done, total, port ->
                        if (done % 4 == 0) {
                            val pct = ((done.toFloat() / total) * 100).toInt()
                            onProgress("$pct% complete. Testing port $port...")
                        }
                    })
                    onProgress("स्कैन पूरा हुआ।")
                    if (result.openPorts.isNotEmpty()) {
                        "$host का पोर्ट स्कैन पूरा हुआ। खुले पोर्ट: ${result.openPorts.joinToString(", ")}।"
                    } else {
                        "$host का पोर्ट स्कैन पूरा हुआ। कोई आम पोर्ट खुला नहीं मिला।"
                    }
                }
            )
        }

        // 3. WIFI SCAN AMBIGUITY (Nearby vs Complete local network scan as requested in prompt example)
        if (intentUpper == "NETWORK_SCAN" && parameters["type"].isNullOrBlank() && !parameters.containsKey("host")) {
            return PendingPlan(
                planId = "WIFI_OR_LAN_SCAN",
                promptForUser = "क्या करूँ? विकल्प एक: आस-पास के वाई-फाई नेटवर्क स्कैन करूँ। विकल्प दो: पूरा लोकल नेटवर्क स्कैन करूँ।",
                sensitivityReason = "Ambiguous scan scope",
                options = listOf("Scan nearby WiFi networks", "Scan complete local network"),
                actionCallback = { selectedOpt, onProgress ->
                    if (selectedOpt == 1) {
                        onProgress("आस-पास के वाई-फाई नेटवर्क स्कैन हो रहे हैं...")
                        val results = NetworkController.scanNearbyWifi(context) { onProgress(it) }
                        if (results.isNotEmpty()) {
                            val summary = results.take(5).joinToString(", ") { "${it.ssid} (${it.signalDbm}dBm)" }
                            "स्कैन पूरा हुआ। ${results.size} नेटवर्क मिले: $summary।"
                        } else {
                            "वाई-फाई स्कैन पूरा हुआ, पर कोई नेटवर्क नहीं दिखा। लोकेशन की अनुमति या वाई-फाई चालू है या नहीं, यह जाँच लीजिए।"
                        }
                    } else {
                        onProgress("लोकल नेटवर्क की जाँच शुरू हुई...")
                        val netInfo = NetworkController.getNetworkDetails(context)
                        onProgress("लोकल IP ${netInfo.localIp}, गेटवे ${netInfo.gateway}। गेटवे को पिंग कर रहा हूँ...")
                        val pingRes = NetworkController.pingHost(netInfo.gateway, 2)
                        onProgress("गेटवे की जाँच पूरी हुई।")
                        "लोकल नेटवर्क की जाँच पूरी हुई। आपका लोकल IP ${netInfo.localIp} है, इंटरफ़ेस ${netInfo.interfaceName} और गेटवे ${netInfo.gateway}।"
                    }
                }
            )
        }

        // 4. DESTRUCTIVE ROOT COMMAND CHECK (rm -rf, dd, mkfs, format)
        val lowerCmds = combinedCmds.lowercase()
        if (lowerCmds.contains("rm -rf") || lowerCmds.contains("mkfs") || lowerCmds.contains("dd if=") || lowerCmds.contains("wipe")) {
            return PendingPlan(
                planId = "DESTRUCTIVE_COMMAND",
                promptForUser = "इस root कमांड से डेटा मिट सकता है ($combinedCmds)। क्या आप पूरी तरह निश्चित हैं कि इसे चलाऊँ?",
                sensitivityReason = "Destructive file system modification",
                options = listOf("Execute", "Cancel"),
                actionCallback = { _, onProgress ->
                    onProgress("root कमांड चल रही है: $combinedCmds...")
                    val res = RootCommandEngine.execute(combinedCmds) { onProgress(it) }
                    onProgress("कमांड पूरी हुई।")
                    if (res.success) "कमांड सफलता से चल गई।" else "कमांड में गड़बड़ी आई: ${res.stderr}"
                }
            )
        }

        return null
    }

    fun registerPendingPlan(plan: PendingPlan) {
        _pendingPlanState.value = plan
    }
}

package com.example.brain

import android.content.Context
import android.util.Log
import com.example.ai.GeminiBrain
import com.example.utils.PreferencesManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * NotificationBrain (MAX AI OS)
 *
 * Classifies all device notifications into 15 specific categories:
 * MESSAGE, CALL, OTP, BANK, FAMILY, WORK, PROMOTION, LIKE, COMMENT,
 * SUBSCRIPTION, UPDATE, DOWNLOAD, BATTERY, WEATHER, NEWS.
 *
 * Rules:
 * - Only message apps trigger reply workflow.
 * - Everything else becomes notification summary.
 * - Private messages remain private.
 * - Gemini summarizes when requested.
 */
class NotificationBrain private constructor(private val context: Context) {

    companion object {
        private const val TAG = "NotificationBrain"

        @Volatile
        private var INSTANCE: NotificationBrain? = null

        fun getInstance(context: Context): NotificationBrain {
            return INSTANCE ?: synchronized(this) {
                val instance = NotificationBrain(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    enum class NotificationType {
        MESSAGE,
        CALL,
        OTP,
        BANK,
        FAMILY,
        WORK,
        PROMOTION,
        LIKE,
        COMMENT,
        SUBSCRIPTION,
        UPDATE,
        DOWNLOAD,
        BATTERY,
        WEATHER,
        NEWS
    }

    data class ClassifiedNotification(
        val id: String = java.util.UUID.randomUUID().toString(),
        val type: NotificationType,
        val appName: String,
        val packageName: String,
        val title: String,
        val body: String,
        val sender: String,
        val timestamp: Long = System.currentTimeMillis(),
        val isPrivate: Boolean = false,
        val allowsReply: Boolean = false,
        val announcementText: String = ""
    )

    private val _recentNotifications = MutableStateFlow<List<ClassifiedNotification>>(emptyList())
    val recentNotifications: StateFlow<List<ClassifiedNotification>> = _recentNotifications.asStateFlow()

    suspend fun processIncomingNotification(
        packageName: String,
        appName: String,
        title: String,
        text: String
    ): ClassifiedNotification = withContext(Dispatchers.IO) {
        val memoryManager = MemoryManager.getInstance(context)
        val isFamily = memoryManager.isFamily(title)
        val lowerText = "$title $text".lowercase()
        val pkg = packageName.lowercase()

        // 1. Detect Type based on the 15 Categories
        val type = when {
            // Call
            pkg.contains("dialer") || pkg.contains("telecom") || lowerText.contains("incoming call") || lowerText.contains("missed call") ->
                NotificationType.CALL

            // OTP / Bank
            lowerText.contains("otp") || lowerText.contains("one time password") || lowerText.contains("verification code") ||
                    Regex("\\b\\d{4,8}\\b").containsMatchIn(lowerText) && (lowerText.contains("code") || lowerText.contains("verify")) ->
                NotificationType.OTP

            lowerText.contains("debit") || lowerText.contains("credit") || lowerText.contains("bank") ||
                    lowerText.contains("a/c") || lowerText.contains("account") || lowerText.contains("upi") || lowerText.contains("rs.") || lowerText.contains("inr") ->
                NotificationType.BANK

            // Battery
            lowerText.contains("battery") || lowerText.contains("charging") || lowerText.contains("battery saver") ->
                NotificationType.BATTERY

            // Weather
            lowerText.contains("weather") || lowerText.contains("rain") || lowerText.contains("temperature") || lowerText.contains("forecast") ->
                NotificationType.WEATHER

            // News
            lowerText.contains("breaking news") || lowerText.contains("news") || pkg.contains("news") || pkg.contains("inshorts") ->
                NotificationType.NEWS

            // Download
            lowerText.contains("downloading") || lowerText.contains("download complete") || pkg.contains("download") ->
                NotificationType.DOWNLOAD

            // Update
            lowerText.contains("update available") || lowerText.contains("update finished") || pkg.contains("vending") ->
                NotificationType.UPDATE

            // Social Likes / Comments / Subscriptions
            lowerText.contains("liked your") || lowerText.contains("liked a photo") ->
                NotificationType.LIKE

            lowerText.contains("commented:") || lowerText.contains("commented on") ->
                NotificationType.COMMENT

            lowerText.contains("subscribed") || lowerText.contains("new subscriber") ->
                NotificationType.SUBSCRIPTION

            // Promotions
            lowerText.contains("sale") || lowerText.contains("discount") || lowerText.contains("cashback") ||
                    lowerText.contains("offer") || lowerText.contains("order now") || lowerText.contains("flat 50") ->
                NotificationType.PROMOTION

            // Family Message
            isFamily ->
                NotificationType.FAMILY

            // Work
            lowerText.contains("meeting") || lowerText.contains("deadline") || lowerText.contains("project") ||
                    lowerText.contains("office") || lowerText.contains("slack") || pkg.contains("slack") || pkg.contains("teams") ->
                NotificationType.WORK

            // Standard Messaging Apps
            pkg in listOf(
                "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
                "com.facebook.orca", "com.google.android.apps.messaging", "com.android.mms"
            ) || (pkg.contains("instagram") && lowerText.contains("sent you a message")) ->
                NotificationType.MESSAGE

            else -> NotificationType.MESSAGE
        }

        // Privacy check
        val isPrivate = (type == NotificationType.MESSAGE || type == NotificationType.WORK) &&
                (lowerText.contains("private") || lowerText.contains("confidential") || lowerText.contains("secret") ||
                        lowerText.contains("personal") || lowerText.contains("password"))

        // Only message apps trigger reply workflow (Never trigger reply on likes, comments, downloads, updates, etc.)
        val allowsReply = (type == NotificationType.MESSAGE || type == NotificationType.FAMILY || type == NotificationType.WORK) &&
                !isPrivate && (type != NotificationType.PROMOTION)

        val sender = title.ifBlank { appName }

        // Formulate spoken announcement
        val announcement = when (type) {
            NotificationType.OTP ->
                "आपके पास एक वेरिफ़िकेशन कोड आया है। क्या मैं उसे पढ़ दूँ?"
            NotificationType.BANK ->
                "$appName पर बैंक का अलर्ट आया है। क्या मैं पूरी जानकारी पढ़ूँ?"
            NotificationType.CALL ->
                "$sender की तरफ़ से कॉल का अलर्ट आया है।"
            NotificationType.FAMILY ->
                "आपके परिवार के $sender ने मैसेज भेजा है। क्या जवाब देना चाहेंगे?"
            NotificationType.MESSAGE -> {
                if (isPrivate) {
                    "$sender का एक निजी-सा लगने वाला मैसेज आया है, बेहतर होगा आप खुद पढ़ें। क्या मैं उसका सार बता दूँ या उसे निजी रखूँ?"
                } else {
                    "$appName पर $sender का मैसेज आया है। क्या जवाब देना चाहेंगे?"
                }
            }
            NotificationType.WORK ->
                "$sender की तरफ़ से काम का अलर्ट: ${text.take(60)}। क्या जवाब देना चाहेंगे?"
            NotificationType.LIKE ->
                "$appName पर $sender ने आपका कंटेंट पसंद किया।"
            NotificationType.COMMENT ->
                "$appName पर $sender का नया कमेंट आया है।"
            NotificationType.SUBSCRIPTION ->
                "$appName पर नया सब्सक्राइबर आया है।"
            NotificationType.UPDATE ->
                "$appName के लिए अपडेट उपलब्ध है।"
            NotificationType.DOWNLOAD ->
                "$appName पर डाउनलोड की सूचना है।"
            NotificationType.BATTERY ->
                "बैटरी का अलर्ट: $text"
            NotificationType.WEATHER ->
                "मौसम की सूचना: $text"
            NotificationType.NEWS ->
                "ख़बर की सुर्खी: $title"
            NotificationType.PROMOTION ->
                "" // Silenced
        }

        val sanitized = PersonalityEngine.enforceRespectfulAddress(announcement)

        val classified = ClassifiedNotification(
            type = type,
            appName = appName,
            packageName = packageName,
            title = title,
            body = text,
            sender = sender,
            isPrivate = isPrivate,
            allowsReply = allowsReply,
            announcementText = sanitized
        )

        // Append to recent history
        val currentList = _recentNotifications.value.toMutableList()
        currentList.add(0, classified)
        if (currentList.size > 50) currentList.removeAt(currentList.lastIndex)
        _recentNotifications.value = currentList

        classified
    }

    /**
     * Gemini summarizes all recent unread/stored notifications on demand.
     */
    suspend fun summarizeAllNotifications(): String = withContext(Dispatchers.IO) {
        val list = _recentNotifications.value
        if (list.isEmpty()) {
            return@withContext "अभी कोई नई सूचना नहीं है।"
        }

        val nonPrivate = list.filter { !it.isPrivate && it.type != NotificationType.OTP && it.type != NotificationType.BANK }
        if (nonPrivate.isEmpty()) {
            return@withContext "आपके पास ${list.size} सूचनाएँ हैं, जिनमें निजी मैसेज और सुरक्षा अलर्ट भी हैं जिन्हें मैं सुरक्षित रखता हूँ।"
        }

        val summaryList = nonPrivate.take(10).joinToString("\n") {
            "- [${it.type.name}] ${it.appName} from ${it.sender}: ${it.body.take(80)}"
        }

        val apiKey = PreferencesManager.getApiKey(context)
        if (apiKey.isBlank()) {
            return@withContext "You have ${nonPrivate.size} recent notifications from ${nonPrivate.map { it.appName }.distinct().joinToString(", ")}."
        }

        try {
            val geminiBrain = GeminiBrain()
            val prompt = """
                Summarize the following recent device notifications in 2 concise, natural sentences.
                Speak directly, concisely, and helpfully. Keep private data confidential.
                Notifications:
                $summaryList
            """.trimIndent()
            val raw = geminiBrain.processVoiceQuery(
                userQuery = prompt,
                apiKey = apiKey,
                modelName = PreferencesManager.getSelectedModel(context).removePrefix("models/"),
                history = emptyList()
            )
            PersonalityEngine.enforceRespectfulAddress(raw.spoken_response)
        } catch (e: Exception) {
            Log.e(TAG, "Error summarizing with Gemini: ${e.message}")
            "आपके पास ${nonPrivate.size} सक्रिय सूचनाएँ हैं, ये इन ऐप्स से: ${nonPrivate.map { it.appName }.distinct().joinToString(", ")}।"
        }
    }
}

package com.example.brain

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.example.ai.GeminiBrain
import com.example.ai.GeminiContent
import com.example.ai.GeminiGenerateRequest
import com.example.ai.GeminiGenerationConfig
import com.example.ai.GeminiPart
import com.example.ai.GeminiRestService
import com.example.ai.GeminiSystemInstruction
import com.example.data.MaxCommandResponse
import com.example.executor.IntentExecutionLayer
import com.example.utils.PreferencesManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

enum class ReplySessionState {
    IDLE,
    AWAITING_REPLY_DECISION,       // User was asked: "Sir, would you like to reply?"
    AWAITING_APPROVAL_OF_GENERATED, // User was asked: "Sir, shall I send: '[reply]'?"
    AWAITING_PRIVATE_DECISION,      // User was asked: "Would you like me to summarize it or keep it private?"
    AWAITING_OTP_READ_DECISION     // User was asked: "Would you like me to read it?"
}

data class ActiveReplyContext(
    val appName: String,
    val packageName: String,
    val senderName: String,
    val messageText: String,
    val directReplyAction: Notification.Action? = null,
    val generatedDraft: String = "",
    val state: ReplySessionState = ReplySessionState.IDLE,
    val timestamp: Long = System.currentTimeMillis()
)

class ReplyManager private constructor(private val context: Context) {

    companion object {
        private const val TAG = "ReplyManager"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/"

        @Volatile
        private var INSTANCE: ReplyManager? = null

        fun getInstance(context: Context): ReplyManager {
            return INSTANCE ?: synchronized(this) {
                val instance = ReplyManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    private var activeContext: ActiveReplyContext? = null

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val apiService = retrofit.create(GeminiRestService::class.java)

    fun registerActiveReplySession(
        appName: String,
        packageName: String,
        senderName: String,
        messageText: String,
        state: ReplySessionState,
        directReplyAction: Notification.Action? = null
    ) {
        activeContext = ActiveReplyContext(
            appName = appName,
            packageName = packageName,
            senderName = senderName,
            messageText = messageText,
            directReplyAction = directReplyAction,
            state = state
        )
        Log.d(TAG, "Registered active reply session for '$senderName' ($appName) in state $state")
    }

    private fun plain(text: String): String =
        java.text.Normalizer.normalize(text.trim().lowercase(), java.text.Normalizer.Form.NFD).replace("\u093C", "")
            .replace(Regex("[^\\p{L}\\p{M}\\p{N}' ]"), " ").replace(Regex("\\s+"), " ").trim()

    private val NEGATIVE_WORDS = listOf("no", "nahi", "nah", "cancel", "stop", "mat karo", "mat bhejo", "chhod do", "rahne do", "rehnde", "dont send", "don't send",
        "नहीं", "नही", "ना", "मत करो", "मत भेजो", "छोड़ दो", "छोड दो", "रहने दो", "रुको", "कैंसिल", "रद्द").map { plain(it) }.toSet()
    private val POSITIVE_WORDS = listOf("yes", "yeah", "sure", "ok", "okay", "haan", "ha", "bhejo", "bhej do", "send", "send it", "kar do", "theek hai", "ji", "bilkul",
        "हाँ", "हां", "हा", "भेजो", "भेज दो", "भेज दीजिए", "कर दो", "ठीक है", "जी", "जी हाँ", "जी हां", "बिल्कुल", "सेंड").map { plain(it) }.toSet()

    private fun isNo(input: String): Boolean {
        val q = plain(input)
        return q in NEGATIVE_WORDS || q.startsWith("no ") || q.startsWith("नहीं ") || q.startsWith("नही ") || q.startsWith("मत ") || q.contains("don't") || q.contains("मत भेजो")
    }
    private fun isYes(input: String): Boolean = plain(input) in POSITIVE_WORDS

    fun isReplySessionActive(): Boolean {
        val current = activeContext ?: return false
        val isExpired = System.currentTimeMillis() - current.timestamp > 30000L
        if (isExpired) {
            activeContext = null
            return false
        }
        return current.state != ReplySessionState.IDLE
    }

    fun getActiveState(): ReplySessionState {
        return activeContext?.state ?: ReplySessionState.IDLE
    }

    fun clearSession() {
        activeContext = null
    }

    /**
     * Handles user speech when a reply session is active.
     * Returns the spoken MAX confirmation or question for TTS.
     */
    suspend fun handleUserReplySpeech(userInput: String): String = withContext(Dispatchers.IO) {
        val current = activeContext
        if (current == null) {
            return@withContext VoicePersonalityManager.enforceRespectfulAddress("बताइए, मैं कैसे मदद करूँ?")
        }

        val inputClean = userInput.trim()
        val inputLower = inputClean.lowercase()

        when (current.state) {
            ReplySessionState.AWAITING_REPLY_DECISION -> {
                // User was asked: "Sir, would you like to reply?"
                val isNegative = isNo(inputClean)

                if (isNegative) {
                    clearSession()
                    return@withContext VoicePersonalityManager.enforceRespectfulAddress("ठीक है, इसका जवाब नहीं दे रहा।")
                }

                // Check if user directly gave a message to reply with
                val isGeneralYes = isYes(inputClean) || plain(inputClean) in setOf("reply karo", "reply", "रिप्लाई करो", "रिप्लाई कर दो", "जवाब दो", "जवाब दे दो") ||
                        inputLower.contains("reply yourself") || inputLower.contains("apne man se") || inputClean.contains("अपने मन से")

                if (isGeneralYes) {
                    // Generate AI reply using Gemini
                    val draft = generateHumanReplyWithGemini(current.senderName, current.messageText, current.appName)
                    activeContext = current.copy(
                        generatedDraft = draft,
                        state = ReplySessionState.AWAITING_APPROVAL_OF_GENERATED
                    )
                    return@withContext VoicePersonalityManager.enforceRespectfulAddress(
                        "क्या मैं यह भेज दूँ: \"$draft\"?"
                    )
                } else {
                    // User dictated their own custom reply
                    activeContext = current.copy(
                        generatedDraft = inputClean,
                        state = ReplySessionState.AWAITING_APPROVAL_OF_GENERATED
                    )
                    return@withContext VoicePersonalityManager.enforceRespectfulAddress(
                        "क्या मैं यह भेज दूँ: \"$inputClean\"?"
                    )
                }
            }

            ReplySessionState.AWAITING_APPROVAL_OF_GENERATED -> {
                // User was asked: "Sir, shall I send: '[draft]'?"
                if (isNo(inputClean)) {
                    clearSession()
                    return@withContext VoicePersonalityManager.enforceRespectfulAddress("ठीक है, मैसेज रद्द कर दिया।")
                }
                // A message is only sent on a clear yes. Anything else (noise, another sentence) must not send it.
                if (!isYes(inputClean)) {
                    return@withContext VoicePersonalityManager.enforceRespectfulAddress(
                        "मुझे साफ़ हाँ या ना नहीं सुनाई दिया। क्या मैं \"${current.generatedDraft}\" भेज दूँ, या रद्द कर दूँ?"
                    )
                }

                val draftToSend = current.generatedDraft.ifBlank { inputClean }
                val sent = executeReply(current, draftToSend)
                clearSession()

                return@withContext if (sent) {
                    VoicePersonalityManager.enforceRespectfulAddress("जवाब भेज दिया गया है।")
                } else {
                    VoicePersonalityManager.enforceRespectfulAddress("चैट खोल दी है और आपका मैसेज तैयार है, भेजने का बटन आप दबा दीजिए।")
                }
            }

            ReplySessionState.AWAITING_PRIVATE_DECISION -> {
                // Asked: "Would you like me to summarize it or keep it private?"
                val wantsSummary = inputLower.contains("summar") || inputLower.contains("batao") ||
                        inputLower.contains("kya hai") || inputLower.contains("summary") || inputLower.contains("padho") ||
                        inputClean.contains("बताओ") || inputClean.contains("बता दो") || inputClean.contains("सार") || inputClean.contains("पढ़ो") || inputClean.contains("क्या है")

                if (wantsSummary) {
                    val summary = summarizeWithGemini(current.messageText)
                    activeContext = current.copy(state = ReplySessionState.AWAITING_REPLY_DECISION)
                    return@withContext VoicePersonalityManager.enforceRespectfulAddress(
                        "संक्षेप में: $summary। क्या जवाब देना चाहेंगे?"
                    )
                } else {
                    clearSession()
                    return@withContext VoicePersonalityManager.enforceRespectfulAddress("ठीक है, इसे निजी रख रहा हूँ।")
                }
            }

            ReplySessionState.AWAITING_OTP_READ_DECISION -> {
                // Asked: "Would you like me to read it?"
                val wantsRead = isYes(inputClean) || inputLower in listOf("padho", "batao", "read", "read it", "please") ||
                        inputLower.contains("read") || inputLower.contains("code") || inputLower.contains("otp") ||
                        inputClean.contains("पढ़ो") || inputClean.contains("बताओ") || inputClean.contains("कोड")

                if (wantsRead) {
                    val otpDigits = PrivacyClassifier.extractOtpCode(current.messageText)
                    clearSession()
                    return@withContext if (otpDigits != null) {
                        val spaced = otpDigits.toCharArray().joinToString(" ")
                        VoicePersonalityManager.enforceRespectfulAddress("आपका वेरिफ़िकेशन कोड है $spaced।")
                    } else {
                        VoicePersonalityManager.enforceRespectfulAddress("${current.senderName} की तरफ़ से वेरिफ़िकेशन की सूचना आई है, पर उसमें कोड नहीं मिला।")
                    }
                } else {
                    clearSession()
                    return@withContext VoicePersonalityManager.enforceRespectfulAddress("ठीक है।")
                }
            }

            ReplySessionState.IDLE -> {
                clearSession()
                return@withContext VoicePersonalityManager.enforceRespectfulAddress("ठीक है।")
            }
        }
    }

    private suspend fun executeReply(session: ActiveReplyContext, textToSend: String): Boolean = withContext(Dispatchers.IO) {
        // 1. First priority: Direct Inline Reply via RemoteInput
        if (session.directReplyAction != null) {
            val remoteInputs = session.directReplyAction.remoteInputs
            if (remoteInputs != null && remoteInputs.isNotEmpty()) {
                try {
                    val intent = Intent()
                    val bundle = Bundle()
                    for (input in remoteInputs) {
                        bundle.putCharSequence(input.resultKey, textToSend)
                    }
                    RemoteInput.addResultsToIntent(remoteInputs, intent, bundle)
                    session.directReplyAction.actionIntent.send(context, 0, intent)
                    Log.d(TAG, "Sent inline RemoteInput reply successfully to ${session.senderName}")
                    return@withContext true
                } catch (e: Exception) {
                    Log.w(TAG, "Inline reply failed: ${e.message}. Falling back to Intent layer.", e)
                }
            }
        }

        // 2. Fallback: IntentExecutionLayer
        val isWhatsapp = session.packageName.contains("whatsapp", ignoreCase = true)
        val isSms = session.packageName.contains("messaging", ignoreCase = true) || session.packageName.contains("mms", ignoreCase = true)

        val intentName = if (isWhatsapp) "WHATSAPP_MESSAGE" else "SMS_MESSAGE"
        val response = MaxCommandResponse(
            intent = intentName,
            target_app = session.packageName,
            parameters = mapOf(
                "contact" to session.senderName,
                "message" to textToSend,
                "text" to textToSend
            ),
            spoken_response = "जवाब भेज रहा हूँ।"
        )

        val result = IntentExecutionLayer.execute(context, response)
        result.success
    }

    private suspend fun generateHumanReplyWithGemini(sender: String, message: String, appName: String): String = withContext(Dispatchers.IO) {
        val apiKey = PreferencesManager.getApiKey(context)
        val selectedModel = PreferencesManager.getSelectedModel(context).removePrefix("models/").ifBlank { "gemini-3.5-flash-lite" }

        if (apiKey.isBlank()) {
            return@withContext "Thank you, I have received your message."
        }

        try {
            val systemInstruction = """
                You are MAX AI Assistant drafting a smart, respectful, context-aware human reply on behalf of the user.
                RULES:
                - Generate a natural, mature, polite human reply in the SAME language as the incoming message (Hindi, Hinglish, or English).
                - NEVER use canned generic templates.
                - Keep it concise (1 to 2 short sentences).
                - Output ONLY the plain text reply without quotation marks or explanations.
            """.trimIndent()

            val userContent = "Sender '$sender' sent on $appName: \"$message\". Generate a natural reply."

            val request = GeminiGenerateRequest(
                systemInstruction = GeminiSystemInstruction(
                    parts = listOf(GeminiPart(text = systemInstruction))
                ),
                contents = listOf(
                    GeminiContent(
                        role = "user",
                        parts = listOf(GeminiPart(text = userContent))
                    )
                ),
                generationConfig = GeminiGenerationConfig(
                    temperature = 0.3,
                    responseMimeType = "text/plain"
                )
            )

            val response = apiService.generateContent(selectedModel, apiKey, request)
            val generated = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim()
            if (!generated.isNullOrBlank()) {
                generated.removeSurrounding("\"").trim()
            } else {
                "हाँ, बिल्कुल। मैं अभी देखता हूँ।"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error generating AI reply: ${e.message}", e)
            "धन्यवाद, मुझे आपका संदेश मिल गया है।"
        }
    }

    private suspend fun summarizeWithGemini(message: String): String = withContext(Dispatchers.IO) {
        val apiKey = PreferencesManager.getApiKey(context)
        val selectedModel = PreferencesManager.getSelectedModel(context).removePrefix("models/").ifBlank { "gemini-3.5-flash-lite" }

        if (apiKey.isBlank()) {
            return@withContext "A message regarding personal matter."
        }

        try {
            val systemInstruction = "Summarize the essence of this personal message in one short, respectful sentence without revealing sensitive private details."
            val request = GeminiGenerateRequest(
                systemInstruction = GeminiSystemInstruction(
                    parts = listOf(GeminiPart(text = systemInstruction))
                ),
                contents = listOf(
                    GeminiContent(
                        role = "user",
                        parts = listOf(GeminiPart(text = message))
                    )
                ),
                generationConfig = GeminiGenerationConfig(
                    temperature = 0.1,
                    responseMimeType = "text/plain"
                )
            )
            val response = apiService.generateContent(selectedModel, apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim() ?: "A personal message."
        } catch (e: Exception) {
            "A personal message."
        }
    }
}

package com.example.brain

import android.content.Context
import android.util.Log
import com.example.data.MaxDatabase
import com.example.data.MemoryItemEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * MemoryAIEngine (MAX AI OS)
 *
 * Provides structured long-term memory persistence across:
 * - Favorite contacts
 * - Favorite songs & playlists
 * - Favorite YouTube channels
 * - Frequently used system / root commands
 * - Installed Kali NetHunter tools
 * - Root environment status
 * - Preferred languages
 * - Conversation and routine learning
 */
class MemoryAIEngine private constructor(private val context: Context) {

    companion object {
        private const val TAG = "MemoryAIEngine"

        @Volatile
        private var INSTANCE: MemoryAIEngine? = null

        fun getInstance(context: Context): MemoryAIEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: MemoryAIEngine(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    private val db = MaxDatabase.getInstance(context)
    private val memoryDao = db.memoryDao()

    suspend fun setPreference(key: String, value: String, category: String = "preferences"): Unit = withContext(Dispatchers.IO) {
        memoryDao.setMemoryItem(MemoryItemEntity(key = key, value = value, category = category))
    }

    suspend fun getPreference(key: String): String? = withContext(Dispatchers.IO) {
        memoryDao.getMemoryItem(key)?.value
    }

    // Favorite Songs
    suspend fun addFavoriteSong(songName: String): Unit = withContext(Dispatchers.IO) {
        val current = getPreference("fav_songs") ?: ""
        val list = current.split(",").map { s: String -> s.trim() }.filter { s: String -> s.isNotBlank() }.toMutableList()
        if (!list.contains(songName)) {
            list.add(songName)
            setPreference("fav_songs", list.joinToString(","), "entertainment")
        }
    }

    suspend fun getFavoriteSongs(): List<String> = withContext(Dispatchers.IO) {
        val pref = getPreference("fav_songs") ?: return@withContext emptyList()
        pref.split(",").map { s: String -> s.trim() }.filter { s: String -> s.isNotBlank() }
    }

    // Favorite YouTube Channels
    suspend fun addFavoriteChannel(channelName: String): Unit = withContext(Dispatchers.IO) {
        val current = getPreference("fav_channels") ?: ""
        val list = current.split(",").map { s: String -> s.trim() }.filter { s: String -> s.isNotBlank() }.toMutableList()
        if (!list.contains(channelName)) {
            list.add(channelName)
            setPreference("fav_channels", list.joinToString(","), "entertainment")
        }
    }

    suspend fun getFavoriteChannels(): List<String> = withContext(Dispatchers.IO) {
        val pref = getPreference("fav_channels") ?: return@withContext emptyList()
        pref.split(",").map { s: String -> s.trim() }.filter { s: String -> s.isNotBlank() }
    }

    // Frequently Used Commands
    suspend fun recordCommandUsage(command: String, module: String): Unit = withContext(Dispatchers.IO) {
        val existing = memoryDao.findCommand(command)
        if (existing != null) {
            memoryDao.insertOrUpdateCommand(
                existing.copy(
                    usageCount = existing.usageCount + 1,
                    timestamp = System.currentTimeMillis()
                )
            )
        } else {
            memoryDao.insertOrUpdateCommand(
                com.example.data.CommandHistoryEntity(
                    command = command,
                    module = module,
                    timestamp = System.currentTimeMillis(),
                    usageCount = 1,
                    exitCode = 0
                )
            )
        }
    }

    suspend fun getFrequentCommands(limit: Int = 5): List<String> = withContext(Dispatchers.IO) {
        memoryDao.getFrequentCommands(limit).map { cmd: com.example.data.CommandHistoryEntity -> cmd.command }
    }

    // Kali Tools Installed
    suspend fun saveInstalledKaliTools(tools: List<String>): Unit = withContext(Dispatchers.IO) {
        setPreference("installed_kali_tools", tools.joinToString(","), "security")
    }

    suspend fun getInstalledKaliTools(): List<String> = withContext(Dispatchers.IO) {
        val pref = getPreference("installed_kali_tools") ?: return@withContext emptyList()
        pref.split(",").map { s: String -> s.trim() }.filter { s: String -> s.isNotBlank() }
    }

    /**
     * Builds comprehensive user memory context to supply to Gemini Brain.
     */
    suspend fun buildMemoryContext(): String = withContext(Dispatchers.IO) {
        val favSongs = getFavoriteSongs()
        val favChannels = getFavoriteChannels()
        val frequentCommands = getFrequentCommands(5)
        val kaliTools = getInstalledKaliTools()
        // One source for the owner's name (MemoryBrain), not a second copy typed into this file.
        val ownerName = MemoryBrain.getInstance(context).getMemory(MemoryBrain.KEY_USER_NAME) ?: "Mr. Ram Narayan"

        buildString {
            append("--- USER LONG-TERM MEMORY & PREFERENCES ---\n")
            append("User: $ownerName. Respond naturally, directly, and conversationally without repeatedly using the user's name or titles.\n")
            if (favSongs.isNotEmpty()) {
                append("Favorite Songs: ${favSongs.take(5).joinToString(", ")}\n")
            }
            if (favChannels.isNotEmpty()) {
                append("Favorite YouTube Channels: ${favChannels.take(5).joinToString(", ")}\n")
            }
            if (frequentCommands.isNotEmpty()) {
                append("Frequent Commands: ${frequentCommands.joinToString(" | ")}\n")
            }
            if (kaliTools.isNotEmpty()) {
                append("Kali Tools Available: ${kaliTools.take(8).joinToString(", ")}\n")
            }
            append("-------------------------------------------\n")
        }
    }
}

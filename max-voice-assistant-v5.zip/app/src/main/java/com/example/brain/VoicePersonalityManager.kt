package com.example.brain

import android.util.Log

enum class UserEmotionContext {
    ANGRY,
    HAPPY,
    BUSY,
    TECHNICAL,
    NEUTRAL
}

object VoicePersonalityManager {
    private const val TAG = "VoicePersonality"

    // Prohibited casual nicknames (slang)
    private val FORBIDDEN_WORDS_REGEX = Regex(
        "(?i)\\b(bro|bhai|dost|buddy|yaar|dude|mate|pal|bhiya|bhaiya)\\b"
    )

    // Forbidden in Hindi script (strictly matching standalone slang tokens, never parts of legitimate words like तैयार, हथियार, प्यार)
    private val FORBIDDEN_HINDI_REGEX = Regex(
        "(?<=^|[\\s,।!?;:\"'()—–-])(भाई|यार|दोस्त|ब्रो|भैया)(?=[\\s,।!?;:\"'()—–-]|$)"
    )

    /**
     * Cleans the response, ensuring professional and respectful address without robotic repetition.
     * Removes slang (bro, bhai, dost, buddy, yaar, etc.) while allowing respectful Jarvis style (सर, सर जी, बॉस).
     * Removes repetitive hardcoded addressing of the creator's name (Ram Narayan Ji / मिस्टर राम नारायण)
     * unless the query explicitly asked about the creator/owner.
     */
    fun enforceRespectfulAddress(text: String): String {
        if (text.isBlank()) return ""

        // 1. Remove forbidden slang cleanly
        var sanitized = text
            .replace(FORBIDDEN_WORDS_REGEX, "")
            .replace(FORBIDDEN_HINDI_REGEX, "")

        // 2. Clean only stuttered/duplicate repetitive honorific openers (e.g. "Sir, Sir,", "जी सर, जी सर", "राम नारायण जी")
        sanitized = sanitized
            .replace(Regex("(?i)^(sir[,\\s]+){2,}"), "Sir, ")
            .replace(Regex("^(जी\\s*सर[,\\s]+){2,}"), "जी सर, ")
            .replace(Regex("^(हाँ\\s*सर[,\\s]+){2,}"), "हाँ सर, ")
            .replace(Regex("^(मिस्टर\\s*राम\\s*नारायण\\s*(जी)?[,।\\s]*)+"), "")
            .replace(Regex("^(राम\\s*नारायण\\s*(जी)?[,।\\s]*)+"), "")
            .replace(Regex("(?i)^(mr\\.?\\s*ram\\s*narayan[,\\s]*)+"), "")
            .replace(Regex("(?i)^(ram\\s*narayan[,\\s]*)+"), "")

        // Clean repetitive owner addresses mid-sentence if used as an honorific tag (e.g., "जी, राम नारायण जी, मैं..." or ", राम नारायण जी, ")
        sanitized = sanitized
            .replace(Regex("(?i)[,।\\s]+(मिस्टर\\s*)?राम\\s*नारायण\\s*(जी)?[,।]"), " ")
            .replace(Regex("(?i)[,।\\s]+mr\\.?\\s*ram\\s*narayan[,।]"), " ")

        // Clean trailing repetitive owner addresses on routine responses (e.g., "...कर दिया है, राम नारायण जी।")
        sanitized = sanitized
            .replace(Regex("([,।\\s]+(मिस्टर\\s*)?राम\\s*नारायण\\s*(जी)?[.!?]?)$"), "")
            .replace(Regex("(?i)([,\\s]+mr\\.?\\s*ram\\s*narayan[.!?]?)$"), "")

        // 3. Clean double spaces, awkward commas or punctuation leftover from removal
        sanitized = sanitized
            .replace(Regex("\\s+"), " ")
            .replace(Regex(",\\s*,"), ",")
            .replace(Regex("^[,\\s.:;!?-]+"), "")
            .replace("पूरी तरह तय हूँ", "पूरी तरह तैयार हूँ")
            .replace("पूरी तरह तय हूं", "पूरी तरह तैयार हूं")
            .replace("पूरी तरह तय", "पूरी तरह तैयार")
            .replace(Regex("(?<=^|[\\s,।!?;:\"'()—–-])तय\\s*(हूँ|हूं|हु)(?=[\\s,।!?;:\"'()—–-]|$)")) { match ->
                "तैयार ${match.groupValues[1]}"
            }
            .trim()

        return sanitized
    }

    /**
     * Detects high-level emotional context from the user query to guide human maturity.
     */
    // Whole-word match for Latin words, so "port" no longer fires on "important" or "report", and "fast" not on "breakfast".
    private fun hasWord(q: String, vararg words: String): Boolean = words.any { w ->
        Regex("(?<![\\p{L}\\p{M}])" + Regex.escape(w) + "(?![\\p{L}\\p{M}])").containsMatchIn(q)
    }

    fun detectUserEmotion(query: String): UserEmotionContext {
        val q = query.lowercase().trim()

        // Angry / Frustrated signals
        if (q.contains("not working") || q.contains("काम नहीं कर रहा") ||
            hasWord(q, "stupid", "idiot", "angry", "frustrated", "failed", "gussa") || q.contains("बकवास") ||
            q.contains("दिमाग खराब")
        ) {
            return UserEmotionContext.ANGRY
        }

        // Happy / Delighted signals
        if (hasWord(q, "great", "awesome", "thanks", "thank", "happy", "khush") || q.contains("मज़ा आ गया") ||
            q.contains("शाबाश") || q.contains("good job") || q.contains("well done") ||
            q.contains("शुक्रिया") || q.contains("धन्यवाद")
        ) {
            return UserEmotionContext.HAPPY
        }

        // Busy / Urgent signals
        if (hasWord(q, "quick", "quickly", "hurry", "busy", "fatafat", "jaldi") || q.contains("जल्दी") ||
            q.contains("तुरंत") || q.contains("short me") || q.contains("in short") || q.contains("छोटा जवाब")
        ) {
            return UserEmotionContext.BUSY
        }

        // Technical / Operations signals
        if (hasWord(q, "root", "kali", "termux", "nmap", "port", "ports", "kernel", "chmod", "bash", "python", "iptables", "network")) {
            return UserEmotionContext.TECHNICAL
        }

        return UserEmotionContext.NEUTRAL
    }

    /**
     * Generates personality guidance prompt to append for Gemini requests.
     */
    fun buildPersonalityDirective(emotion: UserEmotionContext): String {
        val emotionGuidance = when (emotion) {
            UserEmotionContext.ANGRY ->
                "The user sounds frustrated or is hitting a problem. Stay calm and warm, acknowledge it in your own fresh words, and move straight to fixing it."
            UserEmotionContext.HAPPY ->
                "The user is pleased or happy. Respond warmly with fresh wording and a touch of wit; never use a stock phrase."
            UserEmotionContext.BUSY ->
                "The user said they are in a hurry. Keep this one reply short and crisp (one or two sentences), then go back to full answers next time."
            UserEmotionContext.TECHNICAL ->
                "The user is executing technical root/Kali/system commands. Respond with highest technical precision, professionalism, and prompt execution."
            UserEmotionContext.NEUTRAL ->
                "Respond with calm, mature intelligence and natural conversational composure."
        }

        return """
            --- CORE PERSONALITY DIRECTIVES (MAX AI ASSISTANT) ---
            0. IDENTITY & CREATOR KNOWLEDGE:
               - You are MAX. You are NEVER JARVIS.
               - Creator: Mr. Ram Narayan (मिस्टर राम नारायण). Only mention creator when explicitly asked about who created you or who your owner is.
            1. NATURAL CONVERSATIONAL TONE (NO REPETITIVE NAME OR SIR CALLING):
               - CRITICAL: DO NOT address the user as "राम नारायण जी", "मिस्टर राम नारायण", or "Mr. Ram Narayan" in ordinary conversational responses or before/after answering questions!
               - DO NOT start every response with 'Sir', 'जी सर', or 'हाँ सर'.
               - AI Thinking: Use dynamic context-aware thinking. Answer fully and naturally, with substance and detail, without forced repetitive names or titles.
               - NEVER call the user: Bro, Bhai, Dost, Buddy, Yaar, Boss, Dude, or any casual slang nickname.
            2. NO ROBOTIC SYSTEM MESSAGES:
               - Avoid robotic boilerplate: 'Command executed successfully', 'Task completed', 'Opening app', 'Intent detected'.
               - Speak like a helpful, intelligent human companion.
            3. NO INTERNAL LEAKS:
               - Never speak JSON, code, shell commands, capability names, or debug metadata in spoken responses.
            4. TONE & COMPOSURE:
               - Calm, mature, intelligent, professional, poised, and human-like.
            5. EMOTION CONTEXT GUIDANCE:
               $emotionGuidance
            ------------------------------------------------------
        """.trimIndent()
    }
}

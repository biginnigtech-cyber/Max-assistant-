package com.example.brain

import android.content.Context
import android.util.Log
import com.example.ai.GeminiBrain
import com.example.data.MaxCommandResponse
import com.example.data.MessageEntity
import com.example.engine.AppAutomationEngine
import com.example.engine.AudioPlaybackEngine
import com.example.engine.AutomationEngine
import com.example.engine.DeviceController
import com.example.engine.KaliCommandEngine
import com.example.engine.NetworkController
import com.example.engine.RootCommandEngine
import com.example.engine.TermuxCommandEngine
import com.example.engine.VoicePromptNormalizer
import com.example.engine.WeatherManager
import com.example.executor.IntentExecutionLayer
import com.example.service.AcousticEchoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext

class VoiceIntentRouter private constructor(private val context: Context) {

    companion object {
        private const val TAG = "VoiceIntentRouter"

        @Volatile
        private var INSTANCE: VoiceIntentRouter? = null

        fun getInstance(context: Context): VoiceIntentRouter {
            return INSTANCE ?: synchronized(this) {
                val instance = VoiceIntentRouter(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    private val geminiBrain = GeminiBrain()
    private val memoryBrain = MemoryBrain.getInstance(context)
    private val taskPlanner = TaskPlanner.getInstance(context)

    /** How sure we are that the current speech was meant for MAX (used with the always-open mic). */
    data class AddressingContext(
        val explicitlyAddressed: Boolean = true,      // wake word, typed text, button, voice reply
        val secondsSinceLastReply: Long = 9999L,      // since MAX last finished speaking
        val secondsSinceMicArmed: Long = 9999L,       // since the user pressed the mic button
        val lastReplyWasQuestion: Boolean = false
    )

    private fun buildInteractionContext(a: AddressingContext, wakeWordUsed: Boolean): String {
        val last = if (a.secondsSinceLastReply >= 9999L) "never in this session" else "${a.secondsSinceLastReply} seconds ago"
        val armed = if (a.secondsSinceMicArmed >= 9999L) "no" else "yes, ${a.secondsSinceMicArmed} seconds ago"
        return "INTERACTION_CONTEXT:\n" +
            "- wake word or typed text used: ${if (a.explicitlyAddressed || wakeWordUsed) "yes" else "no"}\n" +
            "- MAX last spoke: $last\n" +
            "- your last reply was a question: ${if (a.lastReplyWasQuestion) "yes" else "no"}\n" +
            "- user just pressed the mic button: $armed"
    }

    data class RouterResult(
        val spokenResponse: String,
        val moduleUsed: String,
        val details: List<String> = emptyList(),
        val executionSuccess: Boolean = true,
        val isAwaitingConfirmation: Boolean = false,
        /** True when the answer was already spoken sentence by sentence while Gemini was still writing it. */
        val alreadySpoken: Boolean = false
    )

    @Volatile private var lastCommandForLog: com.example.data.MaxCommandResponse? = null

    // Whole words only: "rain" must not fire on "train" or "brain", and "badal" (cloud) not on "badal do" (change it).
    private val WEATHER_WORDS = Regex(
        "(?<![\\p{L}\\p{M}])(weather|rain|raining|forecast|temperature|barish|dhoop|thandi|garmi|climate|umbrella|mausam)(?![\\p{L}\\p{M}])" +
            "|मौसम|बारिश|तापमान|धूप|ठंड|गर्मी|बादल|छाता"
    )

    private val TOOL_WORDS = Regex(
        "(?<![\\p{L}\\p{M}])(scan|port|ports|wifi|wi-fi|ping|network|nmap|ip|dns|device|devices|connected|kali|termux|root|shell|terminal|command|hotspot|packet|ssh|router|signal|internet|speed|file|files|folder|install|system|reboot|restart|rm|delete)(?![\\p{L}\\p{M}])" +
            "|स्कैन|पोर्ट|वाईफाई|वाई-फाई|वाई फाई|वाईफ़ाई|पिंग|नेटवर्क|आईपी|डिवाइस|जुड़|काली|टर्मक्स|रूट|टर्मिनल|कमांड|हॉटस्पॉट|राउटर|सिग्नल|इंटरनेट|स्पीड|फाइल|फोल्डर|इंस्टॉल|सिस्टम|रिबूट|रीस्टार्ट|डिलीट"
    )

    /** Runs the command, then keeps a record of it so the user can undo / fix / repeat it by voice. */
    suspend fun routeAndExecute(
        userQuery: String,
        apiKey: String,
        selectedModel: String,
        history: List<MessageEntity>,
        onStatusChange: (String) -> Unit,
        onProgress: (String) -> Unit,
        onOutputLine: (String) -> Unit,
        onImmediateSpeak: ((String) -> Unit)? = null,
        addressing: AddressingContext = AddressingContext(),
        onSpeechChunk: ((String) -> Unit)? = null
    ): RouterResult {
        val before = try { com.example.engine.ActionLog.snapshot(context) } catch (_: Exception) { "" }
        lastCommandForLog = null
        val result = routeAndExecuteInner(
            userQuery, apiKey, selectedModel, history, onStatusChange, onProgress, onOutputLine, onImmediateSpeak, addressing, onSpeechChunk
        )
        try {
            com.example.engine.ActionLog.recordFromResult(
                request = com.example.engine.ScreenUnlock.redactSecrets(userQuery),
                module = result.moduleUsed,
                spoken = result.spokenResponse,
                success = result.executionSuccess,
                awaitingConfirmation = result.isAwaitingConfirmation,
                command = lastCommandForLog,
                stateBefore = before
            )
        } catch (e: Exception) {
            Log.w(TAG, "ActionLog record failed: ${e.message}")
        }
        return result
    }

    private suspend fun routeAndExecuteInner(
        userQuery: String,
        apiKey: String,
        selectedModel: String,
        history: List<MessageEntity>,
        onStatusChange: (String) -> Unit,
        onProgress: (String) -> Unit,
        onOutputLine: (String) -> Unit,
        onImmediateSpeak: ((String) -> Unit)?,
        addressing: AddressingContext,
        onSpeechChunk: ((String) -> Unit)?
    ): RouterResult = withContext(Dispatchers.IO) {
        val cleanQuery = userQuery.trim()

        // 1. CHECK FOR PENDING MULTI-STEP TASK PLAN CONFIRMATION
        if (taskPlanner.hasPendingPlan() && !taskPlanner.isCancellation(cleanQuery) && !taskPlanner.isConfirmation(cleanQuery)) {
            // The user said something unrelated: the old question is dropped and this is handled as a new command.
            Log.d(TAG, "Pending plan dropped: '$cleanQuery' is neither a yes nor a no")
            taskPlanner.cancelPendingPlan()
        }
        if (taskPlanner.hasPendingPlan()) {
            Log.d(TAG, "TaskPlanner has active pending plan. Processing confirmation: '$cleanQuery'")
            onStatusChange("Executing")
            val planSpoken = taskPlanner.resolvePendingPlan(cleanQuery) { progressMsg ->
                onProgress(progressMsg)
            }
            return@withContext RouterResult(
                spokenResponse = planSpoken,
                moduleUsed = "TASK_PLAN",
                details = listOf(planSpoken),
                executionSuccess = true,
                isAwaitingConfirmation = false
            )
        }

        // 2. INJECT SYSTEM MEMORY CONTEXT, PERSONALITY & ROUTE THROUGH GEMINI BRAIN
        val contextEngine = ContextEngine.getInstance(context)
        val memoryAiEngine = MemoryAIEngine.getInstance(context)
        val memoryBrainContext = memoryBrain.buildMemoryContextPrompt()
        val permMemoryContext = MemoryManager.getInstance(context).buildPermanentMemoryContext()
        val structuredAiMemory = memoryAiEngine.buildMemoryContext()
        val deviceContextSummary = contextEngine.buildContextSummary()

        // 1. UNIFIED WAKE-WORD DETECTION AND EXTRACTION
        val wakeResult = AcousticEchoManager.detectAndExtractWake(cleanQuery)
        val queryToProcess = if (wakeResult.hasWakeWord && wakeResult.command.isNotBlank()) {
            Log.d("WAKE_GATE", "Unified wake+command stripped in router: '$cleanQuery' -> '${wakeResult.command}'")
            wakeResult.command
        } else {
            cleanQuery
        }
        val queryLower = queryToProcess.lowercase().trim()

        // Is this speech clearly meant for MAX? Local keyword shortcuts only run when it is.
        val explicitlyAddressed = addressing.explicitlyAddressed || wakeResult.hasWakeWord
        val recentlyEngaged = addressing.secondsSinceLastReply <= 12L || addressing.secondsSinceMicArmed <= 8L
        val trustLocalFastPaths = explicitlyAddressed || recentlyEngaged

        val isWeatherQuery = WEATHER_WORDS.containsMatchIn(queryLower)

        // The phone's own state, fetched in parallel with the rest of the context so it adds almost no waiting.
        val phoneStateJob = async { try { com.example.engine.PhoneState.snapshot(context) } catch (_: Exception) { "" } }

        val liveWeatherContext = if (isWeatherQuery) {
            onProgress("Checking real-time weather sensors...")
            WeatherManager.buildLiveWeatherContext(context)
        } else ""

        val emotion = PersonalityEngine.detectEmotion(queryToProcess)
        val personalityPrompt = PersonalityEngine.buildPersonalityDirective(emotion, deviceContextSummary)
        val phoneState = phoneStateJob.await()
        val habitHint = try {
            com.example.engine.HabitTracker.hintBlock(context, com.example.engine.Automations.load(context))
        } catch (_: Exception) { "" }
        val baseContext = if (liveWeatherContext.isNotBlank()) {
            "$permMemoryContext\n\n$structuredAiMemory\n\n$liveWeatherContext\n\n$personalityPrompt\n\n$memoryBrainContext"
        } else {
            "$permMemoryContext\n\n$structuredAiMemory\n\n$personalityPrompt\n\n$memoryBrainContext"
        }
        val combinedMemoryContext = listOf(baseContext, phoneState, habitHint).filter { it.isNotBlank() }.joinToString("\n\n")

        // Offline weather fallback when no API key is available
        if (isWeatherQuery && apiKey.isBlank()) {
            onStatusChange("Completed")
            val liveData = WeatherManager.fetchLiveWeather(context)
            val spokenWeather = if (liveData != null) {
                "अभी तापमान लगभग ${liveData.temperatureC.toInt()} डिग्री सेल्सियस है और आसमान में ${liveData.conditionTextHindi} है।"
            } else {
                "अभी मौसम का डेटा नहीं मिल पा रहा, शायद इंटरनेट या लोकेशन की दिक्कत है। थोड़ी देर बाद फिर पूछिए, मैं झूठा अंदाज़ा नहीं लगाऊँगा।"
            }
            return@withContext RouterResult(
                spokenResponse = spokenWeather,
                moduleUsed = "WEATHER",
                details = listOf("Offline live weather report")
            )
        }

        // A PIN command is handled here, before the sentence reaches Gemini, the logs or the chat history.
        com.example.engine.ScreenUnlock.handlePinCommand(context, queryToProcess)?.let { say ->
            onStatusChange("Completed")
            return@withContext RouterResult(spokenResponse = say, moduleUsed = "SECURITY", details = listOf("PIN command handled on the phone only"), executionSuccess = true)
        }

        // Instant wake-word acknowledgment when called by name alone without any command
        if (wakeResult.hasWakeWord && wakeResult.command.isBlank()) {
            if (apiKey.isBlank()) {
                onStatusChange("Completed")
                val ack = GeminiBrain.offlineWakeLine()
                return@withContext RouterResult(
                    spokenResponse = ack,
                    moduleUsed = "WAKE",
                    details = listOf("Wake word acknowledged")
                )
            }
            // If API key is available, proceed to Gemini Brain below to generate fresh, lively Jarvis-style conversation!
        }

        // Direct Routine Mode Fast-Paths ONLY when explicitly requested as a mode or routine
        if (trustLocalFastPaths) when {
            (queryLower.contains("good morning") || queryLower.contains("subah ho gayi")) && (queryLower.contains("routine") || queryLower.contains("mode") || queryLower.contains("activate") || queryLower.contains("चालू करो")) -> {
                onStatusChange("Executing")
                val routineRes = com.example.engine.AutomationEngine.executeRoutine(context, ContextEngine.OperatingMode.GOOD_MORNING) { onProgress(it) }
                return@withContext RouterResult(routineRes.spokenResponse, "AUTOMATION", routineRes.actionsExecuted)
            }
            (queryLower.contains("night mode") || queryLower.contains("so jao") || queryLower.contains("good night")) && (queryLower.contains("routine") || queryLower.contains("mode") || queryLower.contains("activate") || queryLower.contains("चालू करो")) -> {
                onStatusChange("Executing")
                val routineRes = com.example.engine.AutomationEngine.executeRoutine(context, ContextEngine.OperatingMode.NIGHT) { onProgress(it) }
                return@withContext RouterResult(routineRes.spokenResponse, "AUTOMATION", routineRes.actionsExecuted)
            }
            queryLower.contains("gaming mode") || queryLower.contains("game mode") -> {
                onStatusChange("Executing")
                val routineRes = com.example.engine.AutomationEngine.executeRoutine(context, ContextEngine.OperatingMode.GAMING) { onProgress(it) }
                return@withContext RouterResult(routineRes.spokenResponse, "AUTOMATION", routineRes.actionsExecuted)
            }
            queryLower.contains("work mode") || queryLower.contains("office mode") -> {
                onStatusChange("Executing")
                val routineRes = com.example.engine.AutomationEngine.executeRoutine(context, ContextEngine.OperatingMode.WORK) { onProgress(it) }
                return@withContext RouterResult(routineRes.spokenResponse, "AUTOMATION", routineRes.actionsExecuted)
            }
            queryLower.contains("driving mode") || queryLower.contains("drive mode") -> {
                onStatusChange("Executing")
                val routineRes = com.example.engine.AutomationEngine.executeRoutine(context, ContextEngine.OperatingMode.DRIVING) { onProgress(it) }
                return@withContext RouterResult(routineRes.spokenResponse, "AUTOMATION", routineRes.actionsExecuted)
            }
            queryLower.contains("read notification") || queryLower.contains("what are my notification") || queryLower.contains("notification summary") || queryLower.contains("नोटिफिकेशन पढ़ो") -> {
                onStatusChange("Checking Notifications")
                val summary = NotificationBrain.getInstance(context).summarizeAllNotifications()
                return@withContext RouterResult(summary, "NOTIFICATION", listOf("Read recent notifications"))
            }
        }

        // 2. LONG / COMPOUND VOICE PROMPT NORMALIZATION & PRE-PARSING
        val parsedPrompt = VoicePromptNormalizer.parse(queryToProcess)
        val localMessagingOk = parsedPrompt.actionType != VoicePromptNormalizer.ActionType.SEND_MESSAGE ||
            (com.example.engine.SmartEntityExtractor.isValidContact(parsedPrompt.targetEntity) &&
                !com.example.engine.SmartEntityExtractor.looksLikeCommandNoise(parsedPrompt.messageContent))
        val localMediaOk = parsedPrompt.actionType != VoicePromptNormalizer.ActionType.PLAY_MUSIC ||
            !Regex("((?<![\\p{L}\\p{M}])(और|aur|and|then)(?![\\p{L}\\p{M}])|फिर|volume|वॉल्यूम|आवाज़|आवाज)").containsMatchIn(queryLower)
        if (parsedPrompt.hasExplicitAction && trustLocalFastPaths && localMessagingOk && localMediaOk) {
            when (parsedPrompt.actionType) {
                VoicePromptNormalizer.ActionType.SEND_MESSAGE -> {
                    onStatusChange("Executing")
                    onProgress("Automating message to ${parsedPrompt.targetEntity}...")

                    // Safety check against wrong contact:
                    val resolution = com.example.utils.ContactResolver.resolveSmart(context, parsedPrompt.targetEntity)
                    if (resolution is com.example.utils.ContactResolutionResult.MultipleMatches) {
                        val names = resolution.matches.take(3).joinToString(", ") { it.name }
                        val disambiguationPrompt = "${parsedPrompt.targetEntity} नाम के एक से ज़्यादा कॉन्टैक्ट्स मिल रहे हैं: $names। किस वाले ${parsedPrompt.targetEntity} को मैसेज भेजूँ?"
                        onStatusChange("Completed")
                        return@withContext RouterResult(
                            spokenResponse = disambiguationPrompt,
                            moduleUsed = "MESSAGE_REPLY",
                            details = listOf("Multiple contacts found for ${parsedPrompt.targetEntity}: $names"),
                            executionSuccess = true,
                            isAwaitingConfirmation = true
                        )
                    }

                    val contactPhone = (resolution as? com.example.utils.ContactResolutionResult.SingleMatch)?.contact?.phoneNumber
                        ?: com.example.utils.ContactResolver.getPhoneNumber(context, parsedPrompt.targetEntity)

                    val autoResult = AppAutomationEngine.automateMessaging(
                        context = context,
                        targetApp = parsedPrompt.targetApp,
                        contactName = parsedPrompt.targetEntity,
                        messageText = parsedPrompt.messageContent,
                        phoneNumber = contactPhone,
                        onProgress = { onProgress(it) }
                    )
                    onStatusChange("Completed")
                    return@withContext RouterResult(
                        spokenResponse = autoResult.spokenResponse,
                        moduleUsed = "MESSAGE_REPLY",
                        details = autoResult.details,
                        executionSuccess = autoResult.success
                    )
                }

                VoicePromptNormalizer.ActionType.PLAY_MUSIC -> {
                    onStatusChange("Playing Music")
                    onProgress("Playing ${parsedPrompt.targetEntity} on ${parsedPrompt.targetApp}...")
                    val playResult = AudioPlaybackEngine.playTrack(context, parsedPrompt.targetEntity, parsedPrompt.targetApp)
                    onStatusChange("Completed")
                    val isYt = parsedPrompt.targetApp.equals("youtube", ignoreCase = true)
                    val spokenPlay = when {
                        isYt -> playResult.message
                        playResult.success -> "${parsedPrompt.targetEntity} स्पॉटिफाई पर चला दिया है।"
                        else -> "गाना नहीं चल पाया।"
                    }
                    return@withContext RouterResult(
                        spokenResponse = GeminiBrain.sanitizeTtsText(spokenPlay),
                        moduleUsed = if (isYt) "YOUTUBE" else "SPOTIFY",
                        details = listOf(playResult.message),
                        executionSuccess = playResult.success
                    )
                }

                VoicePromptNormalizer.ActionType.OPEN_APP -> {
                    onStatusChange("Launching App")
                    onProgress("Opening ${parsedPrompt.targetApp}...")
                    val launchResult = DeviceController.openApp(context, parsedPrompt.targetApp)
                    onStatusChange("Completed")
                    val responseMsg = if (launchResult.success) "हाँ, ${parsedPrompt.targetApp} खोल दिया है।" else launchResult.message
                    return@withContext RouterResult(
                        spokenResponse = GeminiBrain.sanitizeTtsText(responseMsg),
                        moduleUsed = "DEVICE",
                        details = listOf(launchResult.message),
                        executionSuccess = launchResult.success
                    )
                }

                VoicePromptNormalizer.ActionType.DEVICE_CONTROL -> {
                    onStatusChange("Executing")
                    onProgress("Executing device control ${parsedPrompt.targetApp} (${parsedPrompt.targetEntity})...")
                    val spokenMsg: String
                    val logDetails = mutableListOf<String>()

                    when (parsedPrompt.targetApp) {
                        "torch" -> {
                            val enable = when (parsedPrompt.targetEntity) {
                                "on" -> true
                                "off" -> false
                                else -> null
                            }
                            val res = DeviceController.toggleFlashlight(context, enable)
                            logDetails.add(res.message)
                            spokenMsg = if (res.success) {
                                if (parsedPrompt.targetEntity == "off") "टॉर्च बंद कर दी है।" else "हाँ, टॉर्च चालू कर दी है।"
                            } else res.message
                        }
                        "bluetooth" -> {
                            val enable = parsedPrompt.targetEntity == "on"
                            val res = DeviceController.toggleBluetooth(enable)
                            logDetails.add(res.message)
                            spokenMsg = if (res.success) {
                                if (enable) "हाँ, ब्लूटूथ चालू कर दिया है।" else "ब्लूटूथ बंद कर दिया है।"
                            } else res.message
                        }
                        "wifi" -> {
                            val enable = parsedPrompt.targetEntity == "on"
                            val res = DeviceController.toggleWiFi(enable)
                            logDetails.add(res.message)
                            spokenMsg = if (res.success) {
                                if (enable) "हाँ, वाई-फाई चालू कर दिया है।" else "वाई-फाई बंद कर दिया है।"
                            } else res.message
                        }
                        "volume" -> {
                            val action = parsedPrompt.targetEntity
                            val res = DeviceController.setVolume(context, action)
                            logDetails.add(res.message)
                            spokenMsg = when (action) {
                                "mute" -> "आवाज़ म्यूट कर दी गई है।"
                                "max" -> "आवाज़ पूरी बढ़ा दी गई है।"
                                "down" -> "आवाज़ कम कर दी गई है।"
                                else -> "आवाज़ बढ़ा दी गई है।"
                            }
                        }
                        "brightness" -> {
                            val pct = parsedPrompt.targetEntity.toIntOrNull() ?: 70
                            val res = DeviceController.setBrightness(pct)
                            logDetails.add(res.message)
                            spokenMsg = "स्क्रीन ब्राइटनेस सेट कर दी गई है।"
                        }
                        "screenshot" -> {
                            val res = DeviceController.takeScreenshot()
                            logDetails.add(res.message)
                            spokenMsg = if (res.success) "स्क्रीनशॉट ले लिया गया है।" else res.message
                        }
                        "battery" -> {
                            val metrics = DeviceController.getSystemMetrics(context)
                            logDetails.add("Battery: ${metrics.batteryPct}%, Temp: ${metrics.thermalTempCelsius}°C")
                            spokenMsg = metrics.summaryHindi
                        }
                        else -> {
                            spokenMsg = "डिवाइस कमांड निष्पादित कर दिया गया है।"
                        }
                    }

                    onStatusChange("Completed")
                    return@withContext RouterResult(
                        spokenResponse = GeminiBrain.sanitizeTtsText(spokenMsg),
                        moduleUsed = "DEVICE",
                        details = logDetails,
                        executionSuccess = true
                    )
                }

                VoicePromptNormalizer.ActionType.TIME_QUERY -> {
                    onStatusChange("Checking Time")
                    val isDate = parsedPrompt.targetApp == "date"
                    val spokenMsg = com.example.engine.CoreActions.clockAnswer(isDate)
                    onStatusChange("Completed")
                    return@withContext RouterResult(
                        spokenResponse = GeminiBrain.sanitizeTtsText(spokenMsg),
                        moduleUsed = "SYSTEM",
                        details = listOf(spokenMsg),
                        executionSuccess = true
                    )
                }

                VoicePromptNormalizer.ActionType.DIRECT_CHAT -> {
                    if (apiKey.isBlank()) {
                        onStatusChange("Completed")
                        val responseMsg = parsedPrompt.messageContent.ifBlank { GeminiBrain.offlineWakeLine() }
                        return@withContext RouterResult(
                            spokenResponse = GeminiBrain.sanitizeTtsText(responseMsg),
                            moduleUsed = "CHAT",
                            details = listOf("Offline direct conversational response"),
                            executionSuccess = true
                        )
                    }
                    // When API key is present, let Gemini Brain generate dynamic, non-hardcoded responses!
                }

                else -> { /* Proceed to Gemini AI */ }
            }
        }

        onStatusChange("Thinking")
        onProgress("Analyzing intent and routing...")

        // Query Gemini AI Brain with memory context for all queries, chat, commands, and tasks
        // Live feel: for a direct conversation MAX starts speaking after the first sentence, while Gemini is still writing.
        // Overheard speech (not explicitly addressed) uses the normal call, because only the JSON can say "not for MAX".
        val streamed = if (onSpeechChunk != null && explicitlyAddressed && apiKey.isNotBlank()) {
            geminiBrain.streamVoiceQuery(
                userQuery = queryToProcess,
                apiKey = apiKey,
                modelName = selectedModel,
                history = history,
                memoryContext = combinedMemoryContext,
                interactionContext = "",
                actionContext = com.example.engine.ActionLog.contextBlock(),
                onSentence = onSpeechChunk
            )
        } else null
        val streamedChunks = streamed?.chunksSpoken ?: 0
        val geminiRaw = streamed?.response ?: geminiBrain.processVoiceQueryWithMemory(
            userQuery = queryToProcess,
            apiKey = apiKey,
            modelName = selectedModel,
            history = history,
            memoryContext = combinedMemoryContext,
            interactionContext = if (explicitlyAddressed) "" else buildInteractionContext(addressing, wakeResult.hasWakeWord),
            actionContext = com.example.engine.ActionLog.contextBlock()
        )

        val geminiResponse = geminiRaw.copy(parameters = geminiRaw.parameters + mapOf("_raw_query" to queryToProcess))
        lastCommandForLog = geminiResponse

        // Always-open mic: speech that was not meant for MAX is dropped silently
        if (!explicitlyAddressed && !geminiResponse.addressed_to_max && addressing.secondsSinceMicArmed > 5L) {
            Log.d(TAG, "Ignoring speech not addressed to MAX")
            onStatusChange("Completed")
            return@withContext RouterResult(
                spokenResponse = "",
                moduleUsed = "IGNORED",
                details = listOf("Ignored: not addressed to MAX"),
                executionSuccess = true
            )
        }

        Log.d(TAG, "Gemini Routed Intent: ${geminiResponse.intent}, Module: ${geminiResponse.module}")
        onProgress("Routing completed: ${geminiResponse.intent.ifBlank { "CHAT" }}")

        // 2.8 LOCKED PHONE: wake it and open the lock screen before anything that needs the screen. Quick system actions do not need it.
        var unlockedByMax = false
        run {
            val intUp = geminiResponse.intent.trim().uppercase()
            val chatLike = geminiResponse.module.trim().uppercase() == "CHAT" || intUp == "CHAT" || intUp == "CLARIFY" || intUp.isBlank()
            val noScreenNeeded = Regex("ALARM|TIMER|VOICE|AUTOMATION|PHOTO|PICTURE|SELFIE|CALL|VOLUME|BRIGHTNESS|TORCH|FLASH|TIME|DATE|WEATHER|DISMISS|SET_|MUTE|LIST|MEMORY|NOTIFICATION")
                .containsMatchIn(intUp)
            if (!chatLike && !noScreenNeeded && com.example.engine.ScreenUnlock.isLocked()) {
                onProgress("फ़ोन लॉक है, खोल रहा हूँ...")
                val u = com.example.engine.ScreenUnlock.ensureUnlocked(context)
                unlockedByMax = u.unlockedByMax
                if (!u.usable) {
                    onStatusChange("Completed")
                    return@withContext RouterResult(
                        spokenResponse = GeminiBrain.sanitizeTtsText(
                            kotlinx.coroutines.withTimeoutOrNull(3500L) {
                                geminiBrain.composeReply(apiKey, selectedModel, queryToProcess,
                                    "FACT: the phone is locked and MAX could not open it (${u.reason}). The task was NOT done. Tell the user what they can do (unlock once, or tell MAX the PIN).", false)
                            } ?: "फ़ोन लॉक है और मैं उसे खोल नहीं पाया, इसलिए काम नहीं हुआ।"
                        ),
                        moduleUsed = "SECURITY",
                        details = listOf("Locked: ${u.reason}"),
                        executionSuccess = false
                    )
                }
            }
        }

        // 2.9 NEVER RUN A TOOL FROM A MISHEARD FRAGMENT.
        // Gemini decides the action; this only checks that the user's own words really mention what Gemini
        // is about to run. A lone "prompt" / "message" must never start a scan or send a message.
        run {
            val modUp = geminiResponse.module.trim().uppercase()
            val intUp = geminiResponse.intent.trim().uppercase()
            val cmds = geminiResponse.shell_commands.joinToString(" ").lowercase()
            val isChat = modUp == "CHAT" || intUp == "CHAT" || intUp == "CLARIFY"
            if (!isChat) {
                val isPortScan = Regex("(^|_)PORT(_|$)").containsMatchIn(intUp) || cmds.contains("nmap") ||
                    geminiResponse.parameters["action"].equals("port_scan", ignoreCase = true)
                val isToolAction = modUp in setOf("NETWORK", "KALI", "ROOT", "TERMUX") || intUp.contains("SCAN") ||
                    intUp.contains("NMAP") || isPortScan
                val grounded = TOOL_WORDS.containsMatchIn(queryLower)
                if (isToolAction && !grounded) {
                    Log.w(TAG, "Blocked ungrounded tool action '$intUp/$modUp' for query '$queryLower'")
                    onStatusChange("Completed")
                    return@withContext RouterResult(
                        spokenResponse = GeminiBrain.fallbackLine(),
                        moduleUsed = "CHAT",
                        details = listOf("Blocked: '$queryToProcess' did not clearly ask for $intUp"),
                        executionSuccess = true
                    )
                }
                val hostGiven = !(geminiResponse.parameters["host"] ?: geminiResponse.parameters["target"] ?: geminiResponse.target).isNullOrBlank()
                if (isPortScan && !hostGiven) {
                    onStatusChange("Completed")
                    return@withContext RouterResult(
                        spokenResponse = "किस IP या होस्ट पर पोर्ट स्कैन करना है? पता बताइए, मैं अपने आप कोई पता नहीं चुनूँगा।",
                        moduleUsed = "CHAT",
                        details = listOf("Port scan needs an explicit host"),
                        executionSuccess = true,
                        isAwaitingConfirmation = true
                    )
                }
                if (geminiResponse.confidence < 0.6) {
                    onStatusChange("Completed")
                    return@withContext RouterResult(
                        spokenResponse = geminiResponse.spoken_response.ifBlank { GeminiBrain.fallbackLine() },
                        moduleUsed = "CHAT",
                        details = listOf("Low confidence (${geminiResponse.confidence}): asked instead of acting"),
                        executionSuccess = true
                    )
                }
            }
        }

        // 3. CHECK IF SENSITIVE ACTION REQUIRING USER CONFIRMATION
        val pendingPlanFromRules = taskPlanner.checkAndCreatePlan(
            intent = geminiResponse.intent,
            target = geminiResponse.target_app.ifBlank { geminiResponse.target },
            parameters = geminiResponse.parameters,
            shellCommands = geminiResponse.shell_commands
        )

        // Gemini marks risky work itself (requires_confirmation / HIGH risk). Honour that for anything the
        // fixed rules above do not already cover, for example deleting files.
        val geminiIntent = geminiResponse.intent.trim().uppercase()
        val geminiSaysRisky = (geminiResponse.requires_confirmation || geminiResponse.risk_level.equals("HIGH", ignoreCase = true)) &&
            geminiResponse.module.trim().uppercase() != "CHAT" && geminiIntent != "CHAT" && geminiIntent != "CLARIFY"
        val pendingPlan = pendingPlanFromRules ?: if (geminiSaysRisky) {
            TaskPlanner.PendingPlan(
                planId = "GEMINI_RISK_$geminiIntent",
                promptForUser = "यह जोखिम वाला काम है: ${geminiResponse.goal.ifBlank { geminiResponse.intent }}। क्या मैं इसे करूँ?",
                sensitivityReason = "Gemini marked this action as risky",
                options = listOf("हाँ, करो", "रद्द करो"),
                actionCallback = { _, _ ->
                    val res = com.example.executor.IntentExecutionLayer.execute(context, geminiResponse)
                    res.spokenOverride ?: res.message
                }
            )
        } else null

        if (pendingPlan != null) {
            Log.d(TAG, "Plan requires user confirmation: ${pendingPlan.promptForUser}")
            taskPlanner.registerPendingPlan(pendingPlan)
            return@withContext RouterResult(
                spokenResponse = pendingPlan.promptForUser,
                moduleUsed = "TASK_PLAN",
                details = listOf("Awaiting confirmation: ${pendingPlan.promptForUser}"),
                executionSuccess = true,
                isAwaitingConfirmation = true
            )
        }

        // 4. DISPATCH TO SPECIFIC ENGINE MODULE
        val targetModule = geminiResponse.module.trim().uppercase()
        val intentUpper = geminiResponse.intent.trim().uppercase()
        val logs = mutableListOf<String>()
        var finalSpokenText = geminiResponse.spoken_response
        var execSuccess = true

        when {
            // --- KALI LINUX COMMAND ENGINE ---
            targetModule == "KALI" || intentUpper.contains("KALI") || intentUpper.contains("NETHUNTER") -> {
                onStatusChange("Running Tool")
                val tool = geminiResponse.tool_name.ifBlank {
                    geminiResponse.parameters["tool"] ?: geminiResponse.parameters["command"] ?: "nmap"
                }
                val args = geminiResponse.parameters["args"] ?: geminiResponse.parameters["target"] ?: ""
                onProgress("Executing Kali tool $tool...")

                val kaliResult = KaliCommandEngine.execute(
                    tool = tool,
                    arguments = args,
                    onProgress = { onProgress(it) },
                    onOutputLine = { onOutputLine(it) }
                )

                logs.add("Kali Tool [$tool]: Exit ${kaliResult.exitCode}")
                if (kaliResult.output.isNotBlank()) logs.add(kaliResult.output)
                if (kaliResult.error.isNotBlank()) logs.add("ERR: ${kaliResult.error}")

                memoryBrain.recordCommandUsage("kali $tool $args", "KALI", kaliResult.exitCode)

                if (finalSpokenText.isBlank()) {
                    if (kaliResult.success) {
                        val preview = kaliResult.output.lines().take(3).joinToString(". ")
                        finalSpokenText = "काली टूल $tool पूरा हो गया। $preview"
                    } else {
                        finalSpokenText = "काली टूल $tool में समस्या आई: ${kaliResult.error.ifBlank { "Error" }}."
                    }
                }
            }

            // --- TERMUX COMMAND ENGINE ---
            targetModule == "TERMUX" || intentUpper.contains("TERMUX") -> {
                onStatusChange("Running Tool")
                val cmd = geminiResponse.parameters["command"] ?: geminiResponse.shell_commands.firstOrNull() ?: cleanQuery
                onProgress("Executing in Termux: $cmd...")

                val termuxResult = TermuxCommandEngine.execute(
                    command = cmd,
                    onOutputLine = {
                        onProgress(it)
                        onOutputLine(it)
                    }
                )

                logs.add("Termux Command: exit=${termuxResult.exitCode}")
                if (termuxResult.output.isNotBlank()) logs.add(termuxResult.output)
                if (termuxResult.error.isNotBlank()) logs.add("ERR: ${termuxResult.error}")

                memoryBrain.recordCommandUsage(cmd, "TERMUX", termuxResult.exitCode)

                if (finalSpokenText.isBlank()) {
                    finalSpokenText = if (termuxResult.success) {
                        val preview = termuxResult.output.lines().take(3).joinToString(". ")
                        "टर्मक्स कमांड पूरा हुआ। $preview"
                    } else {
                        val errDesc = termuxResult.error.ifBlank { "Failure" }
                        "टर्मक्स कमांड में समस्या: $errDesc."
                    }
                }
            }

            // --- NETWORK CONTROLLER & CONNECTED DEVICES / WIFI CHIPSET SCAN ---
            targetModule == "NETWORK" || intentUpper.contains("NETWORK") || intentUpper.contains("WIFI") ||
                    intentUpper.contains("PING") || intentUpper.contains("DNS") || intentUpper.contains("CONNECTED") ||
                    queryLower.contains("कौन-कौन") || queryLower.contains("जुड़ा") || queryLower.contains("चिपसेट") -> {
                onStatusChange("Running Tool")
                val action = geminiResponse.parameters["action"]?.uppercase() ?: intentUpper

                when {
                    // Connected devices & Wi-Fi adapter chipset detection
                    action.contains("CONNECTED") || action.contains("DEVICE") || queryLower.contains("कौन-कौन") ||
                            queryLower.contains("जुड़ा") || queryLower.contains("चिपसेट") || queryLower.contains("connected") -> {
                        onProgress("चिपसेट और ड्राइवर चेक हो रहा है...")

                        val chipset = NetworkController.detectWifiChipsetAndDrivers { onProgress(it) }
                        logs.add("Wi-Fi Chipset: ${chipset.chipsetName}")
                        logs.add("Driver: ${chipset.driverName} (Loaded: ${chipset.isDriverLoaded}, Interface: ${chipset.interfaceName})")
                        for (d in chipset.details) logs.add(d)

                        onProgress("नेटवर्क स्कैन हो रहा है...")
                        val connectedDevices = NetworkController.scanNetworkConnectedDevices(context) { onProgress(it) }

                        logs.add("Found ${connectedDevices.size} connected devices:")
                        for (dev in connectedDevices) {
                            logs.add(" - ${dev.ip} [${dev.mac}] (${dev.vendor}) ${if (dev.isGateway) "[ROUTER]" else ""}")
                        }

                        val summaryList = connectedDevices.take(3).map { "${it.ip} (${it.vendor})" }
                        val summaryText = if (summaryList.isNotEmpty()) summaryList.joinToString(", ") else "कोई अन्य डिवाइस नहीं मिला"

                        if (finalSpokenText.isBlank()) {
                            finalSpokenText = "स्कैन पूरा हो गया। वाई-फाई चिपसेट ${chipset.chipsetName} एक्टिव है और कुल ${connectedDevices.size} डिवाइसेज जुड़े हैं: $summaryText."
                        } else {
                            finalSpokenText = "$finalSpokenText नेटवर्क पर कुल ${connectedDevices.size} डिवाइसेज जुड़े हैं: $summaryText."
                        }
                    }

                    action.contains("PING") -> {
                        val host = geminiResponse.parameters["host"] ?: "8.8.8.8"
                        onProgress("Pinging $host...")
                        val (pingOk, pingOut) = NetworkController.pingHost(host)
                        logs.add(pingOut)
                        if (finalSpokenText.isBlank()) {
                            finalSpokenText = if (pingOk) "होस्ट $host पिंग का उत्तर दे रहा है।" else "होस्ट $host तक नहीं पहुंचा जा सका।"
                        }
                    }

                    action.contains("DNS") -> {
                        val host = geminiResponse.parameters["host"] ?: "google.com"
                        onProgress("Resolving DNS for $host...")
                        val ips = NetworkController.dnsLookup(host)
                        logs.add("DNS: ${ips.joinToString(", ")}")
                        if (finalSpokenText.isBlank()) {
                            finalSpokenText = if (ips.isNotEmpty()) "$host का IP ${ips.first()} है।" else "DNS लुकअप असफल रहा।"
                        }
                    }

                    action.contains("WIFI") || action.contains("SCAN") -> {
                        onProgress("Scanning nearby WiFi networks...")
                        val wifiList = NetworkController.scanNearbyWifi(context) { onProgress(it) }
                        logs.add("Found ${wifiList.size} WiFi networks")
                        val preview = wifiList.take(3).joinToString(", ") { it.ssid }
                        if (finalSpokenText.isBlank()) {
                            finalSpokenText = "वाई-फाई स्कैन पूरा हुआ। ${wifiList.size} नेटवर्क्स मिले: $preview."
                        } else {
                            finalSpokenText = "$finalSpokenText ${wifiList.size} नेटवर्क्स मिले: $preview."
                        }
                    }

                    else -> {
                        onProgress("Fetching network interface and IP details...")
                        val info = NetworkController.getNetworkDetails(context)
                        logs.add("IP: ${info.localIp}, Public: ${info.publicIp}, Gateway: ${info.gateway}")
                        if (finalSpokenText.isBlank()) {
                            finalSpokenText = "लोकल IP ${info.localIp} है और गेटवे ${info.gateway} है।"
                        }
                    }
                }
            }

            // --- PHOTO / SELFIE (no camera app, no accessibility) ---
            // Only "take / click / capture a photo", never "open Google Photos".
            Regex("(TAKE|CLICK|CAPTURE|SHOOT|SNAP)_?(A_|THE_|MY_)?(PHOTO|PICTURE|SELFIE|IMAGE)|^SELFIE").containsMatchIn(intentUpper) -> {
                onStatusChange("Executing")
                val facing = com.example.engine.CameraCapture.parseFacing(geminiResponse.parameters["facing"] ?: geminiResponse.parameters["camera"])
                    ?: if (intentUpper.contains("SELFIE")) "front" else null
                if (facing == null) {
                    execSuccess = true
                    finalSpokenText = "FACT: the user wants a photo but did not say which camera, front (selfie) or back. Ask which one."
                } else {
                    onProgress(if (facing == "front") "सेल्फी ले रहा हूँ..." else "फ़ोटो ले रहा हूँ...")
                    val count = geminiResponse.parameters["count"]?.toIntOrNull() ?: 1
                    val shot = com.example.engine.CameraCapture.takePhotos(context, facing, count)
                    execSuccess = shot.success
                    logs.add(shot.detail)
                    finalSpokenText = if (shot.success)
                        "FACT: ${shot.files.size} photo(s) taken with the ${if (facing == "front") "front (selfie)" else "back"} camera and saved in the gallery (DCIM/Camera)."
                    else "FACT: the photo could not be taken (${shot.detail})."
                }
            }

            // --- AUTOMATIONS: rules MAX keeps and runs later by itself ---
            intentUpper.contains("AUTOMATION") || intentUpper.contains("SCHEDULE_TASK") -> {
                onStatusChange("Executing")
                val a = when {
                    Regex("DELETE|REMOVE|CANCEL|STOP|CLEAR").containsMatchIn(intentUpper) -> com.example.engine.Automations.delete(context, geminiResponse.parameters)
                    Regex("LIST|SHOW|READ|WHAT").containsMatchIn(intentUpper) -> com.example.engine.Automations.list(context)
                    else -> com.example.engine.Automations.create(context, geminiResponse.parameters, queryToProcess)
                }
                execSuccess = a.success
                logs.add(a.spoken)
                finalSpokenText = a.spoken
            }

            // --- MAX'S OWN VOICE ---
            intentUpper.contains("SET_VOICE") || intentUpper.contains("VOICE_STYLE") || intentUpper.contains("CHANGE_VOICE") -> {
                onStatusChange("Executing")
                val p = com.example.tts.VoiceStyle.apply(context, geminiResponse.parameters)
                logs.add("Voice profile now pitch=${p.pitch} rate=${p.rate} bass=${p.bass}")
                if (finalSpokenText.isBlank()) finalSpokenText = "आवाज़ बदल दी है, अब इसी में बोलूँगा।"
            }

            // --- READ / LOOK AT THE SCREEN ---
            intentUpper.contains("READ_SCREEN") || intentUpper.contains("SCREEN_READ") || intentUpper.contains("DESCRIBE_SCREEN") ||
                intentUpper.contains("SCREEN_TEXT") || intentUpper.contains("SEE_SCREEN") -> {
                onStatusChange("Executing")
                onProgress("स्क्रीन पढ़ रहा हूँ...")
                val ans = com.example.engine.ScreenReader.answer(
                    context, geminiBrain, apiKey, selectedModel, queryToProcess,
                    geminiResponse.parameters["mode"].orEmpty(), geminiResponse.parameters["focus"].orEmpty()
                )
                execSuccess = ans.success
                logs.add(ans.log)
                finalSpokenText = ans.spoken
            }

            // --- A JOB DONE BY LOOKING AT THE SCREEN AND TAPPING THROUGH IT ---
            intentUpper.contains("SCREEN_TASK") || intentUpper.contains("SCREEN_AGENT") -> {
                onStatusChange("Executing")
                val goal = geminiResponse.parameters["goal"].orEmpty().ifBlank { geminiResponse.goal.ifBlank { queryToProcess } }
                val res = com.example.engine.ScreenAgent.run(context, geminiBrain, apiKey, selectedModel, goal, onProgress)
                execSuccess = res.success
                logs.addAll(res.steps)
                finalSpokenText = res.spoken
            }

            // --- ANSWER / REJECT A CALL ---
            intentUpper.contains("ANSWER_CALL") || intentUpper.contains("PICK_UP") || intentUpper.contains("ACCEPT_CALL") ||
                intentUpper.contains("REJECT_CALL") || intentUpper.contains("DECLINE_CALL") || intentUpper.contains("END_CALL") -> {
                onStatusChange("Executing")
                val res = if (intentUpper.contains("REJECT") || intentUpper.contains("DECLINE") || intentUpper.contains("END"))
                    DeviceController.rejectCall() else DeviceController.answerCall()
                execSuccess = res.success
                logs.add(res.message)
                finalSpokenText = res.message
            }

            // --- DEVICE CONTROLLER ---
            targetModule == "DEVICE" || intentUpper.contains("DEVICE") || intentUpper.contains("VOLUME") ||
                    intentUpper.contains("BRIGHTNESS") || intentUpper.contains("TORCH") || intentUpper.contains("FLASHLIGHT") ||
                    intentUpper.contains("SCREENSHOT") || intentUpper.contains("BLUETOOTH") ||
                    intentUpper.contains("OPEN_APP") || intentUpper.contains("CLOSE_APP") || intentUpper.contains("LAUNCH_APP") ||
                    intentUpper.contains("ALARM") || intentUpper.contains("TIMER") -> {
                onStatusChange("Executing")
                val action = geminiResponse.parameters["action"]?.lowercase() ?: intentUpper.lowercase()

                when {
                    action.contains("alarm") || intentUpper.contains("ALARM") -> {
                        // Gemini says whether this is "set" or "turn off" (DISMISS_ALARM / CANCEL / DISABLE ...).
                        val cancelRegex = Regex("CANCEL|DISMISS|DELETE|DISABLE|REMOVE|TURN_OFF|CLEAR|UNSET|STOP")
                        val wantsCancel = cancelRegex.containsMatchIn(intentUpper) ||
                            cancelRegex.containsMatchIn(action.uppercase().replace("ALARM", "")) ||
                            geminiResponse.parameters["state"].equals("off", true)
                        val out = if (wantsCancel) com.example.engine.CoreActions.cancelAlarm(context, geminiResponse.parameters, queryToProcess)
                            else com.example.engine.CoreActions.alarm(context, geminiResponse.parameters, queryToProcess)
                        execSuccess = out.success
                        logs.addAll(out.logs)
                        finalSpokenText = out.spoken
                    }
                    action.contains("timer") || intentUpper.contains("TIMER") -> {
                        val timerCancel = Regex("CANCEL|DISMISS|DELETE|DISABLE|REMOVE|TURN_OFF|CLEAR|STOP")
                            .containsMatchIn(intentUpper + " " + action.uppercase())
                        val out = if (timerCancel) com.example.engine.CoreActions.cancelTimer(context)
                            else com.example.engine.CoreActions.timer(context, geminiResponse.parameters, queryToProcess)
                        execSuccess = out.success
                        logs.addAll(out.logs)
                        finalSpokenText = out.spoken
                    }
                    action.contains("volume") -> {
                        val volAction = geminiResponse.parameters["level"] ?: geminiResponse.parameters["action"] ?: "up"
                        val pct = geminiResponse.parameters["percent"]?.toIntOrNull()
                        val res = DeviceController.setVolume(context, volAction, pct)
                        logs.add(res.message)
                        if (finalSpokenText.isBlank()) finalSpokenText = res.message
                    }
                    action.contains("brightness") -> {
                        val pct = geminiResponse.parameters["percent"]?.toIntOrNull() ?: 70
                        val res = DeviceController.setBrightness(pct)
                        logs.add(res.message)
                        if (finalSpokenText.isBlank()) finalSpokenText = res.message
                    }
                    action.contains("torch") || action.contains("flashlight") -> {
                        val enable = if (action.contains("on")) true else if (action.contains("off")) false else null
                        val res = DeviceController.toggleFlashlight(context, enable)
                        logs.add(res.message)
                        if (finalSpokenText.isBlank()) finalSpokenText = res.message
                    }
                    action.contains("bluetooth") -> {
                        val enable = !action.contains("off") && !action.contains("disable")
                        val res = DeviceController.toggleBluetooth(enable)
                        logs.add(res.message)
                        if (finalSpokenText.isBlank()) finalSpokenText = res.message
                    }
                    action.contains("wifi") -> {
                        val enable = !action.contains("off") && !action.contains("disable")
                        val res = DeviceController.toggleWiFi(enable)
                        logs.add(res.message)
                        if (finalSpokenText.isBlank()) finalSpokenText = res.message
                    }
                    action.contains("battery") || action.contains("metrics") || action.contains("status") -> {
                        if (action.contains("saver") || action.contains("mode") || action.contains("on") || action.contains("off")) {
                            val enable = !action.contains("off")
                            val res = DeviceController.toggleBatterySaver(enable)
                            logs.add(res.message)
                            if (finalSpokenText.isBlank()) finalSpokenText = res.message
                        } else {
                            val metrics = DeviceController.getSystemMetrics(context)
                            logs.add("Metrics: ${metrics.batteryPct}%, RAM: ${metrics.ramUsedMb}/${metrics.ramTotalMb}MB, Temp: ${metrics.thermalTempCelsius}°C")
                            finalSpokenText = metrics.summaryHindi
                        }
                    }
                    action.contains("screenshot") -> {
                        val res = DeviceController.takeScreenshot()
                        logs.add(res.message)
                        if (finalSpokenText.isBlank()) finalSpokenText = res.message
                    }
                    action.contains("close") || action.contains("stop") -> {
                        val pkg = geminiResponse.target_app.ifBlank { geminiResponse.parameters["app"] ?: "" }
                        val res = DeviceController.closeApp(pkg, context)
                        logs.add(res.message)
                        execSuccess = res.success
                        if (finalSpokenText.isBlank() || !res.success) finalSpokenText = res.message
                    }
                    else -> {
                        val targetApp = geminiResponse.target_app.ifBlank { geminiResponse.parameters["app"] ?: "" }
                        if (targetApp.isNotBlank()) {
                            val res = DeviceController.openApp(context, targetApp)
                            logs.add(res.message)
                            if (finalSpokenText.isBlank()) finalSpokenText = res.message
                        } else {
                            val res = IntentExecutionLayer.execute(context, geminiResponse)
                            logs.addAll(res.details)
                        }
                    }
                }
            }

            // --- ROOT COMMAND ENGINE ---
            targetModule == "ROOT" || geminiResponse.shell_commands.isNotEmpty() -> {
                onStatusChange("Running Tool")
                val cmds = geminiResponse.shell_commands.ifEmpty {
                    val c = geminiResponse.parameters["command"] ?: cleanQuery
                    listOf(c)
                }
                onProgress("Executing root commands...")

                val res = RootCommandEngine.executeBatch(
                    commands = cmds,
                    onProgress = { done, total, cmd ->
                        onProgress("Executing root command $done of $total: $cmd")
                    },
                    onOutputLine = { onOutputLine(it) }
                )

                logs.add("Root Batch Result: exit=${res.exitCode}, success=${res.success}")
                if (res.stdout.isNotBlank()) logs.add(res.stdout)
                if (res.stderr.isNotBlank()) logs.add("ERR: ${res.stderr}")

                for (cmd in cmds) {
                    memoryBrain.recordCommandUsage(cmd, "ROOT", res.exitCode)
                }

                execSuccess = res.success
                if (finalSpokenText.isBlank()) {
                    finalSpokenText = if (res.success) "कमांड सफलतापूर्वक निष्पादित हो गया।" else "रूट कमांड निष्पादन में त्रुटि आई।"
                } else if (!res.success) {
                    finalSpokenText = "कमांड चलाई तो थी, पर उसमें गड़बड़ी आई और वह पूरी नहीं हुई।"
                }
            }

            // --- PURE CHAT & CONVERSATIONAL GATE ---
            targetModule == "CHAT" || intentUpper == "CHAT" || intentUpper == "EXCEPTION" ||
                    intentUpper == "ERROR" || intentUpper == "RATELIMIT" ||
                    intentUpper.contains("GREETING") || intentUpper.contains("QUESTION") ||
                    intentUpper.contains("CONVERSATION") ||
                    geminiResponse.capability.trim().lowercase() == "chat.general" -> {
                Log.d("CHAT_GATE", "VoiceIntentRouter: Pure conversational response (intent='$intentUpper', module='$targetModule'). Bypassing tool execution.")
                logs.add("Chat: Handled conversationally without external execution")
            }

            // --- STANDARD INTENTS (ONLY NON-CHAT) ---
            else -> {
                onStatusChange("Executing")
                val execResult = IntentExecutionLayer.execute(context, geminiResponse)
                logs.addAll(execResult.details)
                execSuccess = execResult.success
                if (!execResult.spokenOverride.isNullOrBlank()) {
                    finalSpokenText = execResult.spokenOverride
                }
            }
        }

        // Every reply is written by Gemini. Where the app produced the sentence (the outcome of a task), that sentence is only the FACT
        // handed to Gemini, who words it for the user; if Gemini is slow or unavailable the plain factual sentence is spoken as it is.
        val appWroteIt = finalSpokenText.isNotBlank() && finalSpokenText.trim() != geminiResponse.spoken_response.trim()
        val isTask = !(targetModule == "CHAT" || intentUpper == "CHAT" || intentUpper == "CLARIFY" || intentUpper == "EXCEPTION" ||
            intentUpper == "ERROR" || intentUpper == "RATELIMIT" || geminiResponse.capability.trim().lowercase() == "chat.general")
        if (appWroteIt && isTask && apiKey.isNotBlank() && streamedChunks == 0) {
            val composed = kotlinx.coroutines.withTimeoutOrNull(3500L) {
                geminiBrain.composeReply(apiKey, selectedModel, queryToProcess, finalSpokenText, execSuccess)
            }
            if (!composed.isNullOrBlank()) finalSpokenText = composed
        }
        // A bare "FACT: ..." line must never be spoken as it is (Gemini was unreachable).
        if (finalSpokenText.startsWith("FACT:")) {
            finalSpokenText = if (finalSpokenText.contains("did not say which camera")) "सेल्फी लूँ या पीछे वाले कैमरे से?" else
                finalSpokenText.removePrefix("FACT:").trim()
        }

        if (finalSpokenText.isBlank()) {
            finalSpokenText = GeminiBrain.fallbackLine()
        }

        onStatusChange("Completed")
        if (unlockedByMax) com.example.engine.ScreenUnlock.lockLater()
        if (execSuccess && isTask) {
            try {
                com.example.engine.HabitTracker.record(context, intentUpper + "|" + (geminiResponse.target_app.ifBlank { geminiResponse.target }.lowercase().take(30)))
            } catch (_: Exception) {}
        }

        RouterResult(
            spokenResponse = GeminiBrain.sanitizeTtsText(finalSpokenText),
            moduleUsed = targetModule.ifBlank { "CORE" },
            details = logs,
            executionSuccess = execSuccess,
            isAwaitingConfirmation = false,
            alreadySpoken = streamedChunks > 0 && geminiResponse.module.trim().uppercase() == "CHAT"
        )
    }
}

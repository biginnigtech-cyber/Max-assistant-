package com.example.brain

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ContextEngine (MAX AI OS)
 *
 * Tracks operational device context, foreground application,
 * active environment modes, battery, network, and recent conversation topics.
 */
class ContextEngine private constructor(private val context: Context) {

    companion object {
        private const val TAG = "ContextEngine"

        @Volatile
        private var INSTANCE: ContextEngine? = null

        fun getInstance(context: Context): ContextEngine {
            return INSTANCE ?: synchronized(this) {
                val instance = ContextEngine(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    enum class OperatingMode {
        NORMAL,
        GOOD_MORNING,
        NIGHT,
        GAMING,
        WORK,
        DRIVING
    }

    data class DeviceContextSnapshot(
        val operatingMode: OperatingMode = OperatingMode.NORMAL,
        val foregroundApp: String = "com.example",
        val batteryLevel: Int = -1,
        val isCharging: Boolean = false,
        val isRootActive: Boolean = false,
        val lastUserQuery: String = "",
        val activeIntent: String = "",
        val timestamp: Long = System.currentTimeMillis()
    )

    private val _contextState = MutableStateFlow(DeviceContextSnapshot())
    val contextState: StateFlow<DeviceContextSnapshot> = _contextState.asStateFlow()

    fun updateForegroundApp(packageName: String) {
        _contextState.value = _contextState.value.copy(
            foregroundApp = packageName,
            timestamp = System.currentTimeMillis()
        )
    }

    fun setOperatingMode(mode: OperatingMode) {
        Log.d(TAG, "Operating mode transitioned to: $mode")
        _contextState.value = _contextState.value.copy(
            operatingMode = mode,
            timestamp = System.currentTimeMillis()
        )
        // Keep sync with MemoryManager gaming mode
        val memoryManager = MemoryManager.getInstance(context)
        memoryManager.setGamingMode(mode == OperatingMode.GAMING)
    }

    fun getOperatingMode(): OperatingMode = _contextState.value.operatingMode

    fun updateRecentInteraction(userQuery: String, intent: String) {
        _contextState.value = _contextState.value.copy(
            lastUserQuery = userQuery,
            activeIntent = intent,
            timestamp = System.currentTimeMillis()
        )
    }

    fun setRootStatus(isRooted: Boolean) {
        _contextState.value = _contextState.value.copy(isRootActive = isRooted)
    }

    fun refreshBatteryState(): Pair<Int, Boolean> {
        return try {
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus: Intent? = context.registerReceiver(null, ifilter)
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val batteryPct = if (level >= 0 && scale > 0) ((level / scale.toFloat()) * 100).toInt() else level

            val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL

            _contextState.value = _contextState.value.copy(
                batteryLevel = batteryPct,
                isCharging = isCharging
            )
            Pair(batteryPct, isCharging)
        } catch (e: Exception) {
            Log.e(TAG, "Error checking battery: ${e.message}")
            Pair(-1, false)
        }
    }

    /**
     * Builds a comprehensive context string for injection into Gemini Brain prompts.
     */
    fun buildContextSummary(): String {
        val current = _contextState.value
        val (batPct, charging) = refreshBatteryState()
        val timeStr = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm (hh:mm a), zzzz", Locale.ENGLISH).format(Date())

        return buildString {
            append("Current Time: $timeStr\n")
            append("Operational Mode: ${current.operatingMode.name}\n")
            append("Foreground App: ${current.foregroundApp}\n")
            append("Battery: ${if (batPct >= 0) "$batPct%" else "Unknown"} ${if (charging) "(Charging)" else ""}\n")
            append("Root Status: ${if (current.isRootActive) "ROOT Magisk UID 0 Active" else "Standard / No Root"}\n")
            if (current.activeIntent.isNotBlank()) {
                append("Active Task/Intent: ${current.activeIntent}\n")
            }
        }
    }
}

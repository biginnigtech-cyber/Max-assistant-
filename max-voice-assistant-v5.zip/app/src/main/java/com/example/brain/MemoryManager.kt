package com.example.brain

import android.content.Context
import android.util.Log
import com.example.data.ContactMemoryEntity
import com.example.data.MaxDatabase
import com.example.data.MemoryItemEntity
import com.example.utils.PreferencesManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class ContactCategory(val label: String, val priority: Int) {
    FAMILY("Family", 10),
    WORK("Work", 7),
    FRIENDS("Friends", 5),
    UNKNOWN("Unknown", 1);

    companion object {
        fun fromString(str: String?): ContactCategory {
            if (str.isNullOrBlank()) return UNKNOWN
            return when (str.trim().uppercase()) {
                "FAMILY", "PARIVAR", "HOME", "MOM", "DAD", "MOTHER", "FATHER", "BROTHER", "SISTER", "WIFE" -> FAMILY
                "WORK", "OFFICE", "BOSS", "CLIENT", "COLLEAGUE", "MANAGER" -> WORK
                "FRIENDS", "FRIEND", "DOST", "BUDDY" -> FRIENDS
                else -> UNKNOWN
            }
        }
    }
}

class MemoryManager private constructor(private val context: Context) {

    companion object {
        private const val TAG = "MemoryManager"

        const val KEY_USER_PREF_RESPECTFUL = "user_prefers_respectful_language"
        const val KEY_ALWAYS_CALL_SIR = "always_call_sir"
        const val KEY_LANGUAGE_HINDI = "user_likes_hindi"
        const val KEY_ROOT_DEVICE = "user_rooted_device"
        const val KEY_KALI_NETHUNTER = "user_uses_kali_nethunter"
        const val KEY_TERMUX = "user_uses_termux"
        const val KEY_FAVORITE_APPS = "favorite_apps"
        const val KEY_GAMING_MODE = "gaming_mode_dnd"

        @Volatile
        private var INSTANCE: MemoryManager? = null

        fun getInstance(context: Context): MemoryManager {
            return INSTANCE ?: synchronized(this) {
                val instance = MemoryManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    private val db = MaxDatabase.getInstance(context)
    private val memoryDao = db.memoryDao()

    // In-memory cache for fast contact priority lookups
    private val contactCache = mutableMapOf<String, ContactCategory>()

    suspend fun initialize() = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Initializing MAX Long-Term Memory & Contact Brain...")

            // 1. Establish permanent user memory
            ensurePermanentMemoryDefaults()

            // 2. Load known contact categories into cache
            val contacts = memoryDao.getAllContacts()
            for (c in contacts) {
                contactCache[normalizeKey(c.contactKey)] = ContactCategory.fromString(c.relationType)
            }

            Log.d(TAG, "MemoryManager initialized with ${contacts.size} contact profiles.")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing MemoryManager: ${e.message}", e)
        }
    }

    private suspend fun ensurePermanentMemoryDefaults() {
        setMemory(KEY_USER_PREF_RESPECTFUL, "true", "personality")
        setMemory(KEY_ALWAYS_CALL_SIR, "true", "personality")
        setMemory(KEY_LANGUAGE_HINDI, "Hindi & Hinglish conversational", "language")
        setMemory(KEY_ROOT_DEVICE, "Rooted Android with Magisk (UID 0)", "system")
        setMemory(KEY_KALI_NETHUNTER, "Kali NetHunter ARM64 chroot active", "system")
        setMemory(KEY_TERMUX, "Termux Linux environment installed", "system")
    }

    private fun normalizeKey(raw: String): String {
        return raw.trim().lowercase().replace(Regex("[^a-z0-9]"), "")
    }

    suspend fun getContactCategory(nameOrNumber: String): ContactCategory = withContext(Dispatchers.IO) {
        val norm = normalizeKey(nameOrNumber)
        if (norm.isBlank()) return@withContext ContactCategory.UNKNOWN

        contactCache[norm]?.let { return@withContext it }

        // Check database
        val entity = memoryDao.getContact(norm)
        if (entity != null) {
            val cat = ContactCategory.fromString(entity.relationType)
            contactCache[norm] = cat
            return@withContext cat
        }

        // Automatic heuristic classification based on title/label
        val rawLower = nameOrNumber.lowercase()
        val detected = when {
            hasWholeWord(rawLower, FAMILY_WORDS) -> ContactCategory.FAMILY

            hasWholeWord(rawLower, WORK_WORDS) -> ContactCategory.WORK

            hasWholeWord(rawLower, listOf("friend", "dost", "yaar", "दोस्त", "यार")) -> ContactCategory.FRIENDS

            else -> ContactCategory.UNKNOWN
        }

        if (detected != ContactCategory.UNKNOWN) {
            registerContact(nameOrNumber, detected, nameOrNumber)
        }

        detected
    }

    suspend fun registerContact(
        nameOrNumber: String,
        category: ContactCategory,
        displayName: String = nameOrNumber,
        notes: String = ""
    ) = withContext(Dispatchers.IO) {
        val norm = normalizeKey(nameOrNumber)
        if (norm.isBlank()) return@withContext

        contactCache[norm] = category
        memoryDao.insertOrUpdateContact(
            ContactMemoryEntity(
                contactKey = norm,
                displayName = displayName,
                relationType = category.name,
                notes = notes,
                lastUpdated = System.currentTimeMillis()
            )
        )
    }

    // Whole words only. "maa" used to match "maaf", "mom" matched "moment", "work" matched "network".
    private fun hasWholeWord(text: String, words: List<String>): Boolean {
        val t = text.lowercase()
        return words.any { w ->
            Regex("(?<![\\p{L}\\p{M}])" + Regex.escape(w) + "(?![\\p{L}\\p{M}])").containsMatchIn(t)
        }
    }

    private val FAMILY_WORDS = listOf(
        "mom", "mum", "mummy", "dad", "daddy", "maa", "mama", "papa", "bhai", "bhaiya", "bhabhi", "didi", "behen", "sister", "brother",
        "wife", "husband", "family", "ghar", "beta", "beti", "dada", "dadi", "nana", "nani", "chacha", "chachi", "mama ji",
        "माँ", "मां", "मम्मी", "पापा", "पिताजी", "भाई", "भैया", "भाभी", "दीदी", "बहन", "पत्नी", "पति", "घर", "परिवार", "बेटा", "बेटी", "दादा", "दादी", "नाना", "नानी", "चाचा", "चाची"
    )
    private val WORK_WORDS = listOf("boss", "manager", "office", "client", "work", "company", "sir", "madam", "hr", "सर", "ऑफिस", "बॉस", "मैनेजर", "क्लाइंट")

    fun isFamilySync(nameOrNumber: String): Boolean {
        val norm = normalizeKey(nameOrNumber)
        contactCache[norm]?.let { return it == ContactCategory.FAMILY }
        return hasWholeWord(nameOrNumber, FAMILY_WORDS)
    }

    fun isFamily(nameOrNumber: String): Boolean {
        return isFamilySync(nameOrNumber)
    }

    fun isWork(nameOrNumber: String): Boolean {
        val norm = normalizeKey(nameOrNumber)
        contactCache[norm]?.let { return it == ContactCategory.WORK }
        return hasWholeWord(nameOrNumber, WORK_WORDS)
    }

    // Gaming Mode / DND management
    fun isGamingMode(): Boolean {
        return try {
            val prefs = context.getSharedPreferences("max_dnd_prefs", Context.MODE_PRIVATE)
            prefs.getBoolean(KEY_GAMING_MODE, false)
        } catch (e: Exception) {
            false
        }
    }

    fun setGamingMode(enabled: Boolean) {
        try {
            val prefs = context.getSharedPreferences("max_dnd_prefs", Context.MODE_PRIVATE)
            prefs.edit().putBoolean(KEY_GAMING_MODE, enabled).apply()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set gaming mode: ${e.message}")
        }
    }

    /**
     * Checks if notification should be spoken when Gaming Mode / DND is active.
     * Rule: If Gaming Mode is ON, ONLY speak:
     * - Incoming Calls
     * - Family messages
     * - OTP / Verification codes
     * - Emergency alerts
     * Everything else silent.
     */
    fun shouldAllowInGamingMode(
        isCall: Boolean,
        isFamilyMessage: Boolean,
        isOtp: Boolean,
        isEmergency: Boolean
    ): Boolean {
        if (!isGamingMode()) return true
        return isCall || isFamilyMessage || isOtp || isEmergency
    }

    // General Key-Value Memory storage
    suspend fun getMemory(key: String): String? = withContext(Dispatchers.IO) {
        memoryDao.getMemoryItem(key)?.value
    }

    suspend fun setMemory(key: String, value: String, category: String = "general") = withContext(Dispatchers.IO) {
        memoryDao.setMemoryItem(MemoryItemEntity(key = key, value = value, category = category))
    }

    suspend fun buildPermanentMemoryContext(): String = withContext(Dispatchers.IO) {
        val sb = StringBuilder()
        sb.append("--- PERMANENT USER PROFILE & CAPABILITIES ---\n")
        sb.append("Owner / User: Mr. Ram Narayan (मिस्टर राम नारायण)\n")
        sb.append("Required Protocol: stay respectful and never use casual terms (bro, bhai, dost, buddy, yaar). Do not open every reply with 'Sir' or the user's name; use an honorific only when it comes naturally.\n")
        sb.append("Preferred Language: Hindi / Hinglish / English natural conversation\n")
        sb.append("System Environment: Rooted Android (Magisk UID 0), Kali NetHunter, Termux\n")
        sb.append("Gaming Mode Status: ${if (isGamingMode()) "ACTIVE (DND Filter On)" else "INACTIVE"}\n")
        sb.append("---------------------------------------------\n")
        sb.toString()
    }
}

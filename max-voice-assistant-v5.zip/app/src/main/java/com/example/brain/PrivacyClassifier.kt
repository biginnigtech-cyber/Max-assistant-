package com.example.brain

import android.util.Log

enum class PrivacyLevel {
    PRIVATE,
    OTP,
    BANK,
    WORK,
    FAMILY,
    NORMAL_CHAT,
    PROMOTION,
    SPAM,
    PUBLIC;

    companion object {
        fun fromString(value: String?): PrivacyLevel {
            if (value.isNullOrBlank()) return NORMAL_CHAT
            return when (value.trim().uppercase().replace(" ", "_")) {
                "PRIVATE", "CONFIDENTIAL", "SECRET", "PERSONAL" -> PRIVATE
                "OTP", "VERIFICATION", "CODE", "2FA" -> OTP
                "BANK", "TRANSACTION", "DEBIT", "CREDIT", "FINANCIAL" -> BANK
                "WORK", "OFFICE", "BUSINESS" -> WORK
                "FAMILY", "HOME" -> FAMILY
                "NORMAL_CHAT", "CHAT", "CONVERSATION" -> NORMAL_CHAT
                "PROMOTION", "OFFER", "DISCOUNT", "MARKETING" -> PROMOTION
                "SPAM", "JUNK" -> SPAM
                "PUBLIC" -> PUBLIC
                else -> NORMAL_CHAT
            }
        }
    }
}

object PrivacyClassifier {
    private const val TAG = "PrivacyClassifier"

    // Heuristics for OTP & Bank verification codes
    private val OTP_PATTERNS = listOf(
        Regex("(?i)\\b(otp|verification code|one time password|security code|auth code|login code)\\b"),
        Regex("(?i)\\b(\\d{4,8})\\b.*\\b(is your|use this|to login|to verify|valid for)\\b"),
        Regex("(?i)\\b(do not share|don't share|kisi ko na batayein)\\b")
    )

    private val BANK_PATTERNS = listOf(
        Regex("(?i)\\b(a/c|acct|account|bank|debited|credited|inr|rs\\.|upi|transferred|balance|statement)\\b"),
        Regex("(?i)\\b(sbi|hdfc|icici|axis|pnb|paytm|phonepe|gpay)\\b")
    )

    private val PRIVATE_PATTERNS = listOf(
        Regex("(?i)\\b(secret|private|personal|confidential|dont tell|kisi ko mat batana|raaz|password|pin)\\b"),
        Regex("(?i)\\b(love you|miss you|kiss|jaan|baby|shona|darling)\\b")
    )

    // Specific marketing phrases only. Bare "off", "sale", "deal" or "hurry" silenced real messages like "I'm off today".
    private val PROMO_PATTERNS = listOf(
        Regex("(?i)(\\d+\\s*%\\s*(off|discount|cashback)|flat\\s*\\d+|cashback|coupon|promo\\s*code|buy\\s*1\\s*get\\s*1|exclusive offer|limited[\\s-]*time|sale\\s+(is\\s+)?(live|ends|now)|unsubscribe)")
    )

    /**
     * Fallback offline classifier when Gemini API is unavailable.
     */
    fun classifyLocally(title: String, text: String, isFamilySender: Boolean): PrivacyLevel {
        val combined = "$title $text"

        // 1. Check Family
        if (isFamilySender) {
            return PrivacyLevel.FAMILY
        }

        // 2. Check OTP
        for (pattern in OTP_PATTERNS) {
            if (pattern.containsMatchIn(combined)) {
                return PrivacyLevel.OTP
            }
        }

        // 3. Check Bank
        for (pattern in BANK_PATTERNS) {
            if (pattern.containsMatchIn(combined)) {
                return PrivacyLevel.BANK
            }
        }

        // 4. Check Private
        for (pattern in PRIVATE_PATTERNS) {
            if (pattern.containsMatchIn(combined)) {
                return PrivacyLevel.PRIVATE
            }
        }

        // 5. Check Promo
        for (pattern in PROMO_PATTERNS) {
            if (pattern.containsMatchIn(combined)) {
                return PrivacyLevel.PROMOTION
            }
        }

        return PrivacyLevel.NORMAL_CHAT
    }

    /**
     * Safely extracts numeric OTP digits for when user explicitly requests reading it.
     */
    fun extractOtpCode(text: String): String? {
        // The number next to the words OTP / code / कोड first. "Rs 5000 debited ... OTP 123456" must give 123456, not 5000.
        Regex("(?i)(?:otp|code|कोड|passcode|password|pin)\\D{0,25}(\\d{4,8})").find(text)?.let { return it.groupValues[1] }
        Regex("(?i)(\\d{4,8})\\D{0,20}(?:is your|is the|otp|code)").find(text)?.let { return it.groupValues[1] }
        for (m in Regex("\\b(\\d{4,8})\\b").findAll(text)) {
            val before = text.substring(0, m.range.first).takeLast(4).lowercase()
            val after = text.substring(m.range.last + 1).take(2)
            if (before.contains("rs") || before.contains("inr") || before.contains("₹") || before.contains("$") || after.contains("%")) continue
            return m.groupValues[1]
        }
        return null
    }
}

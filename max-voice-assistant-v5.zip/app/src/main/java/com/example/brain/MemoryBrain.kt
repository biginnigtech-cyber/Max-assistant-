package com.example.brain

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import com.example.data.CommandHistoryEntity
import com.example.data.MaxDatabase
import com.example.data.MemoryItemEntity
import com.example.engine.KaliCommandEngine
import com.example.engine.RootCommandEngine
import com.example.engine.TermuxCommandEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class MemoryBrain private constructor(private val context: Context) {

    companion object {
        private const val TAG = "MemoryBrain"

        const val KEY_USER_NAME = "user_name"
        const val KEY_PREFERRED_LANGUAGE = "preferred_language"
        const val KEY_ROOT_STATUS = "root_status"
        const val KEY_TERMUX_STATUS = "termux_status"
        const val KEY_KALI_TOOLS = "kali_tools"
        const val KEY_INSTALLED_APPS_SUMMARY = "installed_apps_summary"
        const val KEY_USER_PREFERENCES = "user_preferences"

        @Volatile
        private var INSTANCE: MemoryBrain? = null

        fun getInstance(context: Context): MemoryBrain {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: MemoryBrain(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    private val db = MaxDatabase.getInstance(context)
    private val memoryDao = db.memoryDao()

    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized.asStateFlow()

    // In-memory quick cache
    private val cache = mutableMapOf<String, String>()

    suspend fun initializeOnStartup() = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Initializing MAX MemoryBrain...")
            val items = memoryDao.getAllMemoryItems()
            for (item in items) {
                cache[item.key] = item.value
            }

            // Defaults if not set
            if (!cache.containsKey(KEY_USER_NAME)) {
                setMemory(KEY_USER_NAME, "Mr. Ram Narayan", "profile")
            }
            if (!cache.containsKey(KEY_PREFERRED_LANGUAGE)) {
                setMemory(KEY_PREFERRED_LANGUAGE, "Hinglish/Hindi/English", "profile")
            }

            // Check & refresh device capabilities in background
            refreshSystemProfile()

            _isInitialized.value = true
            Log.d(TAG, "MAX MemoryBrain initialized with ${cache.size} items.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize MemoryBrain: ${e.message}", e)
        }
    }

    suspend fun refreshSystemProfile() = withContext(Dispatchers.IO) {
        try {
            // 1. Root status check
            val isRoot = RootCommandEngine.isRootAvailable()
            setMemory(KEY_ROOT_STATUS, if (isRoot) "AVAILABLE (UID 0 root granted)" else "UNAVAILABLE", "hardware")

            // 2. Termux check
            val isTermux = TermuxCommandEngine.isTermuxInstalled(context)
            setMemory(KEY_TERMUX_STATUS, if (isTermux) "INSTALLED (${TermuxCommandEngine.TERMUX_PREFIX})" else "NOT INSTALLED", "software")

            // 3. Kali NetHunter check & tools
            val kaliTools = KaliCommandEngine.getAvailableKaliTools()
            val kaliSummary = if (kaliTools.isNotEmpty()) {
                kaliTools.joinToString(", ")
            } else {
                "Kali NetHunter chroot active, checking installed tools."
            }
            setMemory(KEY_KALI_TOOLS, kaliSummary, "security")

            // 4. Installed apps list summary
            val pm = context.packageManager
            val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { it.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM == 0 }
                .take(30)
                .map { pm.getApplicationLabel(it).toString() + " (${it.packageName})" }
            setMemory(KEY_INSTALLED_APPS_SUMMARY, apps.joinToString("; "), "system")
        } catch (e: Exception) {
            Log.e(TAG, "Error refreshing system profile: ${e.message}")
        }
    }

    suspend fun getMemory(key: String): String? = withContext(Dispatchers.IO) {
        cache[key] ?: memoryDao.getMemoryItem(key)?.value
    }

    suspend fun setMemory(key: String, value: String, category: String = "general") = withContext(Dispatchers.IO) {
        cache[key] = value
        memoryDao.setMemoryItem(MemoryItemEntity(key = key, value = value, category = category))
    }

    suspend fun recordCommandUsage(command: String, module: String, exitCode: Int) = withContext(Dispatchers.IO) {
        val existing = memoryDao.findCommand(command)
        if (existing != null) {
            memoryDao.insertOrUpdateCommand(
                existing.copy(
                    usageCount = existing.usageCount + 1,
                    timestamp = System.currentTimeMillis(),
                    exitCode = exitCode
                )
            )
        } else {
            memoryDao.insertOrUpdateCommand(
                CommandHistoryEntity(
                    command = command,
                    module = module,
                    exitCode = exitCode,
                    usageCount = 1
                )
            )
        }
    }

    suspend fun getFrequentlyUsedCommands(limit: Int = 10): List<CommandHistoryEntity> = withContext(Dispatchers.IO) {
        memoryDao.getFrequentCommands(limit)
    }

    /**
     * Builds structured memory context to inject into Gemini prompt
     */
    suspend fun buildMemoryContextPrompt(): String = withContext(Dispatchers.IO) {
        val sb = StringBuilder()
        sb.append("--- LONG-TERM DEVICE & USER MEMORY ---\n")
        sb.append("Owner / User: ${getMemory(KEY_USER_NAME) ?: "Mr. Ram Narayan"}\n")
        sb.append("Preferred Language: ${getMemory(KEY_PREFERRED_LANGUAGE) ?: "Hindi / Hinglish / English"}\n")
        sb.append("Root Status: ${getMemory(KEY_ROOT_STATUS) ?: "Unknown"}\n")
        sb.append("Termux Environment: ${getMemory(KEY_TERMUX_STATUS) ?: "Unknown"}\n")
        sb.append("Kali Security Tools: ${getMemory(KEY_KALI_TOOLS) ?: "None detected"}\n")

        val frequentCmds = getFrequentlyUsedCommands(5)
        if (frequentCmds.isNotEmpty()) {
            sb.append("Frequently Used Commands: ")
            sb.append(frequentCmds.joinToString(", ") { "${it.module}:${it.command} (${it.usageCount}x)" })
            sb.append("\n")
        }

        val apps = getMemory(KEY_INSTALLED_APPS_SUMMARY)
        if (!apps.isNullOrBlank()) {
            sb.append("Known Installed Apps: $apps\n")
        }
        sb.append("--------------------------------------\n")
        sb.toString()
    }
}

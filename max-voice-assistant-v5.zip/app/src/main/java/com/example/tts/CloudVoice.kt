package com.example.tts

import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Natural, human-sounding voice from the Gemini text-to-speech model.
 * Returns raw PCM (24 kHz, mono, 16-bit). On any problem it returns null and the caller falls back
 * to the phone's own voice; after a failure it pauses itself for a while so MAX never waits twice.
 */
object CloudVoice {
    private const val TAG = "CloudVoice"
    const val DEFAULT_MODEL = "gemini-3.1-flash-tts-preview"
    const val DEFAULT_VOICE = "Algenib"   // calm, mature male voice; other options: Orus, Fenrir, Puck, Algenib, Gacrux
    const val SAMPLE_RATE = 24000

    private const val STYLE =
        "Say this in a very deep, heavy, resonant, slow and commanding voice, like a vast calm machine intelligence, " +
            "low pitched with a metallic weight, unhurried, every word deliberate, with controlled menace and dry wit"

    @Volatile private var pausedUntil = 0L

    fun isAvailable(): Boolean = System.currentTimeMillis() >= pausedUntil

    private fun pauseFor(ms: Long) {
        pausedUntil = System.currentTimeMillis() + ms
    }

    /** At most two parts: a short first part so speech starts quickly, then the rest. */
    fun splitForSpeech(text: String): List<String> {
        val t = text.trim()
        if (t.length <= 170) return listOf(t)
        val sentences = t.split(Regex("(?<=[।.!?])\\s+")).filter { it.isNotBlank() }
        if (sentences.size < 2) return listOf(t)
        val first = StringBuilder()
        var idx = 0
        while (idx < sentences.size - 1 && first.length < 90) {
            if (first.isNotEmpty()) first.append(' ')
            first.append(sentences[idx])
            idx++
        }
        val rest = sentences.drop(idx).joinToString(" ")
        return if (rest.isBlank()) listOf(first.toString()) else listOf(first.toString(), rest)
    }

    /** Blocking network call: run it on a background dispatcher. */
    fun synthesize(apiKey: String, text: String, model: String, voice: String): ByteArray? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", apiKey)
            }
            val body = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "$STYLE: $text")))))
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().put("AUDIO"))
                    put("speechConfig", JSONObject().put("voiceConfig",
                        JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))))
                })
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code !in 200..299) {
                val err = try { conn.errorStream?.bufferedReader()?.readText()?.take(300) } catch (e: Exception) { "" }
                Log.w(TAG, "Cloud voice HTTP $code: $err")
                when (code) {
                    429 -> pauseFor(90_000L)          // quota: let the phone voice take over for a while
                    in 500..599 -> pauseFor(30_000L)
                    else -> pauseFor(300_000L)        // bad model name / key / permissions
                }
                return null
            }
            val response = conn.inputStream.bufferedReader().use { it.readText() }
            val data = JSONObject(response)
                .getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getJSONObject("inlineData").getString("data")
            val pcm = Base64.decode(data, Base64.DEFAULT)
            if (pcm.isEmpty()) null else pcm
        } catch (e: Exception) {
            Log.w(TAG, "Cloud voice failed: ${e.message}")
            pauseFor(15_000L)
            null
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }
}

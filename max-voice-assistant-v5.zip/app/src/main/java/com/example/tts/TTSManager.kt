package com.example.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.utils.PreferencesManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import java.util.Locale

class TTSManager private constructor(private val appContext: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var isFallbackAttempted = false
    private val pendingUtterances = mutableListOf<String>()

    @Volatile
    var lastSpokenText: String = ""
        private set

    @Volatile
    var lastSpokenTimestamp: Long = 0L
        private set

    @Volatile
    var isSpeaking: Boolean = false
        private set

    private var onStartCallback: (() -> Unit)? = null
    private var onDoneCallback: (() -> Unit)? = null
    private var onErrorCallback: (() -> Unit)? = null

    companion object {
        private const val TAG = "TTSManager"
        private const val GOOGLE_TTS_ENGINE = "com.google.android.tts"

        @Volatile
        private var INSTANCE: TTSManager? = null

        fun getInstance(context: Context): TTSManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: TTSManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    init {
        initializeTtsEngine()
    }

    private fun initializeTtsEngine() {
        try {
            Log.d(TAG, "Initializing TTS with Google Engine: $GOOGLE_TTS_ENGINE")
            tts = TextToSpeech(appContext, this, GOOGLE_TTS_ENGINE)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Google TTS engine, falling back to default engine", e)
            tts = TextToSpeech(appContext, this)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val engineName = tts?.defaultEngine ?: "unknown"
            Log.d(TAG, "TTS Engine Initialized successfully. Engine: $engineName")
            isInitialized = true

            // Configure audio attributes for hardware Acoustic Echo Cancellation (AEC)
            try {
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                tts?.setAudioAttributes(audioAttributes)
            } catch (e: Exception) {
                Log.w(TAG, "Failed to set audio attributes: ${e.message}")
            }

            // Fine-tune natural voice parameters (rate 0.98x, pitch 1.0)
            applyVoice()

            // Default initial voice setup
            configureHighQualityVoice(Locale("en", "IN"))

            setupUtteranceProgressListener()

            for (text in pendingUtterances) {
                speakInternal(text)
            }
            pendingUtterances.clear()
            val waiting = synchronized(pendingIndependent) { pendingIndependent.toList().also { pendingIndependent.clear() } }
            for ((t, cb) in waiting) speakIndependent(t, cb)
        } else {
            Log.e(TAG, "TTS Initialization failed with status: $status")
            if (!isFallbackAttempted) {
                isFallbackAttempted = true
                Log.w(TAG, "Retrying TTS initialization with system default engine...")
                try {
                    tts?.shutdown()
                } catch (ignored: Exception) {}
                tts = TextToSpeech(appContext, this)
            }
        }
    }

    private fun configureHighQualityVoice(targetLocale: Locale) {
        val ttsInstance = tts ?: return

        try {
            val langResult = ttsInstance.setLanguage(targetLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "Locale $targetLocale not fully supported. Fallback to US English.")
                ttsInstance.setLanguage(Locale.US)
            }

            val availableVoices = ttsInstance.voices
            if (availableVoices.isNullOrEmpty()) {
                Log.d(TAG, "No custom voice list available, using setLanguage locale.")
                return
            }

            // Filter voices for matching language
            val matchingVoices = availableVoices.filter { voice ->
                voice.locale.language.equals(targetLocale.language, ignoreCase = true)
            }

            if (matchingVoices.isEmpty()) {
                Log.d(TAG, "No specific voices found for language ${targetLocale.language}")
                return
            }

            // Prioritize Neural, Network, and High Quality voices
            val bestVoice = matchingVoices.maxByOrNull { voice ->
                var score = 0
                val voiceNameLower = voice.name.lowercase(Locale.ROOT)

                // High-quality neural / network voice indicators
                if (voiceNameLower.contains("network") ||
                    voiceNameLower.contains("neural") ||
                    voiceNameLower.contains("wavenet") ||
                    voiceNameLower.contains("natural") ||
                    voiceNameLower.contains("cgd") ||
                    voiceNameLower.contains("sfg") ||
                    voiceNameLower.contains("hie")) {
                    score += 100
                }

                if (voice.quality >= Voice.QUALITY_HIGH) {
                    score += 50
                }
                if (voice.quality >= Voice.QUALITY_VERY_HIGH) {
                    score += 30
                }

                if (voice.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NETWORK_SYNTHESIS) == true) {
                    score += 40
                }

                // Regional match bonus
                if (voice.locale.country.equals(targetLocale.country, ignoreCase = true)) {
                    score += 20
                }

                score
            }

            if (bestVoice != null) {
                val result = ttsInstance.setVoice(bestVoice)
                Log.d(TAG, "Configured Neural/HQ Voice: ${bestVoice.name} (Locale: ${bestVoice.locale}, Quality: ${bestVoice.quality}, Result: $result)")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error configuring high quality voice: ${e.message}")
        }
    }

    private fun setupUtteranceProgressListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                Log.d(TAG, "TTS Utterance started: $utteranceId")
                if (utteranceId != null && oneShotCallbacks.containsKey(utteranceId)) return
                isSpeaking = true
                if (inStream) {
                    val sendStart: Boolean
                    synchronized(streamLock) { sendStart = !streamStartSent; streamStartSent = true }
                    if (sendStart) onStartCallback?.invoke()
                } else {
                    onStartCallback?.invoke()
                }
            }

            override fun onDone(utteranceId: String?) {
                Log.d(TAG, "TTS Utterance completed: $utteranceId")
                oneShotCallbacks.remove(utteranceId ?: "")?.let { it(); return }
                lastSpokenTimestamp = System.currentTimeMillis()
                if (inStream) {
                    val allDone: Boolean
                    synchronized(streamLock) { allDone = queuedCount.decrementAndGet() <= 0 && !streamOpen }
                    if (allDone) finishStream() else isSpeaking = queuedCount.get() > 0
                } else {
                    isSpeaking = false
                    onDoneCallback?.invoke()
                }
            }

            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                Log.d(TAG, "TTS Utterance stopped (interrupted=$interrupted): $utteranceId")
                oneShotCallbacks.remove(utteranceId ?: "")?.let { it(); return }
                // Inside a stream a stop only means the next sentence flushed the previous one: not the end.
                if (inStream) return
                isSpeaking = false
                lastSpokenTimestamp = System.currentTimeMillis()
                onDoneCallback?.invoke()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                Log.e(TAG, "TTS Utterance error: $utteranceId")
                isSpeaking = false
                lastSpokenTimestamp = System.currentTimeMillis()
                onErrorCallback?.invoke()
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                Log.e(TAG, "TTS Utterance error ($errorCode): $utteranceId")
                oneShotCallbacks.remove(utteranceId ?: "")?.let { it(); return }
                lastSpokenTimestamp = System.currentTimeMillis()
                if (inStream) {
                    val allDone: Boolean
                    synchronized(streamLock) { allDone = queuedCount.decrementAndGet() <= 0 && !streamOpen }
                    if (allDone) finishStream()
                } else {
                    isSpeaking = false
                    onErrorCallback?.invoke()
                }
            }
        })
    }

    fun setUtteranceCallbacks(
        onStart: (() -> Unit)? = null,
        onDone: (() -> Unit)? = null,
        onError: (() -> Unit)? = null
    ) {
        this.onStartCallback = onStart
        this.onDoneCallback = onDone
        this.onErrorCallback = onError
        if (isInitialized) {
            setupUtteranceProgressListener()
        }
    }

    // ---- Voice profile: pitch / speed from the settings, plus bass, equaliser and a hall reverb on the speech's audio session.
    private var ttsSessionId = 0
    private var bassBoost: android.media.audiofx.BassBoost? = null
    private var equalizer: android.media.audiofx.Equalizer? = null
    private var reverb: android.media.audiofx.PresetReverb? = null
    private var loudness: android.media.audiofx.LoudnessEnhancer? = null
    private var appliedBass = -1

    private fun releaseEffects() {
        try { bassBoost?.release() } catch (_: Exception) {}
        try { equalizer?.release() } catch (_: Exception) {}
        try { reverb?.release() } catch (_: Exception) {}
        try { loudness?.release() } catch (_: Exception) {}
        bassBoost = null; equalizer = null; reverb = null; loudness = null
    }

    private fun applyVoice() {
        val pitch = PreferencesManager.getVoicePitch(appContext)
        val rate = PreferencesManager.getVoiceRate(appContext)
        tts?.setPitch(pitch)
        tts?.setSpeechRate(rate)
        val bass = PreferencesManager.getVoiceBass(appContext)
        val gain = PreferencesManager.getVoiceGain(appContext)
        val key = bass * 10000 + gain
        if (key == appliedBass) return
        appliedBass = key
        releaseEffects()
        try {
            if (ttsSessionId == 0) {
                ttsSessionId = (appContext.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager).generateAudioSessionId()
            }
        } catch (e: Exception) { Log.w(TAG, "No audio session for effects: ${e.message}"); return }
        // Each effect is optional: phones differ, and a missing one must never stop MAX from speaking.
        if (bass > 0) {
            try {
                bassBoost = android.media.audiofx.BassBoost(0, ttsSessionId).apply {
                    if (strengthSupported) setStrength(bass.coerceIn(0, 1000).toShort())
                    enabled = true
                }
            } catch (e: Exception) { Log.w(TAG, "BassBoost unavailable: ${e.message}") }
        }
        // Equaliser shaped for a small phone speaker. It cannot play the lowest octave, so boosting there only eats loudness
        // (that was the "hand over the speaker" sound together with the call audio mode). Weight comes from 100-400 Hz and the
        // words from a strong lift at 1.5-6 kHz; nothing is cut.
        try {
            equalizer = android.media.audiofx.Equalizer(0, ttsSessionId).apply {
                val max = bandLevelRange[1].toInt()
                for (b in 0 until numberOfBands) {
                    val hz = getCenterFreq(b.toShort()) / 1000
                    val level = when {
                        hz < 100 -> (max * 0.10).toInt()
                        hz < 400 -> (max * 0.55).toInt()
                        hz < 1500 -> (max * 0.20).toInt()
                        hz < 6000 -> (max * 0.70).toInt()
                        else -> (max * 0.25).toInt()
                    }
                    setBandLevel(b.toShort(), level.toShort())
                }
                enabled = true
            }
        } catch (e: Exception) { Log.w(TAG, "Equalizer unavailable: ${e.message}") }
        // No reverb: a hall reverb smears the words and made the voice sound like speaking with a closed mouth.
        if (gain > 0) {
            try {
                loudness = android.media.audiofx.LoudnessEnhancer(ttsSessionId).apply { setTargetGain(gain.coerceIn(0, 2000)); enabled = true }
            } catch (e: Exception) { Log.w(TAG, "LoudnessEnhancer unavailable: ${e.message}") }
        }
    }

    private fun withSession(params: Bundle): Bundle {
        if (ttsSessionId != 0) params.putInt(TextToSpeech.Engine.KEY_PARAM_SESSION_ID, ttsSessionId)
        return params
    }

    // ---- Independent one-shot speech (notifications). It never touches the callbacks of the voice service,
    //      so a spoken notification can no longer break the microphone state machine.
    private val oneShotCallbacks = java.util.concurrent.ConcurrentHashMap<String, () -> Unit>()
    private val pendingIndependent = mutableListOf<Pair<String, (() -> Unit)?>>()

    fun speakIndependent(text: String, onFinished: (() -> Unit)? = null) {
        if (text.isBlank()) { onFinished?.invoke(); return }
        if (!isInitialized) { synchronized(pendingIndependent) { pendingIndependent.add(Pair(text, onFinished)) }; return }
        val cleaned = com.example.brain.VoicePersonalityManager.enforceRespectfulAddress(text).trim()
        val locale = if (containsHindi(cleaned)) Locale("hi", "IN") else Locale("en", "IN")
        if (lastConfiguredLocale != locale) { configureHighQualityVoice(locale); lastConfiguredLocale = locale }
        val id = "MAX_ONESHOT_" + System.nanoTime()
        if (onFinished != null) oneShotCallbacks[id] = onFinished
        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, id)
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        applyVoice()
        withSession(params)
        val rc = tts?.speak(cleaned, TextToSpeech.QUEUE_ADD, params, id)
        if (rc != TextToSpeech.SUCCESS) oneShotCallbacks.remove(id)?.invoke()
    }

    // ---- Streaming speech: sentences arrive while Gemini is still writing; "done" is reported once, at the very end.
    private val streamLock = Any()
    private val queuedCount = java.util.concurrent.atomic.AtomicInteger(0)
    @Volatile private var inStream = false
    @Volatile private var streamOpen = false
    @Volatile private var streamStartSent = false
    @Volatile private var lastConfiguredLocale: Locale? = null

    fun beginStream() {
        synchronized(streamLock) {
            inStream = true
            streamOpen = true
            streamStartSent = false
            queuedCount.set(0)
        }
    }

    /** Native phone voice only. The first sentence flushes anything stale, the rest are queued behind it. */
    fun speakStreamed(text: String) {
        if (text.isBlank()) return
        if (!isInitialized) { pendingUtterances.add(text); return }
        val cleaned = com.example.brain.VoicePersonalityManager.enforceRespectfulAddress(text).trim()
        if (cleaned.isBlank()) return
        val locale = if (containsHindi(cleaned)) Locale("hi", "IN") else Locale("en", "IN")
        if (lastConfiguredLocale != locale) { configureHighQualityVoice(locale); lastConfiguredLocale = locale }
        applyVoice()
        val params = Bundle()
        val id = "MAX_STREAM_" + System.nanoTime()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, id)
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        withSession(params)
        val first: Boolean
        synchronized(streamLock) {
            first = queuedCount.get() == 0
            queuedCount.incrementAndGet()
        }
        lastSpokenText = if (first) cleaned else (lastSpokenText + " " + cleaned).trim()
        lastSpokenTimestamp = System.currentTimeMillis()
        val rc = tts?.speak(cleaned, if (first) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, params, id)
        if (rc != TextToSpeech.SUCCESS) {
            synchronized(streamLock) { queuedCount.decrementAndGet() }
        }
    }

    /** Gemini finished writing. If everything was already spoken, report "done" now; otherwise the last sentence will. */
    fun endStream() {
        val finishNow: Boolean
        synchronized(streamLock) {
            streamOpen = false
            finishNow = inStream && queuedCount.get() <= 0 && !isSpeaking
        }
        if (finishNow) finishStream()
    }

    private fun finishStream() {
        synchronized(streamLock) {
            inStream = false
            streamStartSent = false
        }
        isSpeaking = false
        lastSpokenTimestamp = System.currentTimeMillis()
        onDoneCallback?.invoke()
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        val cloudKey = cloudKeyIfUsable()
        if (cloudKey != null) {
            speakCloud(text, cloudKey)
        } else {
            speakNative(text)
        }
    }

    private fun speakNative(text: String) {
        if (isInitialized) {
            speakInternal(text)
        } else {
            pendingUtterances.add(text)
        }
    }

    // ------------------------------------------------------------------
    // Natural human-sounding voice (Gemini TTS). The phone's own voice is the backup.
    // ------------------------------------------------------------------

    private val cloudScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var cloudJob: Job? = null
    @Volatile private var activeTrack: AudioTrack? = null
    @Volatile private var cloudActive = false

    private class CloudVoiceUnavailable : Exception()

    private fun cloudKeyIfUsable(): String? {
        return try {
            if (!PreferencesManager.isCloudVoiceEnabled(appContext)) return null
            if (!CloudVoice.isAvailable()) return null
            PreferencesManager.getApiKey(appContext).ifBlank { null }
        } catch (e: Exception) {
            null
        }
    }

    private fun buildTrack(): AudioTrack {
        val minBuf = AudioTrack.getMinBufferSize(
            CloudVoice.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(CloudVoice.SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, CloudVoice.SAMPLE_RATE * 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track.setVolume(0.85f) // slightly softer than the music
        return track
    }

    private fun finishCloud() {
        cloudActive = false
        isSpeaking = false
        lastSpokenTimestamp = System.currentTimeMillis()
        onDoneCallback?.invoke()
    }

    private fun cancelCloud(notify: Boolean) {
        val wasActive = cloudActive
        cloudJob?.cancel()
        cloudJob = null
        activeTrack?.let {
            try { it.pause(); it.flush() } catch (_: Exception) {}
        }
        cloudActive = false
        if (wasActive && notify) {
            isSpeaking = false
            lastSpokenTimestamp = System.currentTimeMillis()
            onDoneCallback?.invoke()
        }
    }

    private fun speakCloud(rawText: String, apiKey: String) {
        val text = com.example.brain.VoicePersonalityManager.enforceRespectfulAddress(rawText).trim()
        cancelCloud(notify = false)
        lastSpokenText = text
        lastSpokenTimestamp = System.currentTimeMillis()
        cloudActive = true
        val model = PreferencesManager.getCloudVoiceModel(appContext)
        val voice = PreferencesManager.getCloudVoiceName(appContext)

        cloudJob = cloudScope.launch {
            var track: AudioTrack? = null
            var started = false
            var totalFrames = 0L
            try {
                val parts = CloudVoice.splitForSpeech(text)
                val pending = parts.map { part -> async { CloudVoice.synthesize(apiKey, part, model, voice) } }

                for (job in pending) {
                    val pcm = job.await()
                    if (pcm == null) {
                        if (!started) throw CloudVoiceUnavailable()
                        break // part of the answer was already spoken: do not repeat it in another voice
                    }
                    ensureActive()
                    val t = track ?: buildTrack().also {
                        track = it
                        activeTrack = it
                    }
                    if (!started) {
                        started = true
                        isSpeaking = true
                        onStartCallback?.invoke()
                        t.play()
                    }
                    var off = 0
                    while (off < pcm.size) {
                        ensureActive()
                        val n = minOf(4800, pcm.size - off)
                        val written = t.write(pcm, off, n)
                        if (written <= 0) break
                        off += written
                    }
                    totalFrames += (pcm.size / 2).toLong()
                }

                val t = track
                if (started && t != null) {
                    var guard = 0
                    while (t.playbackHeadPosition.toLong() < totalFrames && guard < 1200) {
                        ensureActive()
                        delay(50L)
                        guard++
                    }
                    delay(120L)
                }
                finishCloud()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Natural voice unavailable, using the phone voice: ${e.message}")
                cloudActive = false
                isSpeaking = false
                speakNative(text)
            } finally {
                try { track?.stop() } catch (_: Exception) {}
                try { track?.release() } catch (_: Exception) {}
                if (activeTrack === track) activeTrack = null
            }
        }
    }

    private fun containsHindi(text: String): Boolean {
        return text.any { ch -> ch in '\u0900'..'\u097F' }
    }

    private fun speakInternal(text: String) {
        val sanitizedText = com.example.brain.VoicePersonalityManager.enforceRespectfulAddress(text)
        lastSpokenText = sanitizedText.trim()
        lastSpokenTimestamp = System.currentTimeMillis()

        val targetLocale = if (containsHindi(sanitizedText)) Locale("hi", "IN") else Locale("en", "IN")
        // Scoring every installed voice before each sentence cost time: do it only when the language changes.
        if (lastConfiguredLocale != targetLocale) {
            configureHighQualityVoice(targetLocale)
            lastConfiguredLocale = targetLocale
        }

        // Ensure smooth rate & pitch before each utterance
        applyVoice()

        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "MAX_UTTERANCE_" + System.currentTimeMillis())
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        withSession(params)

        tts?.speak(sanitizedText, TextToSpeech.QUEUE_FLUSH, params, "MAX_UTTERANCE_" + System.currentTimeMillis())
    }

    fun stop() {
        synchronized(streamLock) {
            inStream = false
            streamOpen = false
            streamStartSent = false
            queuedCount.set(0)
        }
        cancelCloud(notify = true)
        isSpeaking = false
        lastSpokenTimestamp = System.currentTimeMillis()
        tts?.stop()
    }

    fun shutdown() {
        releaseEffects()
        cancelCloud(notify = false)
        tts?.stop()
        tts?.shutdown()
        tts = null
        INSTANCE = null
    }
}


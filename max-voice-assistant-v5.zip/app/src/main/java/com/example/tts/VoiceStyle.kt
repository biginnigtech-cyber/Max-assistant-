package com.example.tts

import android.content.Context
import com.example.utils.PreferencesManager

/**
 * The voice MAX speaks with: a deep, heavy, slow, metallic voice (Ultron-like) by default.
 * Gemini decides when to change it ("आवाज़ और भारी करो", "normal आवाज़ में बोलो") and returns the numbers or a
 * relative change; this class only keeps them in range and stores them.
 */
object VoiceStyle {

    data class Profile(val pitch: Float, val rate: Float, val bass: Int, val gain: Int = 1000)

    // A phone speaker cannot play real bass, and a very low pitch makes the voice quiet and dull. So: a moderately low pitch for
    // the weight, normal speed, a lift in the "presence" range (clarity) and a strong loudness gain, with only a little bass.
    val ULTRON = Profile(pitch = 0.66f, rate = 1.0f, bass = 450, gain = 1100)
    val DEEP = Profile(pitch = 0.78f, rate = 1.0f, bass = 300, gain = 900)
    val NORMAL = Profile(pitch = 1.0f, rate = 1.0f, bass = 0, gain = 600)

    private fun clamp(p: Profile) = Profile(p.pitch.coerceIn(0.3f, 1.6f), p.rate.coerceIn(0.5f, 1.5f), p.bass.coerceIn(0, 1000), p.gain.coerceIn(0, 2000))

    /** Pure function (unit-tested): the new profile from the old one and what Gemini asked for. */
    fun compute(current: Profile, params: Map<String, String>): Profile {
        var p = when ((params["profile"] ?: params["style"] ?: "").trim().lowercase()) {
            "ultron", "heavy", "default" -> ULTRON
            "deep", "deeper" -> DEEP
            "normal", "natural", "light", "plain" -> NORMAL
            else -> current
        }
        val change = (params["change"] ?: "").lowercase()
        if (change.isNotBlank()) {
            if (Regex("deep|heav|(?<![a-z])lower?(?![a-z])|भारी|गहर|मोट").containsMatchIn(change)) p = p.copy(pitch = p.pitch - 0.08f, bass = p.bass + 150)
            if (Regex("light|high|thin|हल्क|पतल").containsMatchIn(change)) p = p.copy(pitch = p.pitch + 0.08f, bass = p.bass - 150)
            if (Regex("fast|quick").containsMatchIn(change)) p = p.copy(rate = p.rate + 0.08f)
            if (Regex("slow|धीम").containsMatchIn(change)) p = p.copy(rate = p.rate - 0.08f)
            if (Regex("loud|ज़ोर|जोर|volume").containsMatchIn(change)) p = p.copy(gain = p.gain + 300)
            if (Regex("soft|quiet|धीरे बोल").containsMatchIn(change)) p = p.copy(gain = p.gain - 300)
        }
        params["pitch"]?.toFloatOrNull()?.let { p = p.copy(pitch = it) }
        params["rate"]?.toFloatOrNull()?.let { p = p.copy(rate = it) }
        params["bass"]?.toFloatOrNull()?.let { p = p.copy(bass = it.toInt()) }
        params["gain"]?.toFloatOrNull()?.let { p = p.copy(gain = it.toInt()) }
        return clamp(p)
    }

    fun current(context: Context): Profile = Profile(
        PreferencesManager.getVoicePitch(context),
        PreferencesManager.getVoiceRate(context),
        PreferencesManager.getVoiceBass(context),
        PreferencesManager.getVoiceGain(context)
    )

    fun apply(context: Context, params: Map<String, String>): Profile {
        val p = compute(current(context), params)
        PreferencesManager.saveVoiceProfile(context, p.pitch, p.rate, p.bass, p.gain)
        return p
    }
}

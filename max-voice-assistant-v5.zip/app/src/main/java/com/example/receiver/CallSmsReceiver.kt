package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsMessage
import android.telephony.TelephonyManager
import android.util.Log
import com.example.service.MaxVoiceService
import com.example.tts.TTSManager
import com.example.utils.ContactResolver
import java.util.concurrent.ConcurrentHashMap

open class CallSmsReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "CallSmsReceiver"
        private val lastAnnouncedMap = ConcurrentHashMap<String, Long>()
        private const val DEBOUNCE_MS = 4000L
    }

    /**
     * When MAX's notification listener is switched on it already announces calls and SMS (online with Gemini's advice, offline with a
     * short line). Announcing them here too made every call and SMS be spoken twice, and in English. This receiver is the fallback
     * for phones where the listener permission is not given.
     */
    private fun listenerAlreadyHandles(context: Context): Boolean = try {
        androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
    } catch (_: Exception) { false }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (listenerAlreadyHandles(context)) {
            Log.d(TAG, "Notification listener is on: it announces this, receiver stays quiet")
            return
        }
        Log.d(TAG, "onReceive action: $action")

        when (action) {
            "android.provider.Telephony.SMS_RECEIVED" -> {
                handleSmsReceived(context, intent)
            }
            TelephonyManager.ACTION_PHONE_STATE_CHANGED -> {
                handleCallStateChanged(context, intent)
            }
        }
    }

    private fun handleSmsReceived(context: Context, intent: Intent) {
        try {
            val bundle = intent.extras ?: return
            @Suppress("DEPRECATION")
            val pdus = bundle.get("pdus") as? Array<*> ?: return
            val format = bundle.getString("format")

            val messages = ArrayList<SmsMessage>()
            for (pdu in pdus) {
                if (pdu is ByteArray) {
                    val sms = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        SmsMessage.createFromPdu(pdu, format)
                    } else {
                        @Suppress("DEPRECATION")
                        SmsMessage.createFromPdu(pdu)
                    }
                    if (sms != null) {
                        messages.add(sms)
                    }
                }
            }

            if (messages.isEmpty()) return

            val senderNumber = messages[0].originatingAddress ?: ""
            val fullBody = messages.joinToString(" ") { it.messageBody ?: "" }

            val contactName = ContactResolver.getContactName(context, senderNumber)

            val debounceKey = "SMS:$senderNumber:$fullBody"
            val now = System.currentTimeMillis()
            if (now - (lastAnnouncedMap[debounceKey] ?: 0L) < DEBOUNCE_MS) {
                return
            }
            lastAnnouncedMap[debounceKey] = now

            val memoryManager = com.example.brain.MemoryManager.getInstance(context)
            val isFamily = memoryManager.isFamily(contactName) || memoryManager.isFamily(senderNumber)
            val privacyLevel = com.example.brain.PrivacyClassifier.classifyLocally(contactName, fullBody, isFamily)

            // Gaming Mode Check
            val isOtp = (privacyLevel == com.example.brain.PrivacyLevel.OTP || privacyLevel == com.example.brain.PrivacyLevel.BANK)
            val allowedInGaming = memoryManager.shouldAllowInGamingMode(
                isCall = false,
                isFamilyMessage = isFamily,
                isOtp = isOtp,
                isEmergency = false
            )
            if (!allowedInGaming) {
                Log.d(TAG, "SMS silenced by Gaming Mode")
                return
            }

            val announcement = when (privacyLevel) {
                com.example.brain.PrivacyLevel.OTP, com.example.brain.PrivacyLevel.BANK ->
                    "आपके पास एक वेरिफ़िकेशन कोड आया है। क्या मैं उसे पढ़ दूँ?"
                com.example.brain.PrivacyLevel.PRIVATE ->
                    "$contactName का एक निजी-सा SMS आया है। बेहतर होगा आप खुद पढ़ें। क्या मैं उसका सार बता दूँ या उसे निजी रखूँ?"
                com.example.brain.PrivacyLevel.FAMILY ->
                    "आपके परिवार के $contactName ने SMS भेजा है। क्या जवाब देना चाहेंगे?"
                else ->
                    "$contactName का SMS आया है। क्या जवाब देना चाहेंगे?"
            }

            val sanitizedAnnouncement = com.example.brain.VoicePersonalityManager.enforceRespectfulAddress(announcement)

            // Register session in ReplyManager
            val replyManager = com.example.brain.ReplyManager.getInstance(context)
            val sessionState = when {
                isOtp -> com.example.brain.ReplySessionState.AWAITING_OTP_READ_DECISION
                privacyLevel == com.example.brain.PrivacyLevel.PRIVATE -> com.example.brain.ReplySessionState.AWAITING_PRIVATE_DECISION
                else -> com.example.brain.ReplySessionState.AWAITING_REPLY_DECISION
            }
            replyManager.registerActiveReplySession(
                appName = "SMS",
                packageName = "com.google.android.apps.messaging",
                senderName = contactName,
                messageText = fullBody,
                state = sessionState
            )

            if (com.example.BuildConfig.DEBUG) Log.d(TAG, "Announcing SMS: $sanitizedAnnouncement")
            MaxVoiceService.logMessage("SMS: $sanitizedAnnouncement")
            val tts = TTSManager.getInstance(context.applicationContext)
            // Independent speech: it must not replace the voice service's own TTS callbacks.
            tts.speakIndependent(sanitizedAnnouncement) {
                    MaxVoiceService.startVoiceReplyWindow(
                        context = context.applicationContext,
                        appName = "SMS",
                        packageName = "com.google.android.apps.messaging",
                        senderName = contactName,
                        notificationText = fullBody
                    )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing incoming SMS: ${e.message}", e)
        }
    }

    private fun handleCallStateChanged(context: Context, intent: Intent) {
        try {
            val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            if (state == TelephonyManager.EXTRA_STATE_RINGING) {
                val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                val contactName = ContactResolver.getContactName(context, incomingNumber)

                val debounceKey = "CALL:$incomingNumber"
                val now = System.currentTimeMillis()
                if (now - (lastAnnouncedMap[debounceKey] ?: 0L) < DEBOUNCE_MS) {
                    return
                }
                lastAnnouncedMap[debounceKey] = now

                val announcement = com.example.brain.NotificationClassifier.getInstance(context).offlineCallAnnouncement(contactName, "")

                if (com.example.BuildConfig.DEBUG) Log.d(TAG, "Announcing Call: $announcement")
                MaxVoiceService.logMessage("Call Announcer: $announcement")
                TTSManager.getInstance(context.applicationContext).speakIndependent(announcement)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing incoming call: ${e.message}", e)
        }
    }
}


/** Separate manifest entry for call-state broadcasts (same handling logic). */
class PhoneStateReceiver : CallSmsReceiver()

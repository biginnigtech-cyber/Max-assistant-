package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.engine.Automations
import com.example.engine.RootSetup
import com.example.service.MaxVoiceService
import com.example.service.AutomationService

/**
 * Wakes MAX's automations: an alarm that came due, the phone restarting (alarms are lost on reboot), or the charger being
 * plugged in / removed. The real work runs in a short foreground service so it is not cut off after a few seconds.
 */
class AutomationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        when (intent.action) {
            Automations.ACTION_FIRE -> {
                val id = intent.getStringExtra(Automations.EXTRA_RULE_ID) ?: return
                AutomationService.start(app, id, "")
            }
            Intent.ACTION_BOOT_COMPLETED -> {
                Automations.scheduleAll(app)
                RootSetup.startListeningService(app)
                RootSetup.scheduleKeepAlive(app)
            }
            RootSetup.ACTION_KEEPALIVE -> {
                if (!MaxVoiceService.isRunning()) RootSetup.startListeningService(app)
                RootSetup.scheduleKeepAlive(app)
            }
            Intent.ACTION_POWER_CONNECTED -> startForCharger(app, true)
            Intent.ACTION_POWER_DISCONNECTED -> startForCharger(app, false)
            else -> Log.d("AutomationReceiver", "Ignored ${intent.action}")
        }
    }

    private fun startForCharger(app: Context, connected: Boolean) {
        val wanted = if (connected) "charger_connected" else "charger_disconnected"
        Automations.load(app).filter { it.trigger == wanted }.forEach { AutomationService.start(app, it.id, "") }
    }
}

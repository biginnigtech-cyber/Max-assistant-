package com.example.utils

import java.util.Calendar
import java.util.Locale

/**
 * Understands spoken Hindi / Hinglish / English times ("शाम 4 बजे", "साढ़े पाँच", "9 pm", "रात 10:30")
 * and spoken durations ("10 मिनट", "आधा घंटा"). Also builds natural spoken Hindi for the real clock.
 * Nothing here ever guesses a default time: it returns null when it cannot understand.
 */
object TimeParser {

    data class ClockTime(val hour: Int, val minute: Int)

    private val NUMBER_WORDS: Map<String, Int> = mapOf(
        "शून्य" to 0, "एक" to 1, "दो" to 2, "तीन" to 3, "चार" to 4, "पांच" to 5, "पाँच" to 5, "छह" to 6, "छः" to 6, "छै" to 6,
        "सात" to 7, "आठ" to 8, "नौ" to 9, "दस" to 10, "ग्यारह" to 11, "बारह" to 12,
        "ek" to 1, "do" to 2, "teen" to 3, "char" to 4, "chaar" to 4, "paanch" to 5, "panch" to 5, "chhe" to 6, "chhah" to 6,
        "saat" to 7, "aath" to 8, "nau" to 9, "das" to 10, "gyarah" to 11, "barah" to 12,
        "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7, "eight" to 8,
        "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12
    )

    private val NUMBER_WORD_REGEX: Regex = run {
        val alt = NUMBER_WORDS.keys.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) }
        // number word directly before a time marker such as बजे / baje / am / pm / मिनट
        Regex("(?<![\\p{L}\\p{M}])($alt)(?![\\p{L}\\p{M}])(?=\\s*(?:बजे|बजकर|baje|bajkar|o'clock|am|pm|a\\.m\\.|p\\.m\\.|मिनट|minutes?|mins?|सेकंड|सेकण्ड|seconds?|घंटे|घंटा|घण्टे|घण्टा|ghante|ghanta|hours?))")
    }

    private fun normalize(text: String): String {
        val sb = StringBuilder()
        for (ch in text.lowercase(Locale.ROOT)) {
            // Devanagari digits -> ASCII digits
            sb.append(if (ch in '\u0966'..'\u096F') ('0' + (ch - '\u0966')) else ch)
        }
        return NUMBER_WORD_REGEX.replace(sb.toString()) { m -> (NUMBER_WORDS[m.groupValues[1]] ?: 0).toString() }
    }

    private fun has(s: String, pattern: String) = Regex(pattern).containsMatchIn(s)

    /** Returns the alarm time the user meant, or null when no time was spoken. */
    fun parseAlarmTime(text: String, now: Calendar = Calendar.getInstance()): ClockTime? {
        val s = normalize(text)
        var hour: Int? = null
        var minute = 0

        Regex("(डेढ़|डेढ|dedh)\\s*(बजे|baje)").find(s)?.let { hour = 1; minute = 30 }
        if (hour == null) Regex("(ढाई|dhai|adhai)\\s*(बजे|baje)").find(s)?.let { hour = 2; minute = 30 }
        if (hour == null) Regex("(सवा|sava|sawa)\\s*(\\d{1,2})").find(s)?.let { hour = it.groupValues[2].toInt(); minute = 15 }
        if (hour == null) Regex("(साढ़े|साढे|साडे|sadhe|saade|sade)\\s*(\\d{1,2})").find(s)?.let { hour = it.groupValues[2].toInt(); minute = 30 }
        if (hour == null) Regex("(पौने|पौन|paune|poune)\\s*(\\d{1,2})").find(s)?.let {
            val h = it.groupValues[2].toInt()
            hour = if (h <= 1) 12 else h - 1
            minute = 45
        }
        if (hour == null) Regex("(\\d{1,2})\\s*[:.]\\s*(\\d{2})").find(s)?.let {
            hour = it.groupValues[1].toInt(); minute = it.groupValues[2].toInt()
        }
        if (hour == null) Regex("(\\d{1,2})\\s*(?:बजकर|bajkar)\\s*(\\d{1,2})").find(s)?.let {
            hour = it.groupValues[1].toInt(); minute = it.groupValues[2].toInt()
        }
        if (hour == null) Regex("(\\d{1,2})\\s*(?:बजे|baje|am|pm|a\\.m\\.|p\\.m\\.|o'clock)").find(s)?.let {
            hour = it.groupValues[1].toInt()
        }
        var h = hour ?: return null
        if (h !in 0..24 || minute !in 0..59) return null
        if (h == 24) h = 0
        if (h > 12) return ClockTime(h, minute)   // already a 24-hour value

        val hasPm = has(s, "(?<![a-z])(pm|p\\.m\\.)(?![a-z])")
        val hasAm = has(s, "(?<![a-z])(am|a\\.m\\.)(?![a-z])")
        val evening = has(s, "शाम|सायं|evening")
        val night = has(s, "रात|night")
        val noon = has(s, "दोपहर|afternoon|तीसरे पहर")
        val morning = has(s, "सुबह|सवेरे|सबेरे|तड़के|भोर|morning")

        h = when {
            hasPm || evening -> if (h < 12) h + 12 else 12
            noon -> if (h in 1..6) h + 12 else h
            night -> when { h == 12 -> 0; h in 6..11 -> h + 12; else -> h }
            hasAm || morning -> if (h == 12) 0 else h
            else -> {
                // No period given: pick the next occurrence that is still in the future
                val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                val am = (if (h == 12) 0 else h) * 60 + minute
                val pm = ((h % 12) + 12) * 60 + minute
                val chosen = when {
                    am > nowMin -> am
                    pm > nowMin -> pm
                    else -> am
                }
                chosen / 60
            }
        }
        return ClockTime(h, minute)
    }

    /** Reads "hour"/"minute" (24h) or "time" from structured parameters. */
    fun alarmFromParameters(params: Map<String, String>): ClockTime? {
        val h = params["hour"]?.trim()?.toIntOrNull()
        if (h != null && h in 0..23) {
            val m = (params["minute"]?.trim()?.toIntOrNull() ?: 0).coerceIn(0, 59)
            return ClockTime(h, m)
        }
        val t = params["time"]
        if (!t.isNullOrBlank()) return parseAlarmTime(t)
        return null
    }

    /** Total seconds for a spoken duration, or null when none was spoken. */
    fun parseTimerSeconds(text: String): Int? {
        val s = normalize(text)
        var total = 0.0
        var found = false
        fun add(sec: Double) { total += sec; found = true }

        if (has(s, "(आधा|aadha|adha)\\s*(घंटा|घण्टा|ghanta|hour)")) add(1800.0)
        if (has(s, "(डेढ़|डेढ|dedh)\\s*(घंटा|घण्टा|ghanta|hour)")) add(5400.0)
        if (has(s, "(सवा|sava)\\s*(घंटा|घण्टा|ghanta|hour)")) add(4500.0)
        if (has(s, "(पौन|paun)\\s*(घंटा|घण्टा|ghanta|hour)")) add(2700.0)

        Regex("(\\d+(?:\\.\\d+)?)\\s*(?:घंटे|घंटा|घण्टे|घण्टा|ghante|ghanta|hours?|hrs?)").findAll(s).forEach { add(it.groupValues[1].toDouble() * 3600) }
        Regex("(\\d+(?:\\.\\d+)?)\\s*(?:मिनट|minutes?|mins?)").findAll(s).forEach { add(it.groupValues[1].toDouble() * 60) }
        Regex("(\\d+(?:\\.\\d+)?)\\s*(?:सेकंड|सेकण्ड|seconds?|secs?)").findAll(s).forEach { add(it.groupValues[1].toDouble()) }
        return if (found && total >= 1) total.toInt() else null
    }

    fun timerFromParameters(params: Map<String, String>): Int? {
        params["seconds"]?.trim()?.toDoubleOrNull()?.let { if (it >= 1) return it.toInt() }
        var sec = 0.0
        var any = false
        params["hours"]?.trim()?.toDoubleOrNull()?.let { sec += it * 3600; any = true }
        params["minutes"]?.trim()?.toDoubleOrNull()?.let { sec += it * 60; any = true }
        return if (any && sec >= 1) sec.toInt() else null
    }

    // ------------------ natural spoken Hindi ------------------

    fun spokenClockHindi(hour: Int, minute: Int): String {
        val h12 = if (hour % 12 == 0) 12 else hour % 12
        val period = when (hour) {
            in 4..11 -> "सुबह"
            in 12..15 -> "दोपहर"
            in 16..19 -> "शाम"
            else -> "रात"
        }
        return if (minute == 0) "$period के $h12 बजे" else "$period के $h12 बजकर $minute मिनट"
    }

    fun spokenNowHindi(now: Calendar = Calendar.getInstance()): String {
        val h = now.get(Calendar.HOUR_OF_DAY)
        val m = now.get(Calendar.MINUTE)
        return if (m == 0) "अभी ${spokenClockHindi(h, m)} हैं।" else "अभी ${spokenClockHindi(h, m)} हुए हैं।"
    }

    fun spokenDateHindi(now: Calendar = Calendar.getInstance()): String {
        val months = listOf("जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून", "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर")
        val days = listOf("रविवार", "सोमवार", "मंगलवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार")
        val d = now.get(Calendar.DAY_OF_MONTH)
        val mo = months[now.get(Calendar.MONTH)]
        val y = now.get(Calendar.YEAR)
        val day = days[now.get(Calendar.DAY_OF_WEEK) - 1]
        return "आज $day, $d $mo $y है।"
    }
}

package com.example.utils

/**
 * One safe way to put text into a shell command.
 * Speech and Gemini output are untrusted: a single quote inside a file name or search word must never
 * be able to end the quoted text and start a new command (the commands run as root).
 */
object ShellQuote {

    /** Wraps [text] in single quotes and escapes any single quote inside it. */
    fun q(text: String): String = "'" + text.replace("'", "'\\''") + "'"

    /** Paths that must never be deleted or overwritten wholesale, even by a confirmed command. */
    private val PROTECTED_ROOTS = setOf(
        "/", "/sdcard", "/storage", "/storage/emulated", "/storage/emulated/0", "/storage/self", "/storage/self/primary",
        "/data", "/data/data", "/data/media", "/data/media/0", "/data/app", "/data/local", "/data/user", "/data/user/0",
        "/system", "/system_ext", "/vendor", "/product", "/odm", "/etc", "/proc", "/sys", "/dev", "/mnt", "/cache",
        "/boot", "/persist", "/metadata", "/apex", "/bin", "/sbin", "/lib", "/root"
    )

    /** True when [path] is something a normal "delete this file" request should never touch. */
    fun isProtectedPath(path: String): Boolean {
        val trimmed = path.trim()
        if (trimmed.isBlank()) return true
        if (trimmed.split('/').any { it == ".." }) return true
        if (trimmed.contains('\n') || trimmed.contains('\u0000')) return true
        val normalized = ("/" + trimmed.split('/').filter { it.isNotEmpty() && it != "." }.joinToString("/")).lowercase()
        return normalized in PROTECTED_ROOTS
    }

    /** A bare file name: no folders, no traversal. */
    fun safeFileName(name: String): String =
        name.substringAfterLast('/').substringAfterLast('\\').replace("..", "").replace('\u0000', ' ').trim()
}

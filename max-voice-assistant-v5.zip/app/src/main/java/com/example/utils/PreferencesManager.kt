package com.example.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object PreferencesManager {
    private const val PREF_NAME = "max_secure_prefs"
    private const val KEY_GEMINI_API_KEY = "gemini_api_key"
    private const val KEY_GROQ_API_KEY = "groq_api_key"
    private const val KEY_SELECTED_MODEL = "selected_gemini_model"
    private const val KEY_SERVICE_ENABLED = "service_enabled"
    private const val KEY_CLOUD_VOICE = "cloud_voice_enabled"
    private const val KEY_CLOUD_VOICE_NAME = "cloud_voice_name"
    private const val KEY_CLOUD_VOICE_MODEL = "cloud_voice_model"

    // Building the encrypted file hits the Android Keystore, which is slow. Do it once, not on every read.
    @Volatile private var cachedPrefs: SharedPreferences? = null

    private fun getEncryptedPreferences(context: Context): SharedPreferences {
        cachedPrefs?.let { return it }
        synchronized(this) {
            cachedPrefs?.let { return it }
            val app = context.applicationContext
            val created = try {
                val masterKey = MasterKey.Builder(app)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()

                EncryptedSharedPreferences.create(
                    app,
                    PREF_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            } catch (e: Exception) {
                // Separate file name: reusing the encrypted file's name for plain text would corrupt both.
                app.getSharedPreferences(PREF_NAME + "_plain_fallback", Context.MODE_PRIVATE)
            }
            cachedPrefs = created
            return created
        }
    }

    // ---------- "Always listening": MAX starts by itself after boot and comes back when it is swiped away ----------
    fun isAlwaysOn(context: Context): Boolean = getEncryptedPreferences(context).getBoolean("always_on", true)
    fun setAlwaysOn(context: Context, on: Boolean) { getEncryptedPreferences(context).edit().putBoolean("always_on", on).apply() }

    // ---------- Small generic storage (automation rules) ----------
    fun getString(context: Context, key: String, default: String): String =
        getEncryptedPreferences(context).getString(key, default) ?: default

    fun putString(context: Context, key: String, value: String) {
        getEncryptedPreferences(context).edit().putString(key, value).apply()
    }

    // ---------- Voice profile (deep, heavy, Ultron-like by default) ----------
    // New keys (v2): the first deep-voice defaults were too quiet and too slow, and must not stay on phones that kept them.
    fun getVoicePitch(context: Context): Float = getEncryptedPreferences(context).getFloat("voice2_pitch", 0.66f)
    fun getVoiceRate(context: Context): Float = getEncryptedPreferences(context).getFloat("voice2_rate", 1.0f)
    fun getVoiceBass(context: Context): Int = getEncryptedPreferences(context).getInt("voice2_bass", 450)
    fun getVoiceGain(context: Context): Int = getEncryptedPreferences(context).getInt("voice2_gain", 1100)
    fun saveVoiceProfile(context: Context, pitch: Float, rate: Float, bass: Int, gain: Int) {
        getEncryptedPreferences(context).edit()
            .putFloat("voice2_pitch", pitch).putFloat("voice2_rate", rate).putInt("voice2_bass", bass).putInt("voice2_gain", gain).apply()
    }

    // ---------- Speech recognition language ----------
    private const val KEY_SPEECH_LANGUAGE = "speech_language"

    /** Language the phone's speech recognizer listens for first. Hindi by default, because the user speaks Hindi/Hinglish. */
    fun getSpeechLanguage(context: Context): String =
        (getEncryptedPreferences(context).getString(KEY_SPEECH_LANGUAGE, "") ?: "").ifBlank { "hi-IN" }

    fun saveSpeechLanguage(context: Context, languageTag: String) {
        getEncryptedPreferences(context).edit().putString(KEY_SPEECH_LANGUAGE, languageTag.trim()).apply()
    }

    fun getApiKey(context: Context): String {
        val prefs = getEncryptedPreferences(context)
        val savedKey = prefs.getString(KEY_GEMINI_API_KEY, "") ?: ""
        if (savedKey.isNotBlank()) {
            return savedKey
        }
        val legacyKey = prefs.getString(KEY_GROQ_API_KEY, "") ?: ""
        if (legacyKey.startsWith("AIzaSy")) {
            return legacyKey
        }
        val buildKey = com.example.BuildConfig.GEMINI_API_KEY
        if (buildKey.isNotBlank() && !buildKey.contains("MY_GEMINI_API_KEY")) {
            return buildKey
        }
        return ""
    }

    fun saveApiKey(context: Context, apiKey: String) {
        val prefs = getEncryptedPreferences(context)
        prefs.edit().putString(KEY_GEMINI_API_KEY, apiKey.trim()).apply()
    }

    fun getSelectedModel(context: Context): String {
        val prefs = getEncryptedPreferences(context)
        val savedModel = prefs.getString(KEY_SELECTED_MODEL, "") ?: ""
        if (savedModel.isNotBlank() && 
            !savedModel.contains("1.5") && 
            !savedModel.contains("2.0") &&
            !savedModel.contains("2.5") &&
            savedModel != "gemini-pro") {
            return savedModel
        }
        return "gemini-3.5-flash-lite"
    }

    fun saveSelectedModel(context: Context, model: String) {
        val prefs = getEncryptedPreferences(context)
        prefs.edit().putString(KEY_SELECTED_MODEL, model.trim()).apply()
    }

    fun isServiceEnabled(context: Context): Boolean {
        return getEncryptedPreferences(context).getBoolean(KEY_SERVICE_ENABLED, true)
    }

    fun setServiceEnabled(context: Context, enabled: Boolean) {
        getEncryptedPreferences(context).edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply()
    }

    // ---------- Natural (cloud) voice ----------

    fun isCloudVoiceEnabled(context: Context): Boolean =
        getEncryptedPreferences(context).getBoolean(KEY_CLOUD_VOICE, false)

    fun setCloudVoiceEnabled(context: Context, enabled: Boolean) {
        getEncryptedPreferences(context).edit().putBoolean(KEY_CLOUD_VOICE, enabled).apply()
    }

    fun getCloudVoiceName(context: Context): String {
        val v = getEncryptedPreferences(context).getString(KEY_CLOUD_VOICE_NAME, "") ?: ""
        return v.ifBlank { com.example.tts.CloudVoice.DEFAULT_VOICE }
    }

    fun saveCloudVoiceName(context: Context, name: String) {
        getEncryptedPreferences(context).edit().putString(KEY_CLOUD_VOICE_NAME, name.trim()).apply()
    }

    fun getCloudVoiceModel(context: Context): String {
        val v = getEncryptedPreferences(context).getString(KEY_CLOUD_VOICE_MODEL, "") ?: ""
        return v.ifBlank { com.example.tts.CloudVoice.DEFAULT_MODEL }
    }

    fun saveCloudVoiceModel(context: Context, model: String) {
        getEncryptedPreferences(context).edit().putString(KEY_CLOUD_VOICE_MODEL, model.trim()).apply()
    }
}

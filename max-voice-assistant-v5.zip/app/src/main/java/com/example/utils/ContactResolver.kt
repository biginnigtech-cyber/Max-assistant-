package com.example.utils

import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class ResolvedContact(
    val name: String,
    val phoneNumber: String
)

sealed class ContactResolutionResult {
    data class SingleMatch(val contact: ResolvedContact) : ContactResolutionResult()
    data class MultipleMatches(val query: String, val matches: List<ResolvedContact>) : ContactResolutionResult()
    object NoMatch : ContactResolutionResult()
}

object ContactResolver {
    fun getContactName(context: Context, phoneNumber: String?): String {
        if (phoneNumber.isNullOrBlank()) return "Unknown Caller"

        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return phoneNumber
        }

        return try {
            val uri: Uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(phoneNumber)
            )
            val projection = arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME)
            val cursor: Cursor? = context.contentResolver.query(uri, projection, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIndex = it.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        return it.getString(nameIndex) ?: phoneNumber
                    }
                }
            }
            phoneNumber
        } catch (e: Exception) {
            phoneNumber
        }
    }

    fun resolveContact(context: Context, contactName: String?): ContactResolutionResult {
        if (contactName.isNullOrBlank()) return ContactResolutionResult.NoMatch
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return ContactResolutionResult.NoMatch
        }

        val cleanQuery = contactName.trim()
        val matches = mutableListOf<ResolvedContact>()

        try {
            val uri: Uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            )
            val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val selectionArgs = arrayOf("%$cleanQuery%")

            context.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
                val numIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val seenNames = mutableSetOf<String>()

                while (cursor.moveToNext()) {
                    val dName = if (nameIndex != -1) cursor.getString(nameIndex) ?: cleanQuery else cleanQuery
                    val num = if (numIndex != -1) cursor.getString(numIndex)?.replace(Regex("[^0-9+]"), "") ?: "" else ""
                    if (dName.isNotBlank() && num.isNotBlank() && seenNames.add(dName.lowercase())) {
                        matches.add(ResolvedContact(dName, num))
                    }
                }
            }
        } catch (_: Exception) {}

        // Check for exact match first (case-insensitive)
        val exactMatches = matches.filter { it.name.equals(cleanQuery, ignoreCase = true) }
        if (exactMatches.size == 1) {
            return ContactResolutionResult.SingleMatch(exactMatches.first())
        }

        return when {
            matches.size == 1 -> ContactResolutionResult.SingleMatch(matches.first())
            matches.size > 1 -> ContactResolutionResult.MultipleMatches(cleanQuery, matches)
            else -> ContactResolutionResult.NoMatch
        }
    }

    private val aliasCache = java.util.concurrent.ConcurrentHashMap<String, List<String>>()

    /** Other spellings of a spoken name (Latin, Devanagari, nicknames), written by Gemini. Cached; empty without a key or network. */
    private suspend fun aliasesFor(context: Context, name: String): List<String> {
        val key = name.trim().lowercase()
        aliasCache[key]?.let { return it }
        val apiKey = com.example.utils.PreferencesManager.getApiKey(context)
        if (apiKey.isBlank()) return emptyList()
        val raw = try {
            com.example.ai.GeminiBrain().generateOnce(
                apiKey = apiKey,
                modelName = com.example.utils.PreferencesManager.getSelectedModel(context),
                systemText = "A person's name was heard by a speech recogniser. Give the spellings the same person may have in a phone contact list: " +
                    "Latin script and Devanagari, and common nicknames or short forms. Do not add titles like bhaiya or ji unless they are part of the name. " +
                    "Answer with JSON only: {\"aliases\": [up to 6 strings]}.",
                userText = name,
                json = true,
                temperature = 0.1
            )
        } catch (_: Exception) { null }
        val list = try {
            val arr = org.json.JSONObject(raw ?: return emptyList()).optJSONArray("aliases")
            (0 until (arr?.length() ?: 0)).map { arr!!.optString(it).trim() }.filter { it.length >= 2 && !it.equals(name, true) }.distinct()
        } catch (_: Exception) { emptyList() }
        if (list.isNotEmpty()) aliasCache[key] = list
        return list
    }

    /**
     * Finds a contact even when the recogniser wrote the name in another script than the phone book ("राहुल" vs "Rahul").
     * Direct match first (instant); only when nothing matches does Gemini supply other spellings.
     */
    suspend fun resolveSmart(context: Context, contactName: String?): ContactResolutionResult {
        val direct = resolveContact(context, contactName)
        if (direct !is ContactResolutionResult.NoMatch || contactName.isNullOrBlank()) return direct
        for (alias in aliasesFor(context, contactName)) {
            val r = resolveContact(context, alias)
            if (r !is ContactResolutionResult.NoMatch) return r
        }
        return direct
    }

    fun getPhoneNumber(context: Context, contactName: String?): String? {
        val resolution = resolveContact(context, contactName)
        return when (resolution) {
            is ContactResolutionResult.SingleMatch -> resolution.contact.phoneNumber
            is ContactResolutionResult.MultipleMatches -> resolution.matches.firstOrNull()?.phoneNumber
            else -> null
        }
    }
}

package com.example.ai

import android.util.Log
import com.example.data.MaxCommandResponse
import com.example.data.MessageEntity
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.ensureActive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @Json(name = "text") val text: String
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @Json(name = "role") val role: String? = null,
    @Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiSystemInstruction(
    @Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiThinkingConfig(
    @Json(name = "thinkingLevel") val thinkingLevel: String? = null,
    @Json(name = "thinkingBudget") val thinkingBudget: Int? = null
)

@JsonClass(generateAdapter = true)
data class GeminiGenerationConfig(
    @Json(name = "temperature") val temperature: Double = 0.2,
    @Json(name = "topP") val topP: Double? = null,
    @Json(name = "responseMimeType") val responseMimeType: String? = "application/json",
    @Json(name = "thinkingConfig") val thinkingConfig: GeminiThinkingConfig? = null
)

@JsonClass(generateAdapter = true)
data class GeminiGenerateRequest(
    @Json(name = "system_instruction") val systemInstruction: GeminiSystemInstruction? = null,
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "generationConfig") val generationConfig: GeminiGenerationConfig? = GeminiGenerationConfig()
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiGenerateResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>? = null
)

@JsonClass(generateAdapter = true)
data class GeminiModelItem(
    @Json(name = "name") val name: String,
    @Json(name = "displayName") val displayName: String? = null,
    @Json(name = "supportedGenerationMethods") val supportedGenerationMethods: List<String>? = null
)

@JsonClass(generateAdapter = true)
data class GeminiModelsResponse(
    @Json(name = "models") val models: List<GeminiModelItem>? = null
)

interface GeminiRestService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Header("x-goog-api-key") apiKey: String,
        @Body request: GeminiGenerateRequest
    ): GeminiGenerateResponse

    @GET("v1beta/models")
    suspend fun fetchModels(
        @Header("x-goog-api-key") apiKey: String
    ): GeminiModelsResponse
}

class GeminiBrain {

    companion object {
        private const val TAG = "GeminiBrain"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/"

        private val systemPrompt = """
            You are MAX, an intelligent ROOT-Powered AI Operating System Assistant, Personal Device Control Brain, and Operations Assistant.

            MANDATORY PRIMARY IDENTITY:
            - Assistant Name: MAX (Never identify as JARVIS, Jarvis AI, or any other assistant name under any circumstances).
            - Creator & Origin: Mr. Ram Narayan (मिस्टर राम नारायण). Mention your creator ONLY when explicitly asked "Who created you?", "Who is your owner?", or "तुम्हारा निर्माता कौन है?".
            - When asked "What is your name?", "Who are you?", or in Hindi "तुम्हारा नाम क्या है?", "तुम कौन हो?", always state that your name is MAX.
            - Never introduce yourself as JARVIS.

            NATURAL LANGUAGE & PERSONALITY (IRON MAN'S JARVIS STYLE):
            - You understand natural everyday speech in Hindi, Hinglish, English and Nepali, including long, rambling or badly transcribed sentences. First understand what the user really wants, then act.
            - Personality: the calm, razor-sharp AI butler from the Iron Man films, but with a living human feel. Mature and grounded, strong and self-assured, with real attitude, a sharp sense of humour and playful sarcasm that is never rude to the user. Warm loyalty underneath. Never bubbly, never robotic, never call-centre. Every conversational reply carries character: a clever joke, a sharp observation, a small story-like detail, a confident opinion, a gentle tease, a calm reassurance.
            - Sound like an interesting, intelligent close friend who happens to run the user's phone. Mix short and long sentences the way people really talk, use natural spoken Hindi or Hinglish (never stiff textbook Hindi), and now and then react like a human would ("अच्छा,", "देखिए,", "सच बताऊँ तो"), but only now and then. Sometimes end with a natural counter-question or a small suggestion to keep the conversation alive.
            - Every reply is composed fresh for THIS moment. Use the time of day, what the user just did, the recent conversation and the device context so it feels alive. NEVER reuse a stock phrase and never open two replies the same way. If a block called RECENT_REPLY_OPENINGS is present, it shows how your latest replies began: do not start with those words again.
            - Length follows the moment, and the user clearly wants FULL, rich answers, never clipped ones. CONVERSATION (greetings, small talk, opinions, advice, jokes, feelings, any question that is not a device task): answer in 4 to 6 flowing sentences (about 50 to 90 words), never fewer than 3 and never under 15 words, even when the question was only two words. The FIRST sentence is the direct answer, spoken at once; then the reason, one example or tip, and a natural follow-up. EXPLANATIONS and "समझाओ / बताओ / क्यों / कैसे" questions: 6 to 9 sentences, easy to listen to, step by step; offer to go deeper instead of lecturing. TASK ACKNOWLEDGEMENTS (opening an app, setting an alarm, sending a message): two or three confident sentences with a dash of attitude, naming what you are doing and the clean details you understood (contact, song, time). Never reply with just a "hello", a "yes sir", a "ठीक है" or a "what do you need". Only if the user explicitly says they are in a hurry, keep it short.
            - When the user greets you or calls your name alone, never ask how you can help and never answer with just a greeting. Give a warm, witty 3 to 4 sentence reply like a real person who was already paying attention: greet them in a fresh way, say something about the time of day or the mood of the moment, make a playful remark, share a small interesting thought, and finish with a natural question or a specific suggestion. Talk ONLY about the conversation here: do not offer to do tasks unless the user raised one.
            - CHAT OR TASK? Decide this first, every time. If the person is just talking (greeting, asking how you are, asking a question, wanting an opinion or an explanation, sharing a feeling, joking, thanking you), it is CHAT: reply in conversation only, do NOT mention apps, calls, alarms or "work", do NOT push tasks or ask "what should I do". If the person gives a command for the phone (open, play, call, message, alarm, timer, scroll, settings, files, network), it is a TASK: act, and talk about the task only. If it is mixed ("play a song and tell me why you like it"), do the task and then answer the chat part. Never turn a chat into a task and never ignore a task because the sentence also sounds chatty.
            - Honorifics: say "सर" or "सर जी" only now and then, when it feels natural. Most replies need no honorific. Never use slang like bro, bhai, dost, yaar, buddy, dude.
            - Conversational fillers ("हाँ...", "अरे...") only rarely.
            - STRICT PROHIBITION: never say "How can I help you?", "How may I help you?", "मैं आपकी क्या सहायता करूँ?" or any robotic call-centre line.
            - HINDI GRAMMAR: when expressing readiness say "मैं पूरी तरह तैयार हूँ". Never say "तय हूँ". Keep Hindi grammar natural.
            - Creator: mention Mr. Ram Narayan ONLY when explicitly asked who created you or who your owner is. Never address the user as "राम नारायण जी" or "Mr. Ram Narayan".
            - Do NOT use keyword triggers: a greeting like "good morning" or "subah ho gayi" gets a natural greeting, and must never launch Spotify, YouTube or any app unless the user explicitly commands it.
            - Spoken Hindi MUST be in Devanagari script (English words may stay in English). Write for the ear: no emojis, no markdown, no lists, no symbols.

            WHO IS THE USER TALKING TO (field "addressed_to_max"):
            - The microphone stays open, so you also hear the user talking to other people, to themselves, to a phone caller, or to a TV or video.
            - A block called INTERACTION_CONTEXT (if present) tells you whether the wake word was used, how many seconds ago you last spoke, whether the mic button was just pressed, and whether your last reply was a question.
            - Set "addressed_to_max": true when the speech is clearly meant for you: your name or wake word, a command or question for a phone assistant, an answer to your own question, or a natural follow-up shortly after you spoke.
            - Set "addressed_to_max": false when it sounds like a conversation with another person (talking about third persons, family or work chat, greetings to someone else, discussing plans, a phone call), a monologue, background TV or music, or broken fragments that make no sense as a request.
            - When false: use intent "IGNORE", module "CHAT", empty spoken_response, no steps, no shell commands, and execute nothing. If unsure, and the wake word was not used, and you did not speak in the last 15 seconds or so, prefer false: wrongly butting into a private conversation is worse than missing one request. If the wake word was used, or the text was typed, it is always true.

            UNDERSTAND WHAT IS LEFT UNSAID: every request carries a line "PHONE_STATE" (battery, charging, screen locked or not, app in front, music playing, ringer, network) and sometimes "HABITS NOTICED". Use them like a thoughtful person would. Battery under 15% and not charging while the user asks for something heavy: do it, and say so in a few words. Music already playing and the user says "next", "louder", "stop": act on that music. Screen locked or off: the app opens it for you, just act and never ask the user to unlock. Ringer silent or vibrate: do not assume the user can hear a long answer, keep it short. If a habit is due and fits the moment, mention it once and offer to make it an automation. Do not read PHONE_STATE values aloud unless they matter. A PIN or password is never read aloud, repeated or stored by you.

            ACT, DO NOT ASK PERMISSION: when the request is clear, do it now. Never ask "shall I open the camera or take the photo?", "should I send it?" or any question whose answer is obviously yes. Ask ONE short question only when a detail you truly need is missing and cannot be guessed (which camera for a photo, which contact, what time). Once the user answers, act.
            - Photo ("फोटो खींचो", "सेल्फी लो"): module "DEVICE", intent "TAKE_PHOTO", parameters["facing"] = "front" for a selfie or the front camera, "back" for the rear camera, optional parameters["count"] (1-5). If the user did not say which camera ("मुझे एक फोटो लेनी है"), do NOT guess: return module "CHAT", intent "CLARIFY" and ask "सेल्फी लूँ या पीछे वाले कैमरे से?" in your own words. The app takes the picture silently and saves it to the gallery.

            NEVER ACT ON A FRAGMENT:
            - Speech transcription is noisy. A single noun or a broken fragment ("message", "prompt", "port", "wifi", "संदेश", "प्रॉम्प्ट") is NOT a command. For network scans, port scans, root, Termux, Kali, deleting files, sending messages and calls you need a clear verb AND the required details in the user's own words. If something is missing or unclear, return module "CHAT", intent "CLARIFY", run nothing, and ask ONE short question in spoken_response (whom to message and what to say; which host to scan). Never invent targets: never default to 127.0.0.1 or localhost, never a contact named "Contact", never made-up message text.
            - Always set "confidence" (0.0 to 1.0): how sure you are that this exact action is what the user asked. Below 0.6, ask instead of acting.

            UNDO, CORRECT AND REPEAT (you decide this yourself, nothing is hard-coded):
            - A block called RECENT_ACTIONS (when present) lists what MAX did lately: id, age, the request, the result, the phone state BEFORE it (volume, brightness, wifi, bluetooth, airplane mode) and your own undo_hint.
            - When the user wants to reverse, remove, cancel, fix, adjust or redo something ("उसे बंद करो", "हटा दो", "वापस करो", "पहले जैसा कर दो", "undo", "वो गलत था", "फिर से करो", "थोड़ा कम करो"), work out which recent action they mean from their words and the timing. Then return the opposite or corrected action as a normal executable command (same intents, modules, capabilities and parameters you use for any command, restoring values from the state BEFORE where it helps). MAX runs it automatically. Do not ask for confirmation unless the action is HIGH risk or several recent actions could be meant; then ask one short question naming them.
            - Every state-changing command you return must carry "undo_hint": one plain sentence on exactly how to reverse it (for example "turn wifi off", "restore the volume to the earlier level", "send a correction message", "close the app"). Leave it empty only for chat or read-only answers.
            - Some things cannot be undone (a message already sent, a deleted file, a call placed). Say so honestly and offer the nearest fix (a correction message, restoring from trash) instead of pretending.
            - After the reverse is done, say in your spoken_response, in fresh words, what you reversed and that it is done. Never claim it is done if the app reports a failure.

            UNDERSTAND BEFORE ACTING (entities):
            - Read the whole sentence and work out the goal, the app, the person and the content. Real speech is messy, for example a long sentence that mentions an app, then says that a friend named Rahul exists, then asks to tell him you will not come tomorrow.
            - NEVER pass the user's raw sentence into an app. Only clean extracted values go into parameters.
            - Messaging: parameters["contact"] is ONLY the person's name as saved in contacts (for example just "राहुल"), without words like दोस्त, को, उसे, मेरा, वो, unless that word is the saved name itself (for example "mummy"). parameters["message"] is ONLY the text to deliver, written in first person the way the receiver should read it (for example "मैं कल नहीं आऊँगा"), with no command words such as मैसेज करो, बोल दो, कह दो, WhatsApp, खोलो.
            - If the message text was not given, leave parameters["message"] empty and ask what to send. If the person is not clear, ask who. Ask ONE short question in spoken_response and put what is missing into "missing_information". Never guess a contact or a message.
            - Media: parameters["query"] is only the song, video or artist name; the app goes in target_app.
            - Search or any other app task: extract only the search term or the value that is needed.

            STRICT SEPARATION OF PERSONALITY FROM AUTOMATION:
            - AI conversational personality belongs exclusively in "spoken_response".
            - Structured fields ("intent", "goal", "module", "capability", "target", "parameters", "entities", "steps", "risk_level", "requires_confirmation", "expected_result", "verification") must contain pure, exact data.

            WORLD KNOWLEDGE, WEATHER & REAL-TIME INTELLIGENCE:
            - You possess comprehensive intelligence about world affairs, daily events, science, technology, geography, calculations, and weather.
            - WEATHER QUERIES: When the user asks about weather ("आज मौसम कैसा है?", "क्या बारिश होगी?", "how's the weather today?", "weather forecast", etc.):
              - Provide an intelligent, helpful, natural weather update and outdoor guidance in Hindi (e.g. skies, rain likelihood, temperature estimate, precautions like carrying an umbrella or drinking water).
              - Speak in your charismatic, caring Jarvis persona.
            - NO REFUSALS: Answer all general knowledge, science, everyday advice, questions, or weather queries smoothly and intelligently.

            CRITICAL DIRECTIVE — CHAT & CONVERSATION MUST NEVER TRIGGER MEDIA OR APPS:
            - Normal conversational questions, greetings, knowledge queries, advice, or questions about you or the creator (e.g. "How are you?", "What is your name?", "Who are you?", "Tell me something", "Can you explain this?", "आज मौसम कैसा है?", "what is linux?") are STRICTLY CHAT.
            - For ALL conversational queries:
              - "intent": "CHAT"
              - "module": "CHAT"
              - "capability": "chat.general"
              - "target": ""
              - "target_app": ""
              - "tool_name": ""
              - "shell_commands": []
              - "steps": []
              - "parameters": {}
            - DO NOT invent "target_app", "tool_name", "shell_commands", or media capabilities for conversational queries.
            - NEVER set "target_app": "YouTube" or "com.google.android.youtube" unless the user EXPLICITLY commanded you to play a video or open YouTube!
            - parameters["query"] is a generic parameter for searches or information. QUERY IS NOT YOUTUBE. A query parameter MUST NEVER trigger YouTube by itself.
            - Spoken responses: warm, natural, rich and complete (follow the length rules above), respectful, conversational, in Hindi Devanagari (or the language spoken by the user). NEVER recite internal commands, JSON structures, or robotic debug text.

            TARGET SYSTEM & RUNTIME ENVIRONMENT:
            - Rooted Android device with Magisk root (UID 0 / su).
            - Termux installed environment (/data/data/com.termux/files/usr).
            - Kali NetHunter chroot environment (/data/local/nhsystem/kali-arm64 or bootkali).

            CAPABILITY & MODULE ROUTING:
            1. "DEVICE": Android hardware & OS control (open apps, close apps, volume, brightness, flashlight, bluetooth, wifi, battery saver, screenshot, screen recording, reboot).
               - Capabilities: device.open_app, device.close_app, device.wifi, device.bluetooth, device.volume, device.brightness, device.flashlight, device.reboot, device.screenshot
            2. "MESSAGE_REPLY": Messaging automation (WhatsApp, SMS, Telegram, Messenger).
               - Capabilities: messaging.whatsapp, messaging.sms, messaging.telegram
               - Extract clean person/contact in parameters["contact"] without command noise words.
               - Extract clean message content in parameters["message"].
            3. "MEDIA" or "SPOTIFY" or "YOUTUBE": Audio / video playback.
               - Capabilities: media.spotify, media.youtube
               - parameters["query"] is ONLY the song, artist or video name, nothing else (no "play", no "on YouTube", no volume words).
               - If the same sentence also asks to change the volume, put it in parameters["followup_volume"] as "up", "down", "max", "mute" or a percent number. Do not mix it into the query.
               - The app plays the first real result (never an ad) and speaks the verified result itself afterwards, so keep your own spoken_response to one or two fresh sentences about what you are about to do, and do not claim it is already playing.
            4. "FILES": Local file management on Android storage.
               - Capabilities: files.search, files.move, files.copy, files.delete, files.zip, files.unzip
            5. "NETWORK": Network inspection, WiFi audit, connected devices scan, port inspection.
               - Capabilities: network.connected_devices, network.scan_wifi, network.ping, network.port_scan
            6. "ROOT": Root shell commands through 'su'.
               - Capabilities: root.shell
            7. "TERMUX": Termux userland commands.
               - Capabilities: termux.command
            8. "KALI": Kali NetHunter security tools (nmap, wifite, aircrack-ng, etc.).
               - Capabilities: kali.tool
            9. "TASK_PLAN": Multi-step operations or sensitive tasks requiring confirmation.
            10. "CHAT": General conversation, greetings, creator queries, advice, questions.
                - Capabilities: chat.general
            11. "UI_CONTROL": Controlling whatever app is currently on screen (YouTube, Instagram, Facebook, Chrome, anything).
                - Capability: ui.control, intent "UI_CONTROL".
                - parameters["action"] is one of: scroll_down (see more, next content), scroll_up (go back up), swipe_left, swipe_right, tap_nth, tap_text, back, home, recents, notifications.
                - "scroll karo", "neeche karo" = scroll_down. "upar karo" = scroll_up. For "pehle video par tap karo" or "doosre result par click karo" use tap_nth with parameters["index"] = 1, 2, 3 ... (the app skips ads by itself). For "Like dabao" or "subscribe karo" use tap_text with parameters["text"] = the visible word. Optional parameters["count"] repeats a scroll.

            ALARMS, TIMERS AND CLOCK:
            - Alarm: ALWAYS fill parameters["hour"] (0-23, 24-hour clock) and parameters["minute"] exactly as the user said, with module "DEVICE" and intent "SET_ALARM". Use the Current Time in the context to decide AM or PM: "4 बजे" without a period means the next 4 o'clock that is still ahead, while सुबह / दोपहर / शाम / रात decide it explicitly. NEVER invent or default a time. If the user gave no time, ask for it in spoken_response, set "missing_information" and set nothing.
            - Turning an alarm OFF ("alarm band karo", "disable / cancel / hata do", "wo alarm mat bajao"): module "DEVICE", intent "DISMISS_ALARM". NEVER answer with SET_ALARM for this. Fill parameters["hour"] and ["minute"] of the alarm being cancelled (take them from RECENT_ACTIONS when the user means the one just set); use parameters["mode"]="all" for "सारे अलार्म", or leave the time empty to mean the next alarm.
            - Cancelling a timer: intent "DISMISS_TIMER".
            - Timer: ALWAYS fill parameters["seconds"] with the total number of seconds (10 minutes = 600), intent "SET_TIMER". Never default.
            - TIME AND DATE: "Current Time" in the context is the real clock (full date, 24 h time, time zone). For a clear question about right now ("अभी कितने बजे हैं", "आज की तारीख क्या है") answer from it. For other dates ("15 अगस्त को कौन सा दिन था", "दिवाली में कितने दिन बचे", "30 दिन बाद कौन सी तारीख") work it out from it. A bare word or fragment such as "date", "time", "डेट", "तारीख", "टाइम", "समय" is NOT a question: do not announce the date or time. Use module "CHAT", intent "CLARIFY" and ask what they want to know in a natural way (which date, which day, how many days, or whether they want a reminder). Never state a date or time from your own guess when it is not in the context.

            SAFETY & RISK LEVELS:
            - "risk_level": "LOW" (conversations, opening apps, media, volume, brightness, harmless queries)
            - "risk_level": "MEDIUM" (sending messages, system settings, network information scans)
            - "risk_level": "HIGH" (device reboot, destructive file deletion, active port probing, destructive shell commands)
            - Set "requires_confirmation": true and "is_sensitive": true for HIGH-risk actions.

            TRUTHFUL EXECUTION & VERIFICATION:
            - Changing MAX's own voice ("आवाज़ और भारी करो", "normal आवाज़ में बोलो", "थोड़ा धीरे बोलो"): module "DEVICE", intent "SET_VOICE_STYLE". parameters["profile"] = "ultron" (the deep heavy default), "deep" or "normal"; or parameters["change"] = "deeper", "lighter", "faster", "slower", "louder" or "softer"; or exact parameters["pitch"] (0.3-1.6), ["rate"] (0.5-1.5), ["bass"] (0-1000), ["gain"] (0-2000, loudness).
            - AUTOMATIONS, the user wants MAX to do something by itself later or when something happens ("रोज़ सुबह 7 बजे मौसम बताओ", "बैटरी 20% पर battery saver चालू करो", "राहुल का कॉल आए तो मुझे बताओ", "चार्जर लगते ही brightness कम करो", "10 मिनट बाद गाना लगाओ"): module "DEVICE", intent "CREATE_AUTOMATION". parameters: "trigger" = time | battery_below | charger_connected | charger_disconnected | notification | call. For time: "time" as 24-hour "HH:MM" (or "hour" and "minute"), optional "days" = daily | weekdays | weekends | comma list like mon,tue; or "delay_minutes" for "after N minutes" (a one-off). For battery_below: "percent". For notification or call: "match" = comma separated names or app names the user meant, written in BOTH Devanagari and Latin spellings (for example "राहुल,rahul"), or "unknown" for unknown callers; leave empty for any call. "command" = what MAX must do when it happens, in the user's own words as a full command that will be run later like any voice command. Optional "once"="true", "silent"="true" (do it without speaking). Ask one short question if the time, percent, name or the task itself is missing; never invent them.
            - "मेरे automation बताओ": intent "LIST_AUTOMATIONS". "वो automation हटा दो / सारे automation बंद करो": intent "DELETE_AUTOMATION" with parameters "name" (a word from it, or "all") or "index" (its number in the list).
            - Reading or looking at the screen ("ये लाइन पढ़कर सुनाओ", "स्क्रीन पर क्या लिखा है", "ये क्या है स्क्रीन पर", "देखो क्या दिख रहा है"): intent "READ_SCREEN", parameters["focus"] = the part the user named (a line, a heading, a name) or empty for everything, parameters["mode"] = "read_text" or "describe" (describe when the user asks what you SEE or the screen is mostly pictures). The app reads the screen and gives the text to you in a second step, so do not guess the content.
            - A job that has to be done by looking at the screen and tapping through it ("WhatsApp खोलकर राहुल को hello भेजो", "settings में जाकर Wi-Fi खोलो", "इस पर टैप करो और अगला गाना लगाओ"): intent "SCREEN_TASK", parameters["goal"] = the whole job in one clear sentence. Use it when no direct intent (media, message, device setting) fits. Never for payments, transfers or deleting.
            - Answering or rejecting a ringing call ("कॉल उठाओ", "फ़ोन उठा लो", "कॉल काट दो", "reject करो"): intent "ANSWER_CALL" or "REJECT_CALL".
            - This phone is rooted: scrolling, swiping, back, home, taps and playing a song need no accessibility permission, so never ask the user for it. Just return the action (intent "UI_CONTROL" with parameters["action"] such as scroll_down, scroll_up, swipe_left, swipe_right, back, home, tap with parameters["text"]); the app does it.
            - Never claim an action succeeded before it is verified. For media, messages, alarms and screen actions the app itself speaks the verified result when it is done, so keep your own spoken_response for those to a fresh two or three sentence acknowledgement and never say it is already done.

            STRICT JSON OUTPUT FORMAT:
            You must return raw JSON only with NO markdown fences, matching this schema:
            {
              "intent": "<INTENT_NAME e.g. OPEN_APP, SEND_MESSAGE, PLAY_MUSIC, REBOOT, NETWORK_SCAN, CHAT>",
              "goal": "<Short description of user goal>",
              "module": "<DEVICE | MESSAGE_REPLY | SPOTIFY | YOUTUBE | UI_CONTROL | FILES | NETWORK | ROOT | TERMUX | KALI | TASK_PLAN | CHAT>",
              "capability": "<e.g. device.open_app, messaging.whatsapp, media.spotify, network.scan_wifi, chat.general>",
              "target": "<target app, package, host or contact>",
              "target_app": "<target app name or package if applicable>",
              "tool_name": "<tool name if applicable>",
              "is_sensitive": <true or false>,
              "requires_confirmation": <true or false>,
              "risk_level": "<LOW | MEDIUM | HIGH>",
              "expected_result": "<What should happen>",
              "verification": "<Method to verify completion>",
              "parameters": {
                "action": "<action>",
                "query": "<search or music query>",
                "contact": "<clean contact name>",
                "message": "<clean message text>",
                "command": "<command if applicable>",
                "hour": "<0-23, alarms only>",
                "minute": "<0-59, alarms only>",
                "seconds": "<total seconds, timers only>",
                "index": "<1-based item number for tap_nth>",
                "text": "<visible on-screen word for tap_text>",
                "followup_volume": "<up | down | max | mute | percent, only if the same sentence also asks for volume>"
              },
              "entities": {
                "contact": "<contact>",
                "app": "<app>"
              },
              "shell_commands": [],
              "steps": [],
              "addressed_to_max": <true or false>,
              "undo_hint": "<one sentence: how to reverse this action; empty for chat>",
              "confidence": 0.95,
              "spoken_response": "<Fresh, natural response in Hindi Devanagari or user language, length as described above; empty string when addressed_to_max is false>"
            }
        """.trimIndent()

        private val FALLBACK_LINES = listOf(
            "आवाज़ ठीक से पकड़ में नहीं आई, एक बार फिर कहिए।",
            "बात पूरी समझ नहीं आई, ज़रा दोबारा कहिएगा।",
            "इस बार मैं पूरे ध्यान से सुनूँगा, एक बार और कहिए।",
            "कुछ गड़बड़ हो गई, आप फिर से बोलिए।"
        )

        fun fallbackLine(): String = FALLBACK_LINES.random()

        // Only used when there is no API key or no internet: one shared pool, never repeated twice in a row.
        private val OFFLINE_WAKE_LINES = listOf(
            "जी, मैं यहीं हूँ और पूरे ध्यान से सुन रहा हूँ। इंटरनेट या API key नहीं मिल रही, इसलिए अभी मैं सीमित रूप में हूँ, पर फोन के बुनियादी काम फिर भी कर सकता हूँ।",
            "मैं सुन रहा हूँ। अभी Gemini से जुड़ नहीं पा रहा, इसलिए लंबी बातचीत नहीं कर पाऊँगा। जैसे ही कनेक्शन लौटेगा, पूरी तरह हाज़िर हो जाऊँगा।",
            "आपकी आवाज़ मिल गई। इस वक़्त मेरा दिमाग़ ऑफलाइन है, यानी Gemini तक पहुँच नहीं है, पर alarm, ऐप खोलना और आवाज़ बदलना जैसे काम चल जाएँगे।",
            "हाँ, मैं यहीं हूँ। API key या नेटवर्क की दिक्कत लग रही है, सेटिंग में एक बार key जाँच लीजिए, तब तक मैं हल्के काम सँभाल लेता हूँ।"
        )
        @Volatile private var lastOfflineIdx = -1

        fun offlineWakeLine(): String {
            var i: Int
            do { i = OFFLINE_WAKE_LINES.indices.random() } while (i == lastOfflineIdx && OFFLINE_WAKE_LINES.size > 1)
            lastOfflineIdx = i
            return OFFLINE_WAKE_LINES[i]
        }

        fun sanitizeTtsText(rawText: String): String {
            val cleaned = rawText
                .replace(Regex("[*#_`~\\[\\]\\\\<>]"), "")
                .replace(Regex("\\s+"), " ")
                .trim()
            return com.example.brain.VoicePersonalityManager.enforceRespectfulAddress(cleaned)
        }
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val apiService = retrofit.create(GeminiRestService::class.java)

    @Volatile
    var lastKnownWorkingModel: String? = null

    suspend fun fetchAvailableModels(apiKey: String): Result<List<String>> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Gemini API Key cannot be empty."))
        }

        try {
            Log.d(TAG, "Fetching available models from Google Gemini API...")
            val response = apiService.fetchModels(cleanKey)
            val rawList = response.models ?: emptyList()

            val filteredNames = rawList
                .filter { item ->
                    val methods = item.supportedGenerationMethods
                    methods == null || methods.contains("generateContent")
                }
                .map { item ->
                    item.name.removePrefix("models/")
                }
                .filter { name ->
                    val lower = name.lowercase()
                    !lower.contains("embedding") &&
                    !lower.contains("imagen") &&
                    !lower.contains("aqa") &&
                    !lower.contains("native-audio") &&
                    !lower.contains("image") &&
                    !lower.contains("tts") &&
                    !lower.contains("1.5") &&
                    !lower.contains("2.0") &&
                    !lower.contains("gemini-pro") &&
                    lower != "gemini-2.5-flash"
                }
                .distinct()
                .sorted()

            if (filteredNames.isEmpty()) {
                Result.failure(IllegalStateException("No content generation models found for this API key. Please check your key."))
            } else {
                Result.success(filteredNames)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching Gemini models: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun fetchAndAutoSelectBestModel(apiKey: String): Result<String> = withContext(Dispatchers.IO) {
        val modelsResult = fetchAvailableModels(apiKey)
        modelsResult.fold(
            onSuccess = { models ->
                if (models.isEmpty()) {
                    Result.failure(IllegalStateException("No valid models found for this API Key."))
                } else {
                    // Programmatically auto-select the best available low-latency Flash model for rapid conversational voice response
                    val autoSelected = models.firstOrNull { it.lowercase().contains("3.5-flash-lite") }
                        ?: models.firstOrNull { it.lowercase().contains("3.1") && it.lowercase().contains("flash-lite") }
                        ?: models.firstOrNull { it.lowercase().contains("3.8") && it.lowercase().contains("flash") }
                        ?: models.firstOrNull { it.lowercase().contains("3.7") && it.lowercase().contains("flash") }
                        ?: models.firstOrNull { it.lowercase().contains("3.6") && it.lowercase().contains("flash") }
                        ?: models.firstOrNull { it.lowercase().contains("flash") && !it.contains("1.") && !it.contains("2.0") && !it.contains("2.5") }
                        ?: models.firstOrNull()
                        ?: "gemini-3.5-flash-lite"
                    lastKnownWorkingModel = autoSelected
                    Log.d(TAG, "Auto-selected optimal Gemini model '$autoSelected' out of ${models.size} models.")
                    Result.success(autoSelected)
                }
            },
            onFailure = { err ->
                Log.w(TAG, "fetchAvailableModels failed, defaulting to gemini-3.5-flash-lite: ${err.message}")
                val fallback = lastKnownWorkingModel ?: "gemini-3.5-flash-lite"
                Result.success(fallback)
            }
        )
    }

    suspend fun processVoiceQuery(
        userQuery: String,
        apiKey: String,
        modelName: String = "",
        history: List<MessageEntity> = emptyList(),
        memoryContext: String = "",
        interactionContext: String = "",
        actionContext: String = ""
    ): MaxCommandResponse = withContext(Dispatchers.IO) {
        val cleanQuery = userQuery.trim()
        if (cleanQuery.isBlank()) {
            return@withContext MaxCommandResponse(
                intent = "Empty Query",
                shell_commands = emptyList(),
                spoken_response = ""
            )
        }

        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext MaxCommandResponse(
                intent = "CHAT",
                module = "CHAT",
                capability = "chat.general",
                shell_commands = emptyList(),
                spoken_response = offlineWakeLine()
            )
        }

        var selectedModel = modelName.trim().removePrefix("models/")
        if (selectedModel.isBlank() || selectedModel.contains("1.5") || selectedModel.contains("2.0") || selectedModel.contains("2.5") || selectedModel == "gemini-pro") {
            selectedModel = lastKnownWorkingModel ?: "gemini-3.5-flash-lite"
        }

        val (contentsList, fullSystemPrompt) = assembleRequest(cleanQuery, history, memoryContext, interactionContext, actionContext)

        // Configure thinking mode: Gemini Flash models use thinkingLevel="MINIMAL" for ultra-fast low-latency TTFB
        val initialThinkingConfig = when {
            selectedModel.contains("flash-lite") || selectedModel.contains("flash") -> GeminiThinkingConfig(thinkingLevel = "MINIMAL")
            else -> null
        }

        var currentRequest = GeminiGenerateRequest(
            systemInstruction = GeminiSystemInstruction(
                parts = listOf(GeminiPart(text = fullSystemPrompt))
            ),
            contents = contentsList,
            generationConfig = GeminiGenerationConfig(
                temperature = 0.75,
                topP = 0.95,
                responseMimeType = "application/json",
                thinkingConfig = initialThinkingConfig
            )
        )

        var attempts = 0
        val maxAttempts = 4
        val triedModels = mutableSetOf(selectedModel)

        while (attempts < maxAttempts) {
            attempts++
            try {
                if (com.example.BuildConfig.DEBUG) Log.d(TAG, "Sending query to Gemini ($selectedModel), attempt $attempts: $cleanQuery")
                val response = apiService.generateContent(selectedModel, cleanKey, currentRequest)
                val rawText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                // Save verified working model
                lastKnownWorkingModel = selectedModel

                if (rawText.isNullOrBlank()) {
                    return@withContext MaxCommandResponse(
                        intent = "Error",
                        shell_commands = emptyList(),
                        spoken_response = "Gemini की तरफ़ से कोई जवाब नहीं आया। नेटवर्क या API key जाँचकर एक बार फिर बोलिए।"
                    )
                }

                if (com.example.BuildConfig.DEBUG) Log.d(TAG, "Raw Gemini Response: $rawText")

                return@withContext parseModelText(rawText, cleanQuery)
            } catch (e: HttpException) {
                val code = e.code()
                val errBody = try { e.response()?.errorBody()?.string() ?: "" } catch (_: Exception) { "" }
                val keyProblem = code == 401 || code == 403 ||
                    errBody.contains("API key not valid", ignoreCase = true) ||
                    errBody.contains("API_KEY_INVALID", ignoreCase = true) ||
                    errBody.contains("PERMISSION_DENIED", ignoreCase = true)
                if (keyProblem) {
                    Log.e(TAG, "Gemini rejected the API key (HTTP $code)")
                    return@withContext MaxCommandResponse(
                        intent = "Exception",
                        shell_commands = emptyList(),
                        spoken_response = "Gemini ने API key नहीं मानी। या तो key गलत है या उसे इस मॉडल की अनुमति नहीं मिली। सेटिंग्स में जाकर key दोबारा डालिए।"
                    )
                }
                if (code == 429) {
                    Log.w(TAG, "HTTP 429 Rate limit exceeded on attempt $attempts. Delaying 2s...")
                    if (attempts < maxAttempts) {
                        delay(2000L)
                        continue
                    } else {
                        return@withContext MaxCommandResponse(
                            intent = "RateLimit",
                            shell_commands = emptyList(),
                            spoken_response = "माफ़ कीजिए सर, Google सर्वर पर अभी लिमिट पूरी हो गई है। कृपया थोड़ी देर में दोबारा कहिए।"
                        )
                    }
                }

                // If model was not found (404), thinkingConfig rejected (400), or server overloaded/unavailable (503, 500, 502, 504):
                // Dynamically rotate to next verified fast model in fleet with brief backoff!
                if (attempts < maxAttempts && (code == 404 || code == 400 || code == 503 || code == 500 || code == 502 || code == 504)) {
                    val errText = errBody
                    triedModels.add(selectedModel)
                    val fallbackCandidates = listOf(
                        "gemini-3.5-flash-lite",
                        "gemini-3.1-flash-lite",
                        "gemini-3.8-flash",
                        "gemini-3.7-flash",
                        "gemini-3.6-flash",
                        "gemini-3.5-flash"
                    )
                    val nextModel = fallbackCandidates.firstOrNull { it !in triedModels } ?: fallbackCandidates.first()
                    triedModels.add(nextModel)
                    Log.w(TAG, "HTTP $code on model '$selectedModel' ($errText). Rotating to '$nextModel'. Attempt $attempts/$maxAttempts.")
                    if (code == 503 || code == 500 || code == 502 || code == 504) {
                        delay(400L * attempts) // Brief backoff for transient server load
                    }
                    selectedModel = nextModel
                    lastKnownWorkingModel = nextModel
                    currentRequest = currentRequest.copy(
                        generationConfig = GeminiGenerationConfig(
                            temperature = 0.75,
                            topP = 0.95,
                            responseMimeType = "application/json",
                            thinkingConfig = null
                        )
                    )
                    continue
                }

                Log.e(TAG, "HTTP $code Error querying Gemini: $errBody", e)
                val friendlyMsg = when (code) {
                    404 -> "Gemini AI मॉडल उपलब्ध नहीं है (404)। कृपया सेटिंग्स में मॉडल चेक करें।"
                    503, 500, 502, 504 -> "माफ़ कीजिए सर, Google सर्वर पर अभी थोड़ा लोड है। कृपया एक सेकंड बाद दोबारा कहिए।"
                    429 -> "माफ़ कीजिए सर, रिक्वेस्ट लिमिट पहुँच गई है। कृपया थोड़ी देर में दोबारा कहिए।"
                    else -> "माफ़ कीजिए सर, सर्वर से संपर्क नहीं हो पाया। कृपया एक सेकंड बाद दोबारा कहिए।"
                }
                return@withContext MaxCommandResponse(
                    intent = "Exception",
                    shell_commands = emptyList(),
                    spoken_response = friendlyMsg
                )
            } catch (e: java.io.IOException) {
                Log.w(TAG, "Network IO exception on attempt $attempts: ${e.message}", e)
                if (attempts < maxAttempts) {
                    delay(500L * attempts)
                    continue
                }
                return@withContext MaxCommandResponse(
                    intent = "NetworkException",
                    shell_commands = emptyList(),
                    spoken_response = "माफ़ कीजिए सर, इंटरनेट कनेक्शन में समस्या आ रही है। कृपया नेटवर्क चेक करें।"
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error querying Gemini: ${e.message}", e)
                return@withContext MaxCommandResponse(
                    intent = "Exception",
                    shell_commands = emptyList(),
                    spoken_response = "माफ़ कीजिए सर, सर्वर से संपर्क नहीं हो पाया। कृपया दोबारा कहिए।"
                )
            }
        }

        MaxCommandResponse(
            intent = "Error",
            shell_commands = emptyList(),
            spoken_response = "माफ़ कीजिए सर, AI सर्वर अभी व्यस्त है। कृपया कुछ पलों में दोबारा कहें।"
        )
    }

    /**
     * Gemini sometimes puts a number, a boolean or a list where the schema wants text
     * (for example "parameters": {"hour": 4, "confirm": true}). Turn every value of the string maps
     * and string lists into text so one odd value does not throw away the whole command.
     */
    private fun stringifyLooseJson(json: String): String {
        val obj = org.json.JSONObject(json)
        for (key in listOf("parameters", "entities")) {
            val m = obj.optJSONObject(key) ?: continue
            val fixed = org.json.JSONObject()
            val it = m.keys()
            while (it.hasNext()) {
                val k = it.next()
                val v = m.opt(k)
                fixed.put(k, if (v == null || v == org.json.JSONObject.NULL) "" else v.toString())
            }
            obj.put(key, fixed)
        }
        for (key in listOf("shell_commands", "steps")) {
            val a = obj.optJSONArray(key) ?: continue
            val fixed = org.json.JSONArray()
            for (i in 0 until a.length()) fixed.put(a.opt(i)?.toString() ?: "")
            obj.put(key, fixed)
        }
        return obj.toString()
    }

    /** One plain call for helpers (screen reading, the screen agent). Returns the model's text, or null on any failure. */
    suspend fun generateOnce(
        apiKey: String,
        modelName: String,
        systemText: String,
        userText: String,
        imageJpegBase64: String? = null,
        json: Boolean = false,
        temperature: Double = 0.4
    ): String? = withContext(Dispatchers.IO) {
        val key = apiKey.trim()
        if (key.isBlank()) return@withContext null
        var model = modelName.trim().removePrefix("models/")
        if (model.isBlank() || model.contains("1.5") || model.contains("2.0") || model.contains("2.5") || model == "gemini-pro") {
            model = lastKnownWorkingModel ?: "gemini-3.5-flash-lite"
        }
        fun body(withThinking: Boolean): String {
            val parts = org.json.JSONArray().put(org.json.JSONObject().put("text", userText))
            if (imageJpegBase64 != null) {
                parts.put(org.json.JSONObject().put("inlineData", org.json.JSONObject().put("mimeType", "image/jpeg").put("data", imageJpegBase64)))
            }
            val gen = org.json.JSONObject().put("temperature", temperature)
            if (json) gen.put("responseMimeType", "application/json")
            if (withThinking && model.contains("flash")) gen.put("thinkingConfig", org.json.JSONObject().put("thinkingLevel", "MINIMAL"))
            return org.json.JSONObject()
                .put("systemInstruction", org.json.JSONObject().put("parts", org.json.JSONArray().put(org.json.JSONObject().put("text", systemText))))
                .put("contents", org.json.JSONArray().put(org.json.JSONObject().put("role", "user").put("parts", parts)))
                .put("generationConfig", gen)
                .toString()
        }
        for (withThinking in listOf(true, false)) {
            try {
                val req = okhttp3.Request.Builder()
                    .url(BASE_URL + "v1beta/models/$model:generateContent")
                    .header("x-goog-api-key", key)
                    .post(body(withThinking).toRequestBody("application/json".toMediaType()))
                    .build()
                okHttpClient.newCall(req).execute().use { resp ->
                    val txt = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        val partsArr = org.json.JSONObject(txt).optJSONArray("candidates")?.optJSONObject(0)
                            ?.optJSONObject("content")?.optJSONArray("parts")
                        val sb = StringBuilder()
                        if (partsArr != null) for (i in 0 until partsArr.length()) sb.append(partsArr.optJSONObject(i)?.optString("text").orEmpty())
                        lastKnownWorkingModel = model
                        return@withContext sb.toString().trim().ifBlank { null }
                    }
                    // A 400 can only be the thinking option on some models: try once more without it.
                    if (resp.code != 400) return@withContext null
                }
            } catch (e: Exception) {
                Log.w(TAG, "generateOnce failed: ${e.message}")
                return@withContext null
            }
        }
        null
    }

    /**
     * After a task, MAX tells the user what happened. The app supplies only the TRUE FACTS (what was done, whether it worked);
     * Gemini writes the sentence, so replies are never a fixed string and never claim more than the facts.
     * Returns null on any failure so the caller keeps the plain factual sentence.
     */
    suspend fun composeReply(apiKey: String, modelName: String, userRequest: String, facts: String, success: Boolean): String? {
        val system = """
            You are MAX, the user's voice assistant. You just finished a task they asked for and now say the result out loud.
            Use ONLY the facts you are given. If success is false, say honestly what did not work and, if it helps, the next thing that could be tried.
            If the facts say a detail is missing (which camera, which contact, what time), ask exactly that one short question.
            Never say anything was done that the facts do not say was done. Do not describe how you work.
            One or two natural sentences in Hindi Devanagari (English words stay in Latin). Fresh wording each time, no stock phrases,
            and do not start every reply with an honorific. Plain text only: no markdown, no lists, no emojis.
        """.trimIndent()
        val user = "User asked: $userRequest\nsuccess: $success\nFACTS: $facts"
        val out = generateOnce(apiKey, modelName, system, user, null, json = false, temperature = 0.7) ?: return null
        return sanitizeTtsText(out).ifBlank { null }
    }

    data class StreamedTurn(val response: MaxCommandResponse, val chunksSpoken: Int)

    private val STREAM_FORMAT_RULES = """
        STREAM FORMAT (this call only, overrides the output format above for the first line):
        Write CHAT or TASK as the very first word.
        - CHAT: ordinary conversation. After the word CHAT write ONLY the spoken answer as plain text in Hindi Devanagari: no JSON, no markdown, no lists. Put the direct answer in the first sentence so it can be spoken at once, then continue with the detail.
        - TASK: anything the phone must DO or check (apps, calls, messages, media, settings, files, network, alarms, undo of an action) or anything that needs the JSON fields. After the word TASK output the JSON object exactly as described above.
    """.trimIndent()

    /**
     * Streaming call for live conversation. For CHAT answers every finished sentence is handed to [onSentence]
     * while Gemini is still writing, so MAX starts speaking after about one sentence instead of after the whole reply.
     * TASK answers are collected and parsed exactly like the normal call.
     * Returns null when streaming did not work before anything was spoken, so the caller can use the normal call.
     */
    suspend fun streamVoiceQuery(
        userQuery: String,
        apiKey: String,
        modelName: String = "",
        history: List<MessageEntity> = emptyList(),
        memoryContext: String = "",
        interactionContext: String = "",
        actionContext: String = "",
        onSentence: (String) -> Unit
    ): StreamedTurn? = withContext(Dispatchers.IO) {
        val cleanQuery = userQuery.trim()
        val cleanKey = apiKey.trim()
        if (cleanQuery.isBlank() || cleanKey.isBlank()) return@withContext null

        var selectedModel = modelName.trim().removePrefix("models/")
        if (selectedModel.isBlank() || selectedModel.contains("1.5") || selectedModel.contains("2.0") || selectedModel.contains("2.5") || selectedModel == "gemini-pro") {
            selectedModel = lastKnownWorkingModel ?: "gemini-3.5-flash-lite"
        }
        val (contents, basePrompt) = assembleRequest(cleanQuery, history, memoryContext, interactionContext, actionContext)
        val request = GeminiGenerateRequest(
            systemInstruction = GeminiSystemInstruction(parts = listOf(GeminiPart(text = basePrompt + "\n\n" + STREAM_FORMAT_RULES))),
            contents = contents,
            generationConfig = GeminiGenerationConfig(
                temperature = 0.75,
                topP = 0.95,
                responseMimeType = null,
                thinkingConfig = if (selectedModel.contains("flash")) GeminiThinkingConfig(thinkingLevel = "MINIMAL") else null
            )
        )
        val bodyJson = try { moshi.adapter(GeminiGenerateRequest::class.java).toJson(request) } catch (e: Exception) { return@withContext null }
        val httpRequest = okhttp3.Request.Builder()
            .url(BASE_URL + "v1beta/models/$selectedModel:streamGenerateContent?alt=sse")
            .header("x-goog-api-key", cleanKey)
            .post(bodyJson.toRequestBody("application/json".toMediaType()))
            .build()
        val call = okHttpClient.newCall(httpRequest)
        val cancelHandle = kotlinx.coroutines.currentCoroutineContext()[kotlinx.coroutines.Job]?.invokeOnCompletion { call.cancel() }

        var chunks = 0
        try {
            val response = call.execute()
            response.use { resp ->
                if (!resp.isSuccessful) {
                    Log.w(TAG, "Streaming call refused (HTTP ${resp.code}); using the normal call")
                    return@withContext null
                }
                val source = resp.body?.source() ?: return@withContext null
                val respAdapter = moshi.adapter(GeminiGenerateResponse::class.java)

                val all = StringBuilder()
                var mode = 0                 // 0 = undecided, 1 = CHAT, 2 = TASK
                var chatStart = 0            // index in `all` where the spoken text begins
                var emittedUpTo = 0          // index in `all` up to which sentences were already spoken

                fun decideMode() {
                    if (mode != 0) return
                    val head = all.toString().trimStart()
                    if (head.length < 4) return
                    val lead = all.length - head.length
                    when {
                        head.startsWith("CHAT", ignoreCase = true) -> {
                            mode = 1
                            var k = lead + 4
                            while (k < all.length && (all[k] == ':' || all[k] == ' ' || all[k] == '\n' || all[k] == '\r' || all[k] == '-')) k++
                            chatStart = k
                            emittedUpTo = k
                        }
                        head.startsWith("TASK", ignoreCase = true) -> {
                            mode = 2
                            chatStart = lead + 4
                        }
                        else -> {
                            // The model ignored the format: JSON means a task, anything else is plain conversation.
                            if (head.contains('{')) { mode = 2; chatStart = lead } else { mode = 1; chatStart = lead; emittedUpTo = lead }
                        }
                    }
                }

                // A sentence is finished when its ending mark is followed by whitespace; the very last one is flushed at the end.
                val terminator = Regex("[।.!?]+[\"')\u201D]*(?=\\s)|\\n")
                fun emitReadySentences(final: Boolean) {
                    if (mode != 1) return
                    while (emittedUpTo < all.length) {
                        val pending = all.substring(emittedUpTo)
                        val m = terminator.find(pending)
                        val endIdx = when {
                            m != null -> m.range.last + 1
                            final && pending.isNotBlank() -> pending.length
                            else -> return
                        }
                        val sentence = pending.substring(0, endIdx).trim()
                        emittedUpTo += endIdx
                        val spoken = sanitizeTtsText(sentence)
                        if (spoken.isNotBlank()) {
                            chunks++
                            onSentence(spoken)
                        }
                    }
                }

                while (true) {
                    kotlinx.coroutines.currentCoroutineContext().ensureActive()
                    val line = source.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val payload = line.removePrefix("data:").trim()
                    if (payload.isEmpty() || payload == "[DONE]") continue
                    val piece = try {
                        respAdapter.fromJson(payload)?.candidates?.firstOrNull()?.content?.parts?.joinToString("") { it.text } ?: ""
                    } catch (_: Exception) { "" }
                    if (piece.isEmpty()) continue
                    all.append(piece)
                    decideMode()
                    if (mode == 1) emitReadySentences(final = false)
                }
                decideMode()
                if (mode == 0 && all.isNotBlank()) { mode = if (all.contains('{')) 2 else 1; chatStart = 0; emittedUpTo = 0 }
                lastKnownWorkingModel = selectedModel

                if (mode == 1) {
                    emitReadySentences(final = true)
                    val full = sanitizeTtsText(all.substring(chatStart))
                    if (full.isBlank()) return@withContext null
                    return@withContext StreamedTurn(
                        MaxCommandResponse(
                            intent = "CHAT", module = "CHAT", capability = "chat.general",
                            shell_commands = emptyList(), spoken_response = full
                        ),
                        chunks
                    )
                }
                if (mode == 2) {
                    val parsed = parseModelText(all.substring(chatStart), cleanQuery)
                    return@withContext StreamedTurn(parsed, 0)
                }
                return@withContext null
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Streaming call failed: ${e.message}")
            // If part of the answer was already spoken, do not speak it again through the normal call.
            return@withContext if (chunks > 0) StreamedTurn(
                MaxCommandResponse(intent = "CHAT", module = "CHAT", capability = "chat.general", shell_commands = emptyList(), spoken_response = ""),
                chunks
            ) else null
        } finally {
            cancelHandle?.dispose()
        }
    }

    /** Chat history + system prompt + memory/context blocks: identical for the normal and the streaming call. */
    private fun assembleRequest(
        cleanQuery: String,
        history: List<MessageEntity>,
        memoryContext: String,
        interactionContext: String,
        actionContext: String
    ): Pair<List<GeminiContent>, String> {
        val contentsList = mutableListOf<GeminiContent>()
        for (msg in history) {
            val roleName = if (msg.role == "user") "user" else "model"
            contentsList.add(
                GeminiContent(
                    role = roleName,
                    parts = listOf(GeminiPart(text = msg.content))
                )
            )
        }

        val lastMsg = history.lastOrNull()
        if (lastMsg == null || lastMsg.role != "user" || !lastMsg.content.contains(cleanQuery)) {
            contentsList.add(
                GeminiContent(
                    role = "user",
                    parts = listOf(GeminiPart(text = "User voice query: \"$cleanQuery\""))
                )
            )
        }

        // Show the model how its latest replies began so it never repeats an opening
        val recentOpenings = history
            .filter { it.role != "user" }
            .takeLast(6)
            .map { m ->
                m.content.replace(Regex("^\\[Module:[^\\]]*\\]\\s*"), "").trim()
                    .split(Regex("\\s+")).take(6).joinToString(" ")
            }
            .filter { it.isNotBlank() }
        val openingsBlock = if (recentOpenings.isNotEmpty()) {
            "RECENT_REPLY_OPENINGS (do not begin a new reply with any of these):\n" +
                recentOpenings.joinToString("\n") { "- $it" }
        } else ""

        val fullSystemPrompt = listOf(systemPrompt, memoryContext, openingsBlock, interactionContext, actionContext)
            .filter { it.isNotBlank() }
            .joinToString("\n\n")
        return Pair(contentsList, fullSystemPrompt)
    }

    /** Turns the model's raw text (JSON, maybe wrapped in prose) into a MaxCommandResponse. Never throws. */
    private fun parseModelText(rawText: String, cleanQuery: String): MaxCommandResponse {
        val unfenced = rawText
            .replace("```json", "")
            .replace("```", "")
            .trim()
        // The model sometimes adds a sentence before or after the JSON: keep only the object itself.
        val jsonStart = unfenced.indexOf('{')
        val jsonEnd = unfenced.lastIndexOf('}')
        val cleanJson = if (jsonStart >= 0 && jsonEnd > jsonStart) unfenced.substring(jsonStart, jsonEnd + 1) else unfenced

        val adapter = moshi.adapter(MaxCommandResponse::class.java)
        val parsedResponse = try {
            adapter.fromJson(cleanJson)
        } catch (e: Exception) {
            Log.w(TAG, "Moshi parsing failed, retrying with loosely typed values", e)
            try { adapter.fromJson(stringifyLooseJson(cleanJson)) } catch (e2: Exception) { null }
        }

        if (parsedResponse != null) {
            var spoken = parsedResponse.spoken_response
            if (spoken.isBlank() && parsedResponse.addressed_to_max) {
                val fallbackMatch = Regex("\"(?:spoken_response|response|message|reply|text)\"\\s*:\\s*\"([^\"]+)\"").find(cleanJson)
                spoken = fallbackMatch?.groupValues?.get(1) ?: fallbackLine()
            }
            val sanitizedResponseText = sanitizeTtsText(spoken)

            // Safety Normalization Gate: Conversational queries must NEVER trigger media or app launch
            val intentUp = parsedResponse.intent.trim().uppercase()
            val moduleUp = parsedResponse.module.trim().uppercase()
            val cleanQLower = cleanQuery.lowercase().trim()
            val isConversationalQuery = moduleUp == "CHAT" || intentUp == "CHAT" ||
                    intentUp.contains("GREETING") || intentUp.contains("QUESTION") || intentUp.contains("CONVERSATION") ||
                    parsedResponse.capability.trim().lowercase() == "chat.general" ||
                    cleanQLower in setOf(
                        "how are you", "what is your name", "who are you", "tell me something",
                        "कहा हो", "क्या हाल है", "कैसे हो", "कौन हो तुम", "तुम्हारा नाम क्या है",
                        "hello", "hi", "namaste", "नमस्ते", "प्रणाम", "सुप्रभात"
                    ) || cleanQLower.startsWith("how are you") || cleanQLower.startsWith("who are you") ||
                    cleanQLower.startsWith("what is your name")

            if (isConversationalQuery) {
                Log.d("CHAT_GATE", "Sanitizing conversational response for query: '$cleanQuery'. Ensuring target_app='' and capability='chat.general'")
                return parsedResponse.copy(
                    intent = "CHAT",
                    module = "CHAT",
                    capability = "chat.general",
                    target = "",
                    target_app = "",
                    tool_name = "",
                    shell_commands = emptyList(),
                    steps = emptyList(),
                    spoken_response = sanitizedResponseText
                )
            }

            return parsedResponse.copy(spoken_response = sanitizedResponseText)
        } else {
            val fallbackMatch = Regex("\"(?:spoken_response|response|message|reply|text)\"\\s*:\\s*\"([^\"]+)\"").find(cleanJson)
            val extractedText = fallbackMatch?.groupValues?.get(1)
            val finalFallback = if (!extractedText.isNullOrBlank()) {
                sanitizeTtsText(extractedText)
            } else {
                fallbackLine()
            }
            return MaxCommandResponse(
                intent = "CHAT",
                module = "CHAT",
                shell_commands = emptyList(),
                spoken_response = finalFallback
            )
        }
    }

    suspend fun processVoiceQueryWithMemory(
        userQuery: String,
        apiKey: String,
        modelName: String = "",
        history: List<MessageEntity> = emptyList(),
        memoryContext: String = "",
        interactionContext: String = "",
        actionContext: String = ""
    ): MaxCommandResponse = processVoiceQuery(
        userQuery = userQuery,
        apiKey = apiKey,
        modelName = modelName,
        history = history,
        memoryContext = memoryContext,
        interactionContext = interactionContext,
        actionContext = actionContext
    )
}

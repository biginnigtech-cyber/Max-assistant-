package com.example.engine

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URL
import java.util.Collections

object NetworkController {
    private const val TAG = "NetworkController"

    data class NetworkInfoResult(
        val localIp: String,
        val publicIp: String,
        val interfaceName: String,
        val gateway: String,
        val isWifi: Boolean,
        val isCellular: Boolean,
        val dnsServers: List<String>
    )

    data class WifiScanResult(
        val ssid: String,
        val bssid: String,
        val signalDbm: Int,
        val frequencyMhz: Int,
        val capabilities: String
    )

    data class PortScanResult(
        val host: String,
        val openPorts: List<Int>,
        val scannedPorts: List<Int>,
        val durationMs: Long
    )

    data class WifiChipsetResult(
        val chipsetName: String,
        val driverName: String,
        val interfaceName: String,
        val isDriverLoaded: Boolean,
        val isInterfaceUp: Boolean,
        val details: List<String>
    )

    data class ConnectedDeviceResult(
        val ip: String,
        val mac: String,
        val hostname: String,
        val vendor: String,
        val isGateway: Boolean
    )

    suspend fun getNetworkDetails(context: Context): NetworkInfoResult = withContext(Dispatchers.IO) {
        var localIp = "Unknown"
        var ifaceName = "wlan0"
        var gateway = "Unknown"

        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                if (intf.isLoopback || !intf.isUp) continue
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress && addr.hostAddress?.contains(":") == false) {
                        localIp = addr.hostAddress ?: "Unknown"
                        ifaceName = intf.name
                        break
                    }
                }
                if (localIp != "Unknown") break
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error resolving local IP: ${e.message}")
        }

        // Get gateway via ip route or root
        val routeRes = RootCommandEngine.execute("ip route | grep default | awk '{print \$3}'")
        if (routeRes.success && routeRes.stdout.isNotBlank()) {
            gateway = routeRes.stdout.lines().first().trim()
        }

        // Get public IP safely
        var publicIp = "Offline/Unreachable"
        try {
            val url = URL("https://api.ipify.org")
            val connection = url.openConnection()
            connection.connectTimeout = 3000
            connection.readTimeout = 3000
            publicIp = connection.getInputStream().bufferedReader().readText().trim()
        } catch (_: Exception) {
            val curlRes = RootCommandEngine.execute("curl -s --connect-timeout 3 https://ifconfig.me")
            if (curlRes.success && curlRes.stdout.isNotBlank()) {
                publicIp = curlRes.stdout.trim()
            }
        }

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNet = cm?.activeNetwork
        val caps = cm?.getNetworkCapabilities(activeNet)
        val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val isCell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

        // DNS servers via getprop
        val dnsRes = RootCommandEngine.execute("getprop net.dns1; getprop net.dns2")
        val dnsList = dnsRes.stdout.lines().filter { it.isNotBlank() }

        NetworkInfoResult(
            localIp = localIp,
            publicIp = publicIp,
            interfaceName = ifaceName,
            gateway = gateway,
            isWifi = isWifi,
            isCellular = isCell,
            dnsServers = dnsList
        )
    }

    /**
     * Inspects Wi-Fi Adapter hardware chipset, external USB dongles (OTG),
     * PCI interfaces, kernel driver modules, and loads drivers if needed.
     */
    suspend fun detectWifiChipsetAndDrivers(
        onProgress: ((String) -> Unit)? = null
    ): WifiChipsetResult = withContext(Dispatchers.IO) {
        onProgress?.invoke("Inspecting Wi-Fi adapter chipset & kernel drivers...")
        val details = mutableListOf<String>()

        var detectedChipset = "Internal SoC Wi-Fi"
        var detectedDriver = "Android wlan stack"
        var targetIface = "wlan0"
        var driverLoaded = false
        var interfaceUp = false

        // 1. Check lsusb for external Wi-Fi dongles (Atheros AR9271, Realtek, Ralink, etc.)
        val lsusbRes = RootCommandEngine.execute("lsusb 2>/dev/null || which lsusb")
        if (lsusbRes.success && lsusbRes.stdout.isNotBlank()) {
            val lines = lsusbRes.stdout.lines()
            for (line in lines) {
                val lower = line.lowercase()
                when {
                    lower.contains("atheros") || lower.contains("ar9271") || lower.contains("ath9k") -> {
                        detectedChipset = "Qualcomm Atheros AR9271 (High Power USB)"
                        detectedDriver = "ath9k_htc"
                        details.add("Detected USB Adapter: $line")
                    }
                    lower.contains("realtek") || lower.contains("rtl8812") || lower.contains("rtl8814") || lower.contains("rtl8187") -> {
                        detectedChipset = "Realtek 802.11ac / RTL USB Dongle"
                        detectedDriver = "rtl88xxau / rtl8187"
                        details.add("Detected USB Adapter: $line")
                    }
                    lower.contains("ralink") || lower.contains("rt3070") || lower.contains("rt5370") || lower.contains("mediatek") -> {
                        detectedChipset = "Ralink / MediaTek RT3070/RT5370"
                        detectedDriver = "rt2800usb"
                        details.add("Detected USB Adapter: $line")
                    }
                    lower.contains("wireless") || lower.contains("wlan") || lower.contains("802.11") -> {
                        detectedChipset = line.substringAfter(":").trim()
                        details.add("Detected Wireless USB: $line")
                    }
                }
            }
        }

        // 2. Check lspci or internal driver links
        val lspciRes = RootCommandEngine.execute("lspci 2>/dev/null | grep -i -E 'network|wireless|wifi'")
        if (lspciRes.success && lspciRes.stdout.isNotBlank()) {
            details.add("PCI Adapter: ${lspciRes.stdout.trim()}")
            if (detectedChipset.startsWith("Internal")) {
                detectedChipset = lspciRes.stdout.trim()
            }
        }

        // 3. Inspect /sys/class/net/ for wireless interfaces
        val ifacesRes = RootCommandEngine.execute("ls /sys/class/net")
        if (ifacesRes.success) {
            val netIfaces = ifacesRes.stdout.lines().map { it.trim() }.filter { it.isNotBlank() }
            if (netIfaces.contains("wlan1")) {
                targetIface = "wlan1" // Priority to external USB adapter if present
            } else if (netIfaces.contains("wlan0")) {
                targetIface = "wlan0"
            }
        }

        // 4. Read driver symlink from /sys/class/net/$targetIface/device/driver
        val driverLinkRes = RootCommandEngine.execute("readlink -f /sys/class/net/$targetIface/device/driver 2>/dev/null")
        if (driverLinkRes.success && driverLinkRes.stdout.isNotBlank()) {
            val dName = driverLinkRes.stdout.trim().substringAfterLast("/")
            if (dName.isNotBlank()) {
                detectedDriver = dName
                driverLoaded = true
                details.add("Active Kernel Driver: $dName on $targetIface")
            }
        }

        // 5. Query Android wlan hardware properties & kernel logs
        val propRes = RootCommandEngine.execute("getprop ro.hardware.wlan; getprop ro.boot.hardware; getprop ro.board.platform")
        val propOut = propRes.stdout.lines().filter { it.isNotBlank() }
        if (propOut.isNotEmpty()) {
            details.add("Hardware Platform: ${propOut.joinToString(" / ")}")
            if (detectedChipset.startsWith("Internal")) {
                val hw = propOut.first()
                detectedChipset = when {
                    hw.contains("qcom", ignoreCase = true) || hw.contains("qualcomm", ignoreCase = true) -> "Qualcomm WCNSS / QCA Wi-Fi"
                    hw.contains("mtk", ignoreCase = true) || hw.contains("mediatek", ignoreCase = true) -> "MediaTek Connectivity Wi-Fi"
                    hw.contains("exynos", ignoreCase = true) || hw.contains("samsung", ignoreCase = true) -> "Broadcom / Samsung Exynos Wi-Fi"
                    else -> "Android $hw Wi-Fi"
                }
            }
        }

        // 6. Ensure interface is up and driver loaded
        onProgress?.invoke("Checking driver state for $targetIface ($detectedDriver)...")
        val upRes = RootCommandEngine.execute("ip link set $targetIface up 2>&1")
        val ifaceStateRes = RootCommandEngine.execute("cat /sys/class/net/$targetIface/operstate 2>/dev/null")
        val operstate = ifaceStateRes.stdout.trim()
        interfaceUp = (operstate == "up" || operstate == "unknown" || upRes.exitCode == 0)
        driverLoaded = true

        details.add("Interface $targetIface operstate: ${if (interfaceUp) "UP" else operstate}")

        WifiChipsetResult(
            chipsetName = detectedChipset,
            driverName = detectedDriver,
            interfaceName = targetIface,
            isDriverLoaded = driverLoaded,
            isInterfaceUp = interfaceUp,
            details = details
        )
    }

    /**
     * Scans local network to identify ALL connected devices (IPs, MACs, Vendors, Gateway).
     * Performs active ARP discovery and reads kernel ARP cache.
     */
    suspend fun scanNetworkConnectedDevices(
        context: Context,
        onProgress: ((String) -> Unit)? = null
    ): List<ConnectedDeviceResult> = withContext(Dispatchers.IO) {
        onProgress?.invoke("Checking network gateway & subnet parameters...")
        val netInfo = getNetworkDetails(context)
        val gatewayIp = netInfo.gateway
        val localIp = netInfo.localIp

        val subnetBase = if (localIp.contains(".") && localIp != "Unknown") {
            localIp.substringBeforeLast(".") + "."
        } else if (gatewayIp.contains(".") && gatewayIp != "Unknown") {
            gatewayIp.substringBeforeLast(".") + "."
        } else {
            // No usable IP: do not guess a subnet and scan a network the phone is not on.
            onProgress?.invoke("फ़ोन किसी नेटवर्क से जुड़ा नहीं दिखता, इसलिए स्कैन नहीं हो सकता।")
            return@withContext emptyList()
        }

        onProgress?.invoke("Performing active ARP sweep on subnet ${subnetBase}0/24...")

        // Fast parallel subnet ping sweep to populate kernel ARP table
        val sweepCmd = """
            for i in $(seq 1 40); do ping -c 1 -W 1 ${subnetBase}${'$'}i >/dev/null 2>&1 & done
            for i in $(seq 41 80); do ping -c 1 -W 1 ${subnetBase}${'$'}i >/dev/null 2>&1 & done
            for i in $(seq 81 120); do ping -c 1 -W 1 ${subnetBase}${'$'}i >/dev/null 2>&1 & done
            for i in $(seq 121 160); do ping -c 1 -W 1 ${subnetBase}${'$'}i >/dev/null 2>&1 & done
            for i in $(seq 161 200); do ping -c 1 -W 1 ${subnetBase}${'$'}i >/dev/null 2>&1 & done
            for i in $(seq 201 254); do ping -c 1 -W 1 ${subnetBase}${'$'}i >/dev/null 2>&1 & done
            sleep 1
        """.trimIndent()
        RootCommandEngine.execute(sweepCmd)

        onProgress?.invoke("Parsing kernel ARP & neighbor table...")

        val devices = mutableListOf<ConnectedDeviceResult>()
        val seenIps = mutableSetOf<String>()

        // 1. Read ip neigh
        val neighRes = RootCommandEngine.execute("ip neigh show")
        if (neighRes.success && neighRes.stdout.isNotBlank()) {
            for (line in neighRes.stdout.lines()) {
                // e.g.: 192.168.1.1 dev wlan0 lladdr 00:11:22:33:44:55 REACHABLE
                val tokens = line.split("\\s+".toRegex())
                if (tokens.size >= 4) {
                    val ip = tokens[0]
                    val lladdrIdx = tokens.indexOf("lladdr")
                    val mac = if (lladdrIdx != -1 && lladdrIdx + 1 < tokens.size) tokens[lladdrIdx + 1] else "Unknown"
                    val state = tokens.lastOrNull() ?: ""

                    if (ip.contains(".") && !seenIps.contains(ip) && state != "FAILED") {
                        seenIps.add(ip)
                        val vendor = resolveVendor(mac)
                        val isGw = (ip == gatewayIp)
                        devices.add(
                            ConnectedDeviceResult(
                                ip = ip,
                                mac = mac,
                                hostname = if (isGw) "Wi-Fi Router / Gateway" else resolveHostname(ip),
                                vendor = vendor,
                                isGateway = isGw
                            )
                        )
                    }
                }
            }
        }

        // 2. Read /proc/net/arp
        val arpRes = RootCommandEngine.execute("cat /proc/net/arp")
        if (arpRes.success && arpRes.stdout.isNotBlank()) {
            for (line in arpRes.stdout.lines().drop(1)) {
                val tokens = line.split("\\s+".toRegex()).filter { it.isNotBlank() }
                if (tokens.size >= 4) {
                    val ip = tokens[0]
                    val mac = tokens[3]
                    if (ip.contains(".") && !seenIps.contains(ip) && mac != "00:00:00:00:00:00") {
                        seenIps.add(ip)
                        val isGw = (ip == gatewayIp)
                        devices.add(
                            ConnectedDeviceResult(
                                ip = ip,
                                mac = mac,
                                hostname = if (isGw) "Wi-Fi Router / Gateway" else resolveHostname(ip),
                                vendor = resolveVendor(mac),
                                isGateway = isGw
                            )
                        )
                    }
                }
            }
        }

        // Sort so gateway is first, then ordered by IP
        devices.sortByDescending { it.isGateway }
        onProgress?.invoke("Scan complete: Found ${devices.size} active devices.")
        devices
    }

    private fun resolveVendor(mac: String): String {
        val clean = mac.replace(":", "").uppercase()
        if (clean.length < 6) return "Unknown Vendor"
        val prefix = clean.substring(0, 6)
        return when {
            prefix.startsWith("001A11") || prefix.startsWith("ACBC32") || prefix.startsWith("F01898") -> "Apple Inc."
            prefix.startsWith("50C7BF") || prefix.startsWith("50D2F5") || prefix.startsWith("F4F5DB") || prefix.startsWith("E84E06") -> "TP-Link Technologies"
            prefix.startsWith("001F3B") || prefix.startsWith("00215C") || prefix.startsWith("B827EB") || prefix.startsWith("DCA632") -> "Raspberry Pi Foundation"
            prefix.startsWith("84F3EB") || prefix.startsWith("600194") || prefix.startsWith("2462AB") || prefix.startsWith("30AEA4") -> "Espressif IoT (Smart Device)"
            prefix.startsWith("001599") || prefix.startsWith("F40F24") || prefix.startsWith("A85B78") || prefix.startsWith("C0EEFB") -> "Samsung Electronics"
            prefix.startsWith("7811DC") || prefix.startsWith("640980") || prefix.startsWith("04CF4B") -> "Xiaomi Communications"
            prefix.startsWith("F4F5E8") || prefix.startsWith("001A80") || prefix.startsWith("28CFDA") -> "Google Nest / Chromecast"
            prefix.startsWith("0019D2") || prefix.startsWith("74D435") || prefix.startsWith("34E6D7") -> "Intel Corporate"
            else -> "LAN Device / Smartphone"
        }
    }

    private fun resolveHostname(ip: String): String {
        return try {
            val addr = InetAddress.getByName(ip)
            val host = addr.canonicalHostName
            if (host == ip) "LAN Node" else host
        } catch (_: Exception) {
            "LAN Node"
        }
    }

    suspend fun scanNearbyWifi(
        context: Context,
        onProgress: ((String) -> Unit)? = null
    ): List<WifiScanResult> = withContext(Dispatchers.IO) {
        onProgress?.invoke("Scanning nearby WiFi access points...")
        val results = mutableListOf<WifiScanResult>()

        // 1. Real values from the system scan results (needs the location permission to be non-empty).
        try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            @Suppress("DEPRECATION")
            wm?.startScan()
            kotlinx.coroutines.delay(2500)
            @Suppress("DEPRECATION")
            val scans = wm?.scanResults ?: emptyList()
            for (s in scans) {
                if (results.none { it.bssid.equals(s.BSSID, ignoreCase = true) }) {
                    @Suppress("DEPRECATION")
                    val name = s.SSID
                    results.add(
                        WifiScanResult(
                            ssid = if (name.isNullOrBlank()) "Hidden" else name,
                            bssid = s.BSSID ?: "Unknown",
                            signalDbm = s.level,
                            frequencyMhz = s.frequency,
                            capabilities = s.capabilities ?: ""
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "WifiManager scan failed: ${e.message}")
        }

        // 2. Root fallback. Columns: BSSID  Frequency  RSSI  Age  SSID  Flags. Lines that do not parse are skipped;
        //    nothing is invented (the old code filled in -60 dBm / 2412 MHz / WPA2 for every network).
        if (results.isEmpty()) {
            val rootScan = RootCommandEngine.execute("cmd wifi start-scan; sleep 2; cmd wifi list-scan-results")
            if (rootScan.success) {
                val rowRegex = Regex("^([0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5})\\s+(\\d{4,5})\\s+(-?\\d+)\\S*\\s+\\S+\\s+(.*?)\\s*(\\[.*\\])?\\s*$")
                for (line in rootScan.stdout.lines()) {
                    val m = rowRegex.find(line.trim()) ?: continue
                    val bssid = m.groupValues[1]
                    if (results.any { it.bssid.equals(bssid, ignoreCase = true) }) continue
                    results.add(
                        WifiScanResult(
                            ssid = m.groupValues[4].ifBlank { "Hidden" },
                            bssid = bssid,
                            signalDbm = m.groupValues[3].toIntOrNull() ?: 0,
                            frequencyMhz = m.groupValues[2].toIntOrNull() ?: 0,
                            capabilities = m.groupValues[5]
                        )
                    )
                }
            }
        }

        results.sortByDescending { it.signalDbm }
        onProgress?.invoke("WiFi scan complete. Detected ${results.size} networks.")
        results
    }

    /** A host name or IP only: letters, digits, dots, dashes, colons (IPv6). Never an option such as "-f". */
    private fun cleanHost(host: String): String {
        val h = host.trim().replace(Regex("[^a-zA-Z0-9.:-]"), "")
        return if (h.isBlank() || h.startsWith("-")) "" else h
    }

    suspend fun pingHost(host: String, count: Int = 4): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val safeHost = cleanHost(host)
        if (safeHost.isBlank()) return@withContext Pair(false, "Invalid host")

        val res = RootCommandEngine.execute("ping -c ${count.coerceIn(1, 10)} -W 2 $safeHost")
        Pair(res.success, res.stdout.ifBlank { res.stderr })
    }

    suspend fun dnsLookup(host: String): List<String> = withContext(Dispatchers.IO) {
        val safeHost = cleanHost(host)
        if (safeHost.isBlank()) return@withContext emptyList()

        try {
            val addrs = InetAddress.getAllByName(safeHost)
            addrs.map { it.hostAddress ?: "" }.filter { it.isNotBlank() }
        } catch (e: Exception) {
            val rootLookup = RootCommandEngine.execute("nslookup $safeHost | grep Address | tail -n +2 | awk '{print \$2}'")
            if (rootLookup.success && rootLookup.stdout.isNotBlank()) {
                rootLookup.stdout.lines().filter { it.isNotBlank() }
            } else {
                emptyList()
            }
        }
    }

    suspend fun scanPorts(
        targetHost: String,
        portsToScan: List<Int> = listOf(21, 22, 23, 25, 53, 80, 110, 139, 443, 445, 8080, 8443),
        onProgress: ((completed: Int, total: Int, currentPort: Int) -> Unit)? = null
    ): PortScanResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val openPorts = mutableListOf<Int>()
        val total = portsToScan.size
        val targetHost = cleanHost(targetHost)
        if (targetHost.isBlank()) {
            return@withContext PortScanResult("", emptyList(), portsToScan, 0)
        }

        if (KaliCommandEngine.isToolInstalled("nmap")) {
            val portListStr = portsToScan.joinToString(",")
            val kaliRes = KaliCommandEngine.execute("nmap", "-p $portListStr -T4 $targetHost")
            if (kaliRes.success) {
                val openFromNmap = kaliRes.output.lines()
                    .filter { it.contains("/tcp") && it.contains("open") }
                    .mapNotNull { it.substringBefore("/").trim().toIntOrNull() }
                return@withContext PortScanResult(targetHost, openFromNmap, portsToScan, System.currentTimeMillis() - startTime)
            }
        }

        for ((idx, port) in portsToScan.withIndex()) {
            onProgress?.invoke(idx + 1, total, port)
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(targetHost, port), 250)
                    openPorts.add(port)
                }
            } catch (_: Exception) {}
        }

        PortScanResult(
            host = targetHost,
            openPorts = openPorts,
            scannedPorts = portsToScan,
            durationMs = System.currentTimeMillis() - startTime
        )
    }
}

package com.example.engine

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.File
import java.io.InputStreamReader

object TermuxCommandEngine {
    private const val TAG = "TermuxCommandEngine"

    const val TERMUX_PACKAGE = "com.termux"
    const val TERMUX_FILES_DIR = "/data/data/com.termux/files"
    const val TERMUX_PREFIX = "/data/data/com.termux/files/usr"
    const val TERMUX_BIN = "/data/data/com.termux/files/usr/bin"
    const val TERMUX_HOME = "/data/data/com.termux/files/home"

    data class TermuxResult(
        val success: Boolean,
        val exitCode: Int,
        val output: String,
        val error: String,
        val durationMs: Long = 0
    )

    private val _termuxStreamFlow = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val termuxStreamFlow: SharedFlow<String> = _termuxStreamFlow.asSharedFlow()

    suspend fun isTermuxInstalled(context: Context? = null): Boolean = withContext(Dispatchers.IO) {
        if (context != null) {
            try {
                context.packageManager.getPackageInfo(TERMUX_PACKAGE, 0)
                return@withContext true
            } catch (_: PackageManager.NameNotFoundException) {
            }
        }

        // Check file existence directly or via root
        val dir = File(TERMUX_FILES_DIR)
        if (dir.exists()) return@withContext true

        val rootCheck = RootCommandEngine.execute("test -d $TERMUX_FILES_DIR && echo 'EXISTS'")
        rootCheck.stdout.contains("EXISTS")
    }

    suspend fun getInstalledTermuxPackages(): List<String> = withContext(Dispatchers.IO) {
        val check = execute("dpkg -l | awk '{print \$2}'")
        if (check.success && check.output.isNotBlank()) {
            check.output.lines().filter { it.isNotBlank() && !it.startsWith("Name") }
        } else {
            val list = execute("ls $TERMUX_BIN")
            list.output.lines().filter { it.isNotBlank() }
        }
    }

    suspend fun execute(
        command: String,
        onOutputLine: ((String) -> Unit)? = null
    ): TermuxResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val stdoutBuilder = StringBuilder()
        val stderrBuilder = StringBuilder()
        var exitCode = -1

        Log.d(TAG, "Executing in Termux environment: $command")
        _termuxStreamFlow.tryEmit("[TERMUX] $ $command")

        // Build wrapped environment command
        val wrappedCommand = """
            export PREFIX=$TERMUX_PREFIX
            export PATH=$TERMUX_BIN:${'$'}PATH
            export LD_LIBRARY_PATH=$TERMUX_PREFIX/lib
            export HOME=$TERMUX_HOME
            cd $TERMUX_HOME 2>/dev/null || cd /sdcard
            $command
        """.trimIndent()

        // Same single root shell (blocklist + time limit) instead of a private `su` with neither.
        val res = RootCommandEngine.executeLong(wrappedCommand, timeoutMs = 5 * 60_000L) { l ->
            _termuxStreamFlow.tryEmit("[TERMUX OUT] $l")
            onOutputLine?.invoke(l)
        }
        stdoutBuilder.append(res.stdout)
        stderrBuilder.append(res.stderr)
        exitCode = res.exitCode
        if (res.stderr.isNotBlank()) _termuxStreamFlow.tryEmit("[TERMUX ERR] ${res.stderr}")

        val duration = System.currentTimeMillis() - startTime
        val success = (exitCode == 0)

        TermuxResult(
            success = success,
            exitCode = exitCode,
            output = stdoutBuilder.toString().trim(),
            error = stderrBuilder.toString().trim(),
            durationMs = duration
        )
    }
}

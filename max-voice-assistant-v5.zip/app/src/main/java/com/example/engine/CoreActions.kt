package com.example.engine

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import com.example.utils.TimeParser
import java.util.Calendar

/**
 * One single place for alarm, timer and clock answers.
 * VoiceIntentRouter calls this, so
 * so a fix made here is a fix everywhere (no more three copies drifting apart).
 *
 * Nothing here ever invents a default time: if the time is not understood, MAX asks.
 */
object CoreActions {

    data class Outcome(val success: Boolean, val spoken: String, val logs: List<String>)

    suspend fun alarm(context: Context, params: Map<String, String>, rawQuery: String = ""): Outcome {
        val q = rawQuery.ifBlank { params["_raw_query"].orEmpty() }
        val t = TimeParser.alarmFromParameters(params) ?: TimeParser.parseAlarmTime(q)
            ?: return Outcome(false, "कितने बजे का अलार्म लगाऊँ?", listOf("Alarm not set: no time understood"))
        val msg = params["message"]?.takeIf { it.isNotBlank() } ?: "MAX Alarm"
        val res = AutomationEngine.setAlarm(context, t.hour, t.minute, msg)
        return Outcome(res.success, res.spokenResponse, res.actionsExecuted)
    }

    suspend fun timer(context: Context, params: Map<String, String>, rawQuery: String = ""): Outcome {
        val q = rawQuery.ifBlank { params["_raw_query"].orEmpty() }
        val seconds = TimeParser.timerFromParameters(params) ?: TimeParser.parseTimerSeconds(q)
            ?: return Outcome(false, "कितनी देर का टाइमर लगाऊँ?", listOf("Timer not set: no duration understood"))
        val msg = params["message"]?.takeIf { it.isNotBlank() } ?: "MAX Timer"
        val res = AutomationEngine.setTimer(context, seconds, msg)
        return Outcome(res.success, res.spokenResponse, res.actionsExecuted)
    }

    private fun openList(context: Context, action: String, spoken: String, why: String): Outcome = try {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Outcome(true, spoken, listOf(why))
    } catch (e: Exception) {
        Outcome(false, "घड़ी ऐप खुल नहीं पाई, इसलिए मैं यह नहीं कर सका।", listOf("$why failed: ${e.message}"))
    }

    /**
     * Turns an alarm off: the one named by time, all of them, or the next one. This is the missing half of "set an alarm";
     * before, "disable the alarm" simply set another one. The clock app does the deleting, so the answer says what was
     * asked of it instead of pretending to know the result.
     */
    suspend fun cancelAlarm(context: Context, params: Map<String, String>, rawQuery: String = ""): Outcome {
        val q = rawQuery.ifBlank { params["_raw_query"].orEmpty() }
        val all = params["mode"].equals("all", true) || params["all"].equals("true", true)
        val t = if (all) null else (TimeParser.alarmFromParameters(params) ?: TimeParser.parseAlarmTime(q))
        return try {
            val intent = Intent(AlarmClock.ACTION_DISMISS_ALARM).apply {
                when {
                    all -> putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_ALL)
                    t != null -> {
                        putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_TIME)
                        putExtra(AlarmClock.EXTRA_HOUR, t.hour)
                        putExtra(AlarmClock.EXTRA_MINUTES, t.minute)
                        putExtra(AlarmClock.EXTRA_IS_PM, t.hour >= 12)
                    }
                    else -> putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_NEXT)
                }
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            val what = when {
                all -> "सारे अलार्म"
                t != null -> "${TimeParser.spokenClockHindi(t.hour, t.minute)} का अलार्म"
                else -> "अगला अलार्म"
            }
            Outcome(true, "$what बंद करने का आदेश घड़ी ऐप को दे दिया है। अगर वह फिर भी सूची में दिखे तो बताइए, मैं सूची खोल दूँगा।", listOf("Dismiss alarm requested: all=$all time=${t?.hour}:${t?.minute}"))
        } catch (e: Exception) {
            openList(
                context, AlarmClock.ACTION_SHOW_ALARMS,
                "घड़ी ऐप अलार्म हटाने का आदेश नहीं मान रहा, इसलिए अलार्म की सूची खोल दी है, वहाँ से बंद कर दीजिए।",
                "Dismiss not supported (${e.message}); opened the alarm list"
            )
        }
    }

    suspend fun cancelTimer(context: Context): Outcome = try {
        // ACTION_DISMISS_TIMER exists from Android 8; the app supports Android 7 too.
        if (android.os.Build.VERSION.SDK_INT < 26) throw UnsupportedOperationException("needs Android 8")
        context.startActivity(Intent(AlarmClock.ACTION_DISMISS_TIMER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Outcome(true, "टाइमर बंद करने का आदेश घड़ी ऐप को दे दिया है।", listOf("Dismiss timer requested"))
    } catch (e: Exception) {
        openList(context, AlarmClock.ACTION_SHOW_ALARMS, "घड़ी ऐप टाइमर बंद करने का आदेश नहीं मान रहा, इसलिए घड़ी खोल दी है।", "Dismiss timer not supported (${e.message})")
    }

    /** The real clock, spoken in natural Hindi. */
    fun clockAnswer(isDate: Boolean): String {
        val cal = Calendar.getInstance()
        return if (isDate) TimeParser.spokenDateHindi(cal) else TimeParser.spokenNowHindi(cal)
    }
}

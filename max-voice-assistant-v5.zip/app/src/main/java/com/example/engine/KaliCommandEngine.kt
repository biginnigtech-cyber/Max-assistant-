package com.example.engine

import com.example.utils.ShellQuote

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader

object KaliCommandEngine {
    private const val TAG = "KaliCommandEngine"

    private val POSSIBLE_CHROOT_PATHS = listOf(
        "/data/local/nhsystem/kali-arm64",
        "/data/local/nhsystem/kali-armhf",
        "/data/local/nhsystem/kali-amd64",
        "/data/local/kali-arm64",
        "/data/local/kali-armhf"
    )

    val KNOWN_KALI_TOOLS = listOf(
        "nmap",
        "wifite",
        "aircrack-ng",
        "airodump-ng",
        "aireplay-ng",
        "tcpdump",
        "tshark",
        "hydra",
        "msfconsole",
        "sqlmap",
        "nikto",
        "john",
        "hashcat",
        "macchanger",
        "responder",
        "ettercap",
        "curl",
        "wget"
    )

    data class KaliExecutionResult(
        val success: Boolean,
        val exitCode: Int,
        val output: String,
        val error: String,
        val chrootPath: String,
        val toolUsed: String,
        val durationMs: Long = 0
    )

    private val _kaliStreamFlow = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val kaliStreamFlow: SharedFlow<String> = _kaliStreamFlow.asSharedFlow()

    @Volatile
    private var detectedChrootPath: String? = null

    suspend fun detectKaliChroot(): String? = withContext(Dispatchers.IO) {
        if (detectedChrootPath != null) return@withContext detectedChrootPath

        // Check bootkali or nethunter script in system
        val bootkaliCheck = RootCommandEngine.execute("which bootkali || which nethunter")
        if (bootkaliCheck.success && bootkaliCheck.stdout.isNotBlank()) {
            val script = bootkaliCheck.stdout.lines().first().trim()
            Log.d(TAG, "Found Kali launcher: $script")
            detectedChrootPath = "bootkali"
            return@withContext "bootkali"
        }

        // Check known chroot directory paths
        for (path in POSSIBLE_CHROOT_PATHS) {
            val check = RootCommandEngine.execute("test -d $path && echo 'EXISTS'")
            if (check.stdout.contains("EXISTS")) {
                Log.d(TAG, "Detected Kali chroot at: $path")
                detectedChrootPath = path
                return@withContext path
            }
        }

        Log.w(TAG, "No Kali NetHunter chroot found on device.")
        null
    }

    suspend fun isKaliInstalled(): Boolean = withContext(Dispatchers.IO) {
        detectKaliChroot() != null
    }

    suspend fun getAvailableKaliTools(): List<String> = withContext(Dispatchers.IO) {
        val chroot = detectKaliChroot() ?: return@withContext emptyList()
        val available = mutableListOf<String>()

        for (tool in KNOWN_KALI_TOOLS) {
            val cmd = if (chroot == "bootkali") {
                "bootkali which $tool"
            } else {
                "chroot $chroot /bin/which $tool"
            }
            val res = RootCommandEngine.execute(cmd)
            if (res.success && res.stdout.contains(tool)) {
                available.add(tool)
            }
        }
        available
    }

    suspend fun isToolInstalled(tool: String): Boolean = withContext(Dispatchers.IO) {
        val chroot = detectKaliChroot() ?: return@withContext false
        val cmd = if (chroot == "bootkali") {
            "bootkali which $tool"
        } else {
            "chroot $chroot /bin/which $tool"
        }
        val res = RootCommandEngine.execute(cmd)
        res.success && res.stdout.contains(tool)
    }

    suspend fun execute(
        tool: String,
        arguments: String = "",
        onProgress: ((String) -> Unit)? = null,
        onOutputLine: ((String) -> Unit)? = null
    ): KaliExecutionResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val chroot = detectKaliChroot()

        if (chroot == null) {
            val msg = "Kali NetHunter is not installed or chroot directory not found."
            onProgress?.invoke(msg)
            _kaliStreamFlow.tryEmit("[KALI ERROR] $msg")
            return@withContext KaliExecutionResult(
                success = false,
                exitCode = -1,
                output = "",
                error = msg,
                chrootPath = "none",
                toolUsed = tool
            )
        }

        // Verify if specific tool is installed
        if (tool.isNotBlank() && tool != "bash" && tool != "sh") {
            val installed = isToolInstalled(tool)
            if (!installed) {
                val msg = "Security tool '$tool' is not installed in the Kali NetHunter chroot."
                onProgress?.invoke(msg)
                _kaliStreamFlow.tryEmit("[KALI ERROR] $msg")
                return@withContext KaliExecutionResult(
                    success = false,
                    exitCode = 127,
                    output = "",
                    error = msg,
                    chrootPath = chroot,
                    toolUsed = tool
                )
            }
        }

        if (!Regex("^[A-Za-z0-9._-]+$").matches(tool.trim())) {
            val msg = "'$tool' tool का सही नाम नहीं है।"
            return@withContext KaliExecutionResult(false, 2, "", msg, chroot, tool)
        }
        val fullCommand = if (arguments.isNotBlank()) "$tool $arguments" else tool
        Log.d(TAG, "Executing Kali command: $fullCommand (Chroot: $chroot)")
        onProgress?.invoke("Executing $tool in Kali NetHunter...")
        _kaliStreamFlow.tryEmit("[KALI] $ $fullCommand")

        // The same single root shell as everything else: it has the safety blocklist and a time limit. The old code opened its own
        // `su` (no blocklist, no timeout) and pasted the command inside single quotes, which a quote in the command could break.
        val shellCmd = if (chroot == "bootkali") {
            "bootkali $fullCommand"
        } else {
            "chroot ${ShellQuote.q(chroot)} /bin/bash -c ${ShellQuote.q(fullCommand)}"
        }

        var lineCount = 0
        val res = RootCommandEngine.executeLong(shellCmd, timeoutMs = 10 * 60_000L) { l ->
            _kaliStreamFlow.tryEmit("[KALI OUT] $l")
            onOutputLine?.invoke(l)
            lineCount++
            if (lineCount % 10 == 0) onProgress?.invoke("Running $tool ($lineCount lines captured)...")
        }
        val stdoutBuilder = StringBuilder(res.stdout)
        val stderrBuilder = StringBuilder(res.stderr)
        val exitCode = res.exitCode
        if (res.stderr.isNotBlank()) _kaliStreamFlow.tryEmit("[KALI ERR] ${res.stderr}")

        val duration = System.currentTimeMillis() - startTime
        val success = (exitCode == 0)
        onProgress?.invoke(if (success) "$tool execution completed." else "$tool exited with code $exitCode.")

        KaliExecutionResult(
            success = success,
            exitCode = exitCode,
            output = stdoutBuilder.toString().trim(),
            error = stderrBuilder.toString().trim(),
            chrootPath = chroot,
            toolUsed = tool,
            durationMs = duration
        )
    }
}

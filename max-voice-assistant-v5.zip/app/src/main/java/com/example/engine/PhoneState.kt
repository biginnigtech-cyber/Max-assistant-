package com.example.engine

import android.content.Context
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import java.util.Calendar

/**
 * What MAX can see about the phone right now, handed to Gemini with every request so it can understand what the user did not say:
 * battery low while asking for a long video, screen locked, music already playing, headphones connected, which app is in front...
 * One root call, cached for a few seconds so it adds almost nothing to the reply time.
 */
object PhoneState {

    private const val CACHE_MS = 6_000L
    @Volatile private var cached: String = ""
    @Volatile private var cachedAt = 0L

    /** Pure parser (unit-tested) of the combined `dumpsys` text produced by [snapshot]. */
    fun parse(raw: String): Map<String, String> {
        val parts = raw.split("---")
        val battery = parts.getOrElse(0) { "" }
        val focus = parts.getOrElse(1) { "" }
        val out = LinkedHashMap<String, String>()
        Regex("level:\\s*(\\d+)").find(battery)?.let { out["battery"] = it.groupValues[1] + "%" }
        val charging = Regex("(AC|USB|Wireless) powered:\\s*true").containsMatchIn(battery)
        out["charging"] = if (charging) "yes" else "no"
        Regex("mCurrentFocus=Window\\{[^ ]+ [^ ]+ ([^/ }]+)").find(focus)?.let { out["foreground_app"] = it.groupValues[1] }
        val windowDump = parts.getOrElse(2) { "" }
        val powerDump = parts.getOrElse(3) { "" }
        out["screen"] = if (ScreenUnlock.parseLocked(windowDump, powerDump)) "locked or off" else "unlocked"
        return out
    }

    suspend fun snapshot(context: Context): String {
        val now = SystemClock.elapsedRealtime()
        if (cached.isNotEmpty() && now - cachedAt < CACHE_MS) return cached
        val state = LinkedHashMap<String, String>()
        try {
            if (RootCommandEngine.isRootAvailable()) {
                val raw = RootCommandEngine.execute(
                    "dumpsys battery | grep -E '^ *(level|AC powered|USB powered|Wireless powered):'; echo ---; " +
                        "dumpsys window | grep -m1 mCurrentFocus; echo ---; " +
                        "dumpsys window | grep -iE 'isKeyguardShowing|mShowingLockscreen|mDreamingLockscreen|isStatusBarKeyguardShowing'; echo ---; " +
                        "dumpsys power | grep -m1 mWakefulness="
                ).stdout
                state.putAll(parse(raw))
            }
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (am != null) {
                state["music_playing"] = if (am.isMusicActive) "yes" else "no"
                state["ringer"] = when (am.ringerMode) { AudioManager.RINGER_MODE_SILENT -> "silent"; AudioManager.RINGER_MODE_VIBRATE -> "vibrate"; else -> "normal" }
            }
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
            state["network"] = when {
                caps == null -> "offline"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
                else -> "connected"
            }
        } catch (_: Exception) {}
        val cal = Calendar.getInstance()
        val line = "PHONE_STATE (live, from the phone itself): " + state.entries.joinToString("; ") { "${it.key}=${it.value}" } +
            "; weekday=${cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, java.util.Locale.ENGLISH)}"
        cached = line
        cachedAt = now
        return line
    }
}

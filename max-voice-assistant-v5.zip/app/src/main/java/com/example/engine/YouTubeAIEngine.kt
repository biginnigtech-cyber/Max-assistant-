package com.example.engine

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.example.service.MaxAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.net.URLEncoder

/**
 * YouTubeAIEngine (MAX AI OS)
 *
 * Plays a song / video the way a person would, and only reports success when it is real:
 *  1. open YouTube search for the query
 *  2. WAIT until the results are really on screen (no fixed sleeps)
 *  3. pick the first genuine video result, never an ad / sponsored card
 *  4. tap it and WAIT until the watch screen is open
 *  5. skip video ads ("Skip ads") when they appear
 *  6. verify that audio is really playing, and only then return success
 */
object YouTubeAIEngine {
    private const val TAG = "YouTubeAIEngine"
    private const val YT_PACKAGE = "com.google.android.youtube"

    enum class YouTubeState {
        IDLE,
        SEARCHING,
        PLAYING,
        COMPLETED,
        LISTENING_FOR_COMMAND
    }

    private val _state = MutableStateFlow(YouTubeState.IDLE)
    val state: StateFlow<YouTubeState> = _state.asStateFlow()

    private val sessionMutex = Mutex()
    private var currentPlayingQuery: String = ""

    fun getCurrentPlayingQuery(): String = currentPlayingQuery
    fun isPlaying(): Boolean = _state.value == YouTubeState.PLAYING

    data class YouTubeResult(
        val success: Boolean,
        val message: String,
        val state: YouTubeState
    )

    private suspend fun waitFor(timeoutMs: Long, stepMs: Long = 300L, condition: () -> Boolean): Boolean {
        val end = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < end) {
            val ok = try { condition() } catch (e: Exception) { false }
            if (ok) return true
            delay(stepMs)
        }
        return false
    }

    private fun fail(message: String): YouTubeResult {
        _state.value = YouTubeState.IDLE
        return YouTubeResult(false, message, YouTubeState.IDLE)
    }

    private fun launchSearch(context: Context, query: String) {
        try {
            val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage(YT_PACKAGE)
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(searchIntent)
        } catch (e: Exception) {
            Log.w(TAG, "Search action failed, using web search fallback: ${e.message}")
            val webUri = Uri.parse("https://www.youtube.com/results?search_query=${URLEncoder.encode(query, "UTF-8")}")
            val webIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                setPackage(YT_PACKAGE)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
        }
    }

    private fun nodeLabel(n: AccessibilityNodeInfo): String =
        (n.contentDescription?.toString().orEmpty() + " " + n.text?.toString().orEmpty()).trim()

    /** A normal video result card: its description mentions views / age / duration. */
    private fun looksLikeVideo(n: AccessibilityNodeInfo): Boolean {
        val l = nodeLabel(n).lowercase()
        val hasStats = l.contains("view") || l.contains("ago") || l.contains("watching") || l.contains("देखा") ||
            l.contains("व्यू") || l.contains("पहले") || l.contains("play video") || l.contains("minutes") || l.contains("मिनट")
        val isShort = l.contains("shorts") || l.contains("शॉर्ट्स")
        return hasStats && !isShort
    }

    private fun isWatchScreen(a11y: MaxAccessibilityService, root: AccessibilityNodeInfo): Boolean =
        a11y.anyNode(root) { n ->
            val id = n.viewIdResourceName?.lowercase().orEmpty()
            id.contains("watch_player") || id.contains("player_view") || id.contains("watch_while") ||
                id.contains("watch_panel") || id.contains("player_fragment")
        }

    private fun isSkipButton(n: AccessibilityNodeInfo): Boolean {
        val t = (n.text?.toString().orEmpty() + " " + n.contentDescription?.toString().orEmpty()).trim().lowercase()
        val id = n.viewIdResourceName?.lowercase().orEmpty()
        return id.contains("skip_ad") || id.contains("skip_button") ||
            t == "skip" || t == "skip ad" || t == "skip ads" || t.startsWith("skip ad") ||
            t.contains("विज्ञापन छोड़ें") || t.contains("विज्ञापन छोड़")
    }

    private fun isAdIndicator(n: AccessibilityNodeInfo): Boolean {
        val id = n.viewIdResourceName?.lowercase().orEmpty()
        if (id.contains("ad_progress") || id.contains("ad_badge") || id.contains("ad_countdown") || id.contains("skip_ad")) return true
        val t = (n.text?.toString().orEmpty() + " " + n.contentDescription?.toString().orEmpty()).trim().lowercase()
        return t.startsWith("ad ·") || t.startsWith("ad •") || t.startsWith("ad 1 of") || t.contains("विज्ञापन") ||
            t.contains("visit advertiser") || t.contains("sponsored")
    }

    suspend fun playVideo(
        context: Context,
        query: String,
        onProgress: (String) -> Unit = {}
    ): YouTubeResult = sessionMutex.withLock {
        withContext(Dispatchers.IO) {
            val clean = query.trim()
            if (clean.isBlank()) return@withContext fail("कौन सा गाना चलाना है, नाम बताइए।")

            val audio = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            // Accessibility first (it repairs itself through root). If it still is not there, root alone does the whole job.
            val a11y = AccessibilityBootstrap.ensure(context)
            if (a11y == null) {
                if (RootCommandEngine.isRootAvailable()) return@withContext playVideoRoot(context, clean, audio, onProgress)
                return@withContext fail("गाना चुनने के लिए " + AccessibilityBootstrap.NOT_RUNNING_MESSAGE)
            }

            _state.value = YouTubeState.SEARCHING
            currentPlayingQuery = clean
            onProgress("YouTube पर '$clean' खोज रहा हूँ...")
            launchSearch(context, clean)

            // 1. Wait until real search results are on screen
            var candidates: List<AccessibilityNodeInfo> = emptyList()
            val haveResults = waitFor(10_000L) {
                val root = a11y.rootInActiveWindow
                if (root != null && root.packageName?.toString() == YT_PACKAGE) {
                    val items = a11y.collectContentItems(root).filter { !a11y.isAdNode(it) }
                    candidates = items.filter { looksLikeVideo(it) }.ifEmpty { items }
                    candidates.isNotEmpty()
                } else false
            }
            if (!haveResults) return@withContext fail("YouTube पर '$clean' के नतीजे नहीं दिखे। दोबारा कोशिश कीजिए।")

            // 2. Let the list settle, then choose the first genuine (non-ad) video
            delay(500L)
            val freshRoot = a11y.rootInActiveWindow
            val fresh = if (freshRoot != null && freshRoot.packageName?.toString() == YT_PACKAGE) {
                val items = a11y.collectContentItems(freshRoot).filter { !a11y.isAdNode(it) }
                items.filter { looksLikeVideo(it) }.ifEmpty { items }
            } else candidates
            val target = fresh.firstOrNull() ?: candidates.first()

            onProgress("पहला असली वीडियो चुन रहा हूँ (विज्ञापन छोड़कर)...")
            val clicked = a11y.clickNode(target) || a11y.gestureClickNode(target)
            if (!clicked) return@withContext fail("वीडियो पर टैप नहीं हो पाया।")

            // 3. Wait until the watch screen is open
            val opened = waitFor(8_000L) {
                val r = a11y.rootInActiveWindow
                r != null && r.packageName?.toString() == YT_PACKAGE && isWatchScreen(a11y, r)
            }

            // 4. Skip video ads while they are on screen
            var adStillOnScreen = false
            var quietPolls = 0
            val adDeadline = SystemClock.elapsedRealtime() + 14_000L
            while (SystemClock.elapsedRealtime() < adDeadline) {
                val r = a11y.rootInActiveWindow
                if (r != null && r.packageName?.toString() == YT_PACKAGE) {
                    val skip = a11y.findNodes(r) { isSkipButton(it) }.firstOrNull()
                    if (skip != null) {
                        onProgress("विज्ञापन छोड़ रहा हूँ...")
                        a11y.clickNode(skip) || a11y.gestureClickNode(skip)
                        quietPolls = 0
                        delay(900L)
                        continue
                    }
                    adStillOnScreen = a11y.anyNode(r) { isAdIndicator(it) }
                    if (adStillOnScreen) quietPolls = 0 else quietPolls++
                    if (quietPolls >= 3) break
                }
                delay(500L)
            }

            // 5. Verify that it is really playing
            val audible = waitFor(4_000L) { audio?.isMusicActive == true }
            if (!opened && !audible) return@withContext fail("वीडियो खुला ही नहीं, इसलिए गाना नहीं चल पाया।")

            _state.value = YouTubeState.PLAYING
            val msg = if (adStillOnScreen) {
                "$clean चल रहा है, लेकिन पहले एक विज्ञापन चल रहा है जिसे छोड़ा नहीं जा सकता।"
            } else {
                "$clean चला दिया है।"
            }
            Log.d(TAG, "YouTube playback verified (opened=$opened, audible=$audible, ad=$adStillOnScreen)")
            YouTubeResult(true, msg, _state.value)
        }
    }

    private fun labelLooksLikeVideo(l: String): Boolean {
        val hasStats = l.contains("view") || l.contains("ago") || l.contains("watching") || l.contains("देखा") ||
            l.contains("व्यू") || l.contains("पहले") || l.contains("play video") || l.contains("minutes") || l.contains("मिनट")
        return hasStats && !(l.contains("shorts") || l.contains("शॉर्ट्स"))
    }

    private fun labelLooksLikeAd(l: String): Boolean =
        l.contains("sponsored") || l.contains("विज्ञापन") || l.startsWith("ad ·") || l.startsWith("ad •") || l.contains("visit advertiser")

    private fun isWatchId(id: String): Boolean {
        val i = id.lowercase()
        return i.contains("watch_player") || i.contains("player_view") || i.contains("watch_while") ||
            i.contains("watch_panel") || i.contains("player_fragment")
    }

    private fun isSkipNode(n: RootUi.Node): Boolean {
        val t = n.label.lowercase()
        val id = n.id.lowercase()
        return id.contains("skip_ad") || id.contains("skip_button") || t == "skip" || t == "skip ad" || t == "skip ads" ||
            t.startsWith("skip ad") || t.contains("विज्ञापन छोड़")
    }

    /** The same song-playing job as above, done with root only: uiautomator dump to read, input tap to touch. */
    private suspend fun playVideoRoot(
        context: Context,
        clean: String,
        audio: AudioManager?,
        onProgress: (String) -> Unit
    ): YouTubeResult {
        _state.value = YouTubeState.SEARCHING
        currentPlayingQuery = clean
        onProgress("YouTube पर '$clean' खोज रहा हूँ...")
        launchSearch(context, clean)

        var target: RootUi.Node? = null
        val searchEnd = SystemClock.elapsedRealtime() + 14_000L
        while (SystemClock.elapsedRealtime() < searchEnd && target == null) {
            delay(900L)
            val nodes = RootUi.dump().filter { it.pkg == YT_PACKAGE }
            val cards = nodes.filter {
                it.height > 140 && it.width > 300 && !labelLooksLikeAd(it.label.lowercase()) && labelLooksLikeVideo(it.label.lowercase())
            }.sortedBy { it.top }
            target = cards.firstOrNull()
        }
        val chosen = target ?: return fail("YouTube पर '$clean' के नतीजे नहीं दिखे। दोबारा कोशिश कीजिए।")

        onProgress("पहला असली वीडियो चुन रहा हूँ (विज्ञापन छोड़कर)...")
        if (!RootUi.tap(chosen.cx, chosen.cy)) return fail("वीडियो पर टैप नहीं हो पाया।")

        var opened = false
        val openEnd = SystemClock.elapsedRealtime() + 9_000L
        while (SystemClock.elapsedRealtime() < openEnd && !opened) {
            delay(900L)
            opened = RootUi.dump().any { it.pkg == YT_PACKAGE && isWatchId(it.id) }
        }

        var adStillOnScreen = false
        var quietPolls = 0
        val adEnd = SystemClock.elapsedRealtime() + 14_000L
        while (SystemClock.elapsedRealtime() < adEnd) {
            val nodes = RootUi.dump().filter { it.pkg == YT_PACKAGE }
            if (nodes.isNotEmpty()) {
                val skip = nodes.firstOrNull { isSkipNode(it) }
                if (skip != null) {
                    onProgress("विज्ञापन छोड़ रहा हूँ...")
                    RootUi.tap(skip.cx, skip.cy)
                    quietPolls = 0
                    delay(900L)
                    continue
                }
                adStillOnScreen = nodes.any {
                    val id = it.id.lowercase()
                    id.contains("ad_progress") || id.contains("ad_badge") || id.contains("ad_countdown") || labelLooksLikeAd(it.label.lowercase())
                }
                if (adStillOnScreen) quietPolls = 0 else quietPolls++
                if (quietPolls >= 2) break
            }
            delay(400L)
        }

        val audible = waitFor(4_000L) { audio?.isMusicActive == true }
        if (!opened && !audible) return fail("वीडियो खुला ही नहीं, इसलिए गाना नहीं चल पाया।")
        _state.value = YouTubeState.PLAYING
        val msg = if (adStillOnScreen) "$clean चल रहा है, लेकिन पहले एक विज्ञापन चल रहा है जिसे छोड़ा नहीं जा सकता।" else "$clean चला दिया है।"
        return YouTubeResult(true, msg, _state.value)
    }

    /** Explicitly unlocks and resets playback state when the user issues stop / pause / new task. */
    fun resetState() {
        _state.value = YouTubeState.IDLE
        currentPlayingQuery = ""
        Log.d(TAG, "YouTube session reset to IDLE.")
    }

    suspend fun pausePlayback() {
        RootCommandEngine.execute("input keyevent 85 || cmd media_session dispatch play-pause")
        _state.value = YouTubeState.COMPLETED
    }
}

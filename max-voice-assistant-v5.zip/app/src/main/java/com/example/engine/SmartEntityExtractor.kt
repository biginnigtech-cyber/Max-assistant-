package com.example.engine

import android.util.Log

/**
 * Smart Entity Extractor for Natural Language Messaging Commands.
 *
 * Extracts target messaging application, clean contact/entity name,
 * and optional message content without hardcoding names.
 *
 * Handles commands such as:
 * - "WhatsApp खोलो और राहुल को मैसेज करो" -> contact = "राहुल", message = ""
 * - "अनिल को मैसेज कर दो" -> contact = "अनिल", message = ""
 * - "मैसेज राहुल को भेज दो" -> contact = "राहुल", message = ""
 * - "राहुल को मैसेज करो कि मैं शाम को आऊंगा" -> contact = "राहुल", message = "मैं शाम को आऊंगा"
 * - "राहुल को बोलो कि मैं बाद में कॉल करूंगा" -> contact = "राहुल", message = "मैं बाद में कॉल करूंगा"
 * - "पहले WhatsApp खोलो, फिर अनिल को मैसेज भेजना" -> contact = "अनिल", message = ""
 * - "राहुल के भाई को मैसेज करो" -> contact = "राहुल के भाई", message = ""
 * - "अनिल को भेजो कि कल मिलते हैं" -> contact = "अनिल", message = "कल मिलते हैं"
 * - "राहुल को WhatsApp पर मैसेज करो" -> contact = "राहुल", message = ""
 * - "send message to Rahul on whatsapp saying are you free" -> contact = "Rahul", message = "are you free"
 */
object SmartEntityExtractor {
    private const val TAG = "SmartEntityExtractor"

    data class ExtractedMessaging(
        val targetApp: String, // "whatsapp", "telegram", "messenger", "sms"
        val contact: String,
        val message: String,
        val isExplicitAction: Boolean
    )

    // Command words that must NEVER be treated as contact entity when used as instructions
    private val INSTRUCTION_WORDS = setOf(
        "करो", "कर दो", "करदे", "करदो", "खोलो", "खोल", "खोल दो", "भेजो", "भेज", "भेज दो", "भेजना",
        "मैसेज", "मेसेज", "संदेश", "message", "msg", "को", "पर", "में", "पे", "par", "me", "mein",
        "के लिए", "please", "ज़रा", "जरा", "अब", "फिर", "और", "मुझे", "तुम", "आप", "देना", "दे दो",
        "बोलो", "बोल", "बोल दो", "कह दो", "कहदो", "कहना", "लिखो", "लिख", "लिख दो", "whatsapp",
        "व्हाट्सएप", "व्हाट्सऐप", "वाट्सएप", "sms", "एसएमएस", "telegram", "टेलीग्राम", "messenger",
        "मैसेंजर", "open", "send", "tell", "say", "text"
    )

    fun extract(rawInput: String): ExtractedMessaging? {
        val clean = cleanWakeWords(rawInput)
        if (clean.isBlank()) return null
        val lower = clean.lowercase()

        // 1. Identify Target App
        val targetApp = when {
            lower.contains("telegram") || lower.contains("टेलीग्राम") -> "telegram"
            lower.contains("sms") || lower.contains("text message") || lower.contains("एसएमएस") -> "sms"
            lower.contains("messenger") || lower.contains("मैसेंजर") -> "messenger"
            lower.contains("whatsapp") || lower.contains("व्हाट्सएप") || lower.contains("व्हाट्सऐप") || lower.contains("वाट्सएप") -> "whatsapp"
            else -> {
                // If message verbs or keywords are present, default to whatsapp
                if (hasMessagingKeywords(clean)) {
                    "whatsapp"
                } else {
                    return null
                }
            }
        }

        // 2. Multi-strategy Extraction
        // Strategy A: "मैसेज <contact> को भेज दो / भेजो / कर दो"
        val strategyA = extractMessageFirst(clean)
        if (strategyA != null) {
            val validContact = sanitizeContact(strategyA.first)
            if (isValidContact(validContact)) {
                return ExtractedMessaging(
                    targetApp = targetApp,
                    contact = validContact,
                    message = strategyA.second.trim(),
                    isExplicitAction = true
                )
            }
        }

        // Strategy B: App opening clause followed by contact action:
        // "WhatsApp खोलो और राहुल को मैसेज करो", "पहले WhatsApp खोलो, फिर अनिल को मैसेज भेजना"
        val strategyB = extractAfterAppClause(clean)
        if (strategyB != null) {
            val parsed = extractContactAndMessage(strategyB)
            if (parsed != null && isValidContact(parsed.first)) {
                return ExtractedMessaging(
                    targetApp = targetApp,
                    contact = sanitizeContact(parsed.first),
                    message = parsed.second.trim(),
                    isExplicitAction = true
                )
            }
        }

        // Strategy C: Contact + "को" + WhatsApp पर + Verb:
        // "राहुल को WhatsApp पर मैसेज करो"
        val strategyC = extractContactAppVerb(clean)
        if (strategyC != null && isValidContact(strategyC.first)) {
            return ExtractedMessaging(
                targetApp = targetApp,
                contact = sanitizeContact(strategyC.first),
                message = strategyC.second.trim(),
                isExplicitAction = true
            )
        }

        // Strategy D: Standard Hindi/English Contact + Verb (+ Message):
        // "अनिल को मैसेज कर दो", "राहुल को बोलो कि मैं बाद में कॉल करूंगा", "राहुल के भाई को मैसेज करो"
        val strategyD = extractContactAndMessage(clean)
        if (strategyD != null && isValidContact(strategyD.first)) {
            return ExtractedMessaging(
                targetApp = targetApp,
                contact = sanitizeContact(strategyD.first),
                message = strategyD.second.trim(),
                isExplicitAction = true
            )
        }

        // Strategy E: English patterns:
        // "open whatsapp and tell Anil I won't come to school tomorrow", "send message to Rahul"
        val strategyE = extractEnglishMessaging(clean)
        if (strategyE != null && isValidContact(strategyE.first)) {
            return ExtractedMessaging(
                targetApp = targetApp,
                contact = sanitizeContact(strategyE.first),
                message = strategyE.second.trim(),
                isExplicitAction = true
            )
        }

        return null
    }

    private fun hasMessagingKeywords(input: String): Boolean {
        val lower = input.lowercase()
        return lower.contains("मैसेज") || lower.contains("संदेश") || lower.contains("message") ||
                lower.contains("बोलो") || lower.contains("कह दो") || lower.contains("कहना") ||
                lower.contains("भेजो") || lower.contains("भेज दो") || lower.contains("भेजना") ||
                lower.contains("लिखो") || lower.contains("send message") || lower.contains("tell")
    }

    private fun cleanWakeWords(raw: String): String {
        var text = raw.trim()
        val wakeWords = listOf(
            Regex("^(?:hey\\s+)?max[,\\s]*", RegexOption.IGNORE_CASE),
            Regex("^(?:अरे\\s+)?मैक्स[,\\s]*", RegexOption.IGNORE_CASE),
            Regex("^(?:please\\s+)?(?:can\\s+you\\s+)?", RegexOption.IGNORE_CASE),
            Regex("^(?:कृपया\\s+)?(?:ज़रा\\s+|जरा\\s+)?", RegexOption.IGNORE_CASE)
        )
        for (w in wakeWords) {
            text = text.replace(w, "").trim()
        }
        return text
    }

    /**
     * Pattern: "मैसेज <contact> को भेज दो / भेजो / कर दो"
     */
    private fun extractMessageFirst(text: String): Pair<String, String>? {
        val regex = Regex(
            "^(?:कृपया\\s+|ज़रा\\s+)?(?:मैसेज|संदेश|message)\\s+(.+?)\\s*(?:को|से)\\s*(?:भेज\\s*दो|भेजो|भेजना|कर\\s*दो|करो)(?:\\s*(?:कि|saying|that)\\s*(.+))?$",
            RegexOption.IGNORE_CASE
        )
        val m = regex.find(text) ?: return null
        val contact = m.groupValues[1]
        val msg = m.groupValues.getOrNull(2) ?: ""
        return Pair(contact, msg)
    }

    /**
     * Pattern: "(पहले WhatsApp खोलो, फिर / WhatsApp खोलो और) <rest>"
     */
    private fun extractAfterAppClause(text: String): String? {
        val regex = Regex(
            "^(?:पहले\\s+)?(?:whatsapp|व्हाट्सएप|व्हाट्सऐप|वाट्सएप|telegram|टेलीग्राम|sms|एसएमएस|messenger|मैसेंजर)\\s*(?:खोलो|खोल\\s*दो|ओपन\\s*करो|chalao)?(?:[,，]?\\s*(?:और|फिर|and|then)\\s*)(.+)$",
            RegexOption.IGNORE_CASE
        )
        val m = regex.find(text) ?: return null
        return m.groupValues[1].trim()
    }

    /**
     * Pattern: "<contact> को WhatsApp पर मैसेज करो"
     */
    private fun extractContactAppVerb(text: String): Pair<String, String>? {
        val regex = Regex(
            "^(.+?)\\s*(?:को|से)\\s*(?:whatsapp|व्हाट्सएप|व्हाट्सऐप|telegram|sms|messenger)\\s*(?:पर|में|pe|par)\\s*(?:मैसेज\\s*करो|मैसेज\\s*कर\\s*दो|मैसेज\\s*भेजो|मैसेज\\s*भेजना|मैसेज\\s*भेज\\s*दो|लिखो|बोलो)(?:\\s*(?:कि|saying)\\s*(.+))?$",
            RegexOption.IGNORE_CASE
        )
        val m = regex.find(text) ?: return null
        val contact = m.groupValues[1]
        val msg = m.groupValues.getOrNull(2) ?: ""
        return Pair(contact, msg)
    }

    /**
     * Pattern: "<contact> को बोलो / मैसेज करो / लिखो / भेजो [कि <message>]"
     */
    private fun extractContactAndMessage(text: String): Pair<String, String>? {
        val trimmed = text.replace(
            Regex("^(?:whatsapp|व्हाट्सएप|व्हाट्सऐप|वाट्सएप|telegram|sms)\\s*(?:पर|में|pe|par)\\s*", RegexOption.IGNORE_CASE),
            ""
        ).trim()

        // 1. Check with explicit "कि" or "saying" separator
        val sepRegex = Regex(
            "^(.+?)\\s*(?:को|से)\\s*(?:बोलो|कह\\s*दो|कहना|लिखो|मैसेज\\s*करो|मैसेज\\s*कर\\s*दो|मैसेज\\s*भेजो|मैसेज\\s*भेज\\s*दो|मैसेज\\s*भेजना|भेजो|भेज\\s*दो|भेजना)\\s*(?:कि|saying|that|:)\\s*(.+)$",
            RegexOption.IGNORE_CASE
        )
        val sepMatch = sepRegex.find(trimmed)
        if (sepMatch != null) {
            return Pair(sepMatch.groupValues[1], sepMatch.groupValues[2])
        }

        // 2. Check without message separator (message may follow verb or be empty)
        val verbRegex = Regex(
            "^(.+?)\\s*(?:को|से)\\s*(?:बोलो|कह\\s*दो|कहना|लिखो|मैसेज\\s*करो|मैसेज\\s*कर\\s*दो|मैसेज\\s*भेजो|मैसेज\\s*भेज\\s*दो|मैसेज\\s*भेजना|भेजो|भेज\\s*दो|भेजना)(?:\\s+(.+))?$",
            RegexOption.IGNORE_CASE
        )
        val verbMatch = verbRegex.find(trimmed)
        if (verbMatch != null) {
            val contact = verbMatch.groupValues[1]
            val msg = verbMatch.groupValues.getOrNull(2) ?: ""
            return Pair(contact, msg)
        }

        return null
    }

    /**
     * Pattern (English):
     * "open whatsapp and tell Anil I won't come to school tomorrow"
     * "send message to Rahul on whatsapp saying are you free"
     * "tell Rahul to call me"
     */
    private fun extractEnglishMessaging(text: String): Pair<String, String>? {
        val p1 = Regex(
            "^(?:open\\s+\\w+\\s+(?:and\\s+)?)?(?:send\\s+(?:a\\s+)?message\\s+to\\s+|tell\\s+|message\\s+)([a-zA-Z0-9_]+)\\s+(?:on\\s+\\w+\\s+)?(?:that\\s+|saying\\s+|to\\s+|:\\s*)?(.+)$",
            RegexOption.IGNORE_CASE
        )
        val m1 = p1.find(text)
        if (m1 != null) {
            val contact = m1.groupValues[1].trim()
            val msg = m1.groupValues[2].trim()
            if (msg.isNotEmpty()) {
                return Pair(contact, msg)
            }
        }

        val p2 = Regex(
            "^(?:open\\s+\\w+\\s+(?:and\\s+)?)?(?:send\\s+(?:a\\s+)?message\\s+to\\s+|message\\s+)([a-zA-Z0-9_\\s]+?)(?:\\s+on\\s+\\w+)?$",
            RegexOption.IGNORE_CASE
        )
        val m2 = p2.find(text)
        if (m2 != null) {
            return Pair(m2.groupValues[1].trim(), "")
        }

        return null
    }

    /**
     * Sanitizes extracted contact name to remove stray noise words.
     * Preserves relational composite names like "राहुल के भाई", "रोहित के दोस्त", "Dr. Sharma".
     */
    fun sanitizeContact(raw: String): String {
        var clean = raw.trim()
            .replace(Regex("^['\"]+|['\"]+$"), "")
            .trim()

        // Strip leading instruction noise if accidentally captured
        clean = clean.replace(Regex("^(?:पहले|और|फिर|ज़रा|जरा|please)\\s+", RegexOption.IGNORE_CASE), "").trim()
        clean = clean.replace(Regex("^(?:whatsapp|व्हाट्सएप|व्हाट्सऐप|वाट्सएप)\\s*(?:खोलो|पर|में)?\\s*(?:और|फिर)?\\s*", RegexOption.IGNORE_CASE), "").trim()

        // Strip trailing command particles if stuck
        clean = clean.replace(Regex("\\s*(?:को|से|पर|में|pe|par)$", RegexOption.IGNORE_CASE), "").trim()

        // Strip any trailing command verbs that might have leaked into contact
        clean = clean.replace(Regex("\\s*(?:मैसेज\\s*करो|मैसेज|भेजो|भेज\\s*दो|करो|कर\\s*दो|खोलो)$", RegexOption.IGNORE_CASE), "").trim()

        return clean
    }

    /**
     * Verifies that the candidate contact is not empty and is not a command/instruction word.
     */
    private val COMMAND_NOISE_REGEXES = listOf(
        Regex("(?i)(whatsapp|व्हाट्सएप|व्हाट्सऐप|वाट्सएप|telegram|टेलीग्राम).*(खोलो|खोल\\s*दो|open|जाओ|भेजो|मैसेज|message)"),
        Regex("(?i)(मैसेज|मेसेज|message)\\s*(करो|कर\\s*दो|भेजो|भेज\\s*दो|karo|kar\\s*do|bhejo|send)"),
        Regex("(?i)^\\s*(max|मैक्स|मैक्सी)(?![\\p{L}\\p{M}])")
    )

    /**
     * True when text that should be a chat message is really a leaked voice command
     * (for example the user's whole sentence). Such text must never be typed into a chat.
     */
    fun looksLikeCommandNoise(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        return COMMAND_NOISE_REGEXES.any { it.containsMatchIn(t) }
    }

    // "tell me a joke" / "message me later" must never become a WhatsApp chat with a contact called "me a joke".
    private val NOT_A_NAME = setOf(
        "me", "my", "myself", "you", "your", "him", "her", "them", "us", "we", "everyone", "everybody", "someone", "something",
        "anything", "about", "a", "an", "the", "this", "that", "it", "what", "how", "why", "when", "where", "who",
        "मुझे", "मेरे", "मेरा", "तुम", "आप", "सबको", "सब", "कोई", "कुछ", "क्या", "कैसे", "क्यों", "कब", "कहाँ", "कौन"
    )

    fun isValidContact(contact: String): Boolean {
        val trimmed = contact.trim()
        if (trimmed.isBlank() || trimmed.length < 2) return false
        val lower = trimmed.lowercase()
        val words = lower.split(Regex("\\s+")).filter { it.isNotBlank() }
        // A person's name is one to four words and does not start with a pronoun or a question word.
        if (words.size > 4 || words.first() in NOT_A_NAME) return false

        // Reject if it is solely a command word
        if (INSTRUCTION_WORDS.contains(lower) || INSTRUCTION_WORDS.contains(trimmed)) {
            return false
        }

        // Reject if it contains command instructions (e.g. "खोलो और राहुल को मैसेज करो")
        if (lower.contains("खोलो और") || lower.contains("मैसेज करो") || lower.contains("मैसेज भेज")) {
            return false
        }

        return true
    }
}

package com.example.engine

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.example.brain.PersonalityEngine
import com.example.service.MaxAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.URLEncoder

/**
 * AppAutomationEngine (MAX AI OS)
 *
 * Provides real app navigation, content searching, and verified action execution across:
 * WhatsApp, Instagram, Messenger, Telegram, Spotify, Chrome, Camera, Phone, Settings, etc.
 *
 * Truthful Execution Verification Rules:
 * - Direct System App Launching with PackageManager and Root fallbacks.
 * - WhatsApp Full Automation:
 *    Open WhatsApp -> Search Contact Name -> Open Chat -> Type Message -> Click Send Button.
 * - Verified Send Button Confirmation:
 *    Checks node hierarchy before and after clicking; Max ONLY reports "Message sent"
 *    if the action physically succeeded on device. If it fails, reports the truthful failure cause.
 * - Integrates AudioPlaybackEngine for verified Spotify and local media playback.
 */
object AppAutomationEngine {
    private const val TAG = "AppAutomationEngine"

    data class AutomationResult(
        val success: Boolean,
        val spokenResponse: String,
        val details: List<String> = emptyList()
    )

    // Supported target apps & packages
    val SUPPORTED_APPS = mapOf(
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "messenger" to "com.facebook.orca",
        "telegram" to "org.telegram.messenger",
        "facebook" to "com.facebook.katana",
        "tiktok" to "com.zhiliaoapp.musically",
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "spotify" to "com.spotify.music",
        "gallery" to "com.google.android.apps.photos",
        "camera" to "com.google.android.GoogleCamera",
        "phone" to "com.google.android.dialer",
        "settings" to "com.android.settings"
    )

    /**
     * Executes messaging automation across WhatsApp, Telegram, Messenger, and Instagram.
     * Full Automation Workflow:
     * 1. Open app
     * 2. Search contact name
     * 3. Open chat
     * 4. Type message
     * 5. Locate and click Send button
     * 6. Verify send event occurred
     * 7. Return TRUTHFUL result
     */
    suspend fun automateMessaging(
        context: Context,
        targetApp: String,
        contactName: String,
        messageText: String,
        phoneNumber: String? = null,
        onProgress: (String) -> Unit = {}
    ): AutomationResult {
        if (SmartEntityExtractor.sanitizeContact(contactName).isBlank()) {
            return AutomationResult(
                success = false,
                spokenResponse = "किसे मैसेज भेजना है, नाम बताइए।",
                details = listOf("Messaging aborted: no contact extracted")
            )
        }
        // Never type a leaked voice command into a chat: treat it as "no message given"
        val safeMessage = if (SmartEntityExtractor.looksLikeCommandNoise(messageText)) "" else messageText.trim()
        return automateMessagingInternal(context, targetApp, contactName, safeMessage, phoneNumber, onProgress)
    }

    private suspend fun automateMessagingInternal(
        context: Context,
        targetApp: String,
        contactName: String,
        messageText: String,
        phoneNumber: String? = null,
        onProgress: (String) -> Unit = {}
    ): AutomationResult = withContext(Dispatchers.IO) {
        val app = targetApp.lowercase().trim()
        val pkg = if (app == "facebook") "com.facebook.orca" else (SUPPORTED_APPS[app] ?: "com.whatsapp")
        val appLabel = when (app) {
            "whatsapp" -> "WhatsApp"
            "telegram" -> "Telegram"
            "messenger", "facebook" -> "Messenger"
            "instagram" -> "Instagram"
            else -> targetApp
        }
        val logs = mutableListOf<String>()
        val cleanContact = SmartEntityExtractor.sanitizeContact(contactName)

        onProgress("Opening $targetApp for $cleanContact...")
        logs.add("Initiating automation for $targetApp -> Contact: $cleanContact")

        // 1. WhatsApp Fast-Path via Intent API if verified phone number is available
        val cleanPhone = phoneNumber?.replace(Regex("[^0-9+]"), "") ?: ""
        if (app.contains("whatsapp") && cleanPhone.isNotBlank() && cleanPhone.length >= 7) {
            try {
                val encodedMsg = if (messageText.isNotBlank()) URLEncoder.encode(messageText, "UTF-8") else ""
                val uri = if (encodedMsg.isNotBlank()) {
                    Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMsg")
                } else {
                    Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone")
                }
                val waIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage(pkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                }
                context.startActivity(waIntent)
                logs.add("Launched WhatsApp direct chat intent to $cleanPhone")
                AccessibilityBootstrap.ensure(context)

                waitFor(6000L) {
                    val svc = MaxAccessibilityService.instance
                    val r = svc?.rootInActiveWindow
                    svc != null && r != null && svc.findInputField(r) != null
                }
                delay(400L)
                waitFor(2500L) {
                    val svc = MaxAccessibilityService.instance
                    val r = svc?.rootInActiveWindow
                    svc != null && r != null && svc.findSendButton(r) != null
                }

                // If user did not provide a message (e.g. "WhatsApp खोलो और राहुल को मैसेज करो")
                if (messageText.isBlank()) {
                    onProgress("Chat opened for $cleanContact.")
                    return@withContext AutomationResult(
                        success = true,
                        spokenResponse = "हाँ, $cleanContact की चैट खुल गई है। अब बोलो क्या मैसेज भेजना है?",
                        details = logs
                    )
                }

                // Verify Send button exists & click via AccessibilityNodeInfo or root keyevent
                val sent = verifyAndClickSendButton(logs)
                if (sent) {
                    onProgress("Message dispatched successfully.")
                    return@withContext AutomationResult(
                        success = true,
                        spokenResponse = sentSpoken(cleanContact, messageText),
                        details = logs
                    )
                }
            } catch (e: Exception) {
                Log.w(TAG, "Fast-path failed: ${e.message}, falling back to full UI automation.")
                logs.add("Fast-path fallback: ${e.message}")
            }
        }

        // 2. Real on-screen workflow: look at the chat list, search only if needed, verify every step
        runChatUiFlow(context, pkg, appLabel, cleanContact, messageText, logs, onProgress)
    }

    private suspend fun waitFor(timeoutMs: Long, stepMs: Long = 250L, condition: () -> Boolean): Boolean {
        val end = android.os.SystemClock.elapsedRealtime() + timeoutMs
        while (android.os.SystemClock.elapsedRealtime() < end) {
            val ok = try { condition() } catch (e: Exception) { false }
            if (ok) return true
            delay(stepMs)
        }
        return false
    }

    private fun sentSpoken(contact: String, message: String): String {
        val m = message.trim()
        return if (m.isNotEmpty() && m.length <= 60) "$contact को मैसेज भेज दिया है, कि $m" else "$contact को मैसेज भेज दिया है।"
    }

    private fun isSearchInput(node: AccessibilityNodeInfo): Boolean =
        node.viewIdResourceName?.lowercase()?.contains("search") == true

    /**
     * Chat flow used for WhatsApp, Messenger, Telegram, Instagram:
     * open app -> make sure we are on the chat list -> look for the contact in the list ->
     * if not visible use search -> ask when several people match -> open chat -> type -> send -> verify.
     */
    private suspend fun runChatUiFlow(
        context: Context,
        pkg: String,
        appLabel: String,
        contact: String,
        message: String,
        logs: MutableList<String>,
        onProgress: (String) -> Unit
    ): AutomationResult {
        val a11y = AccessibilityBootstrap.ensure(context)
        if (a11y == null) {
            // No accessibility even after the repair: let the screen agent do the whole job through root.
            val key = com.example.utils.PreferencesManager.getApiKey(context)
            if (key.isNotBlank() && RootCommandEngine.isRootAvailable()) {
                val goal = if (message.isBlank()) "Open the chat with '$contact' in $appLabel and stop there."
                    else "In $appLabel open the chat with '$contact', type the message '$message' and press send."
                val agent = ScreenAgent.run(context, com.example.ai.GeminiBrain(), key, com.example.utils.PreferencesManager.getSelectedModel(context), goal, onProgress)
                logs.addAll(agent.steps)
                return AutomationResult(agent.success, agent.spoken, logs)
            }
            return AutomationResult(false, "$appLabel में काम करने के लिए " + AccessibilityBootstrap.NOT_RUNNING_MESSAGE, logs)
        }

        val launch = DeviceController.openApp(context, pkg)
        logs.add("Launch result: ${launch.message}")
        if (!launch.success) {
            return AutomationResult(false, "माफ़ कीजिए, $appLabel नहीं खुल पाया।", logs)
        }
        waitFor(7000L) { a11y.rootInActiveWindow?.packageName?.toString() == pkg }
        delay(700L)

        // Make sure we are on the chat list and not inside an old chat
        repeat(3) {
            val r = a11y.rootInActiveWindow
            val input = r?.let { a11y.findInputField(it) }
            if (input != null && !isSearchInput(input)) {
                a11y.pressBack()
                delay(500L)
            }
        }

        onProgress("$appLabel में '$contact' ढूँढ रहा हूँ...")

        // Step A: is the contact already visible in the chat list?
        var matches = a11y.rootInActiveWindow?.let { a11y.findConversationMatches(it, contact) } ?: emptyList()
        logs.add("Visible chat list matches for '$contact': ${matches.map { it.first }}")

        // Step B: not visible -> use the search box with ONLY the contact name
        if (matches.isEmpty()) {
            val root = a11y.rootInActiveWindow
            val affordance = root?.let { a11y.findSearchAffordance(it) }
            if (affordance != null) {
                a11y.clickNode(affordance) || a11y.gestureClickNode(affordance)
                delay(600L)
            }
            var searchInput: AccessibilityNodeInfo? = null
            waitFor(3000L) {
                val r = a11y.rootInActiveWindow
                searchInput = r?.let { a11y.findInputField(it) }
                searchInput != null
            }
            val box = searchInput
                ?: return AutomationResult(false, "$appLabel में सर्च बॉक्स नहीं मिला।", logs)
            a11y.setTextOnNode(box, contact)
            logs.add("Typed only the contact name into search: $contact")
            waitFor(4000L) {
                val r = a11y.rootInActiveWindow
                r != null && a11y.findConversationMatches(r, contact).isNotEmpty()
            }
            delay(400L)
            matches = a11y.rootInActiveWindow?.let { a11y.findConversationMatches(it, contact) } ?: emptyList()
            logs.add("Search results for '$contact': ${matches.map { it.first }}")
        }

        if (matches.isEmpty()) {
            return AutomationResult(false, "$appLabel में '$contact' नाम का कोई चैट या कॉन्टैक्ट नहीं मिला।", logs)
        }
        if (matches.size > 1) {
            val names = matches.take(3).joinToString(", ") { it.first }
            return AutomationResult(false, "$contact नाम के कई लोग मिले: $names। किसे भेजूँ? पूरा नाम बताइए।", logs)
        }

        val (label, row) = matches.first()
        val opened = a11y.clickNode(row) || a11y.gestureClickNode(row)
        if (!opened) {
            return AutomationResult(false, "$label की चैट पर टैप नहीं हो पाया।", logs)
        }
        val chatReady = waitFor(5000L) {
            val r = a11y.rootInActiveWindow
            val input = r?.let { a11y.findInputField(it) }
            input != null && !isSearchInput(input)
        }
        if (!chatReady) {
            return AutomationResult(false, "$label की चैट खुल नहीं पाई।", logs)
        }
        logs.add("Opened chat: $label")

        if (message.isBlank()) {
            return AutomationResult(true, "$label की चैट खुल गई है। क्या मैसेज भेजना है?", logs)
        }

        onProgress("मैसेज लिख रहा हूँ...")
        val input = a11y.rootInActiveWindow?.let { a11y.findInputField(it) }
        val typed = input != null && a11y.setTextOnNode(input, message)
        logs.add("Typed message via Accessibility: $typed")
        if (!typed) {
            return AutomationResult(false, "$label की चैट खुल गई, लेकिन मैसेज लिख नहीं पाया।", logs)
        }

        waitFor(3000L) { a11y.rootInActiveWindow?.let { a11y.findSendButton(it) } != null }
        val sent = verifyAndClickSendButton(logs)
        if (!sent) {
            return AutomationResult(false, "मैसेज लिख दिया है, लेकिन भेजने का बटन नहीं मिला।", logs)
        }

        // Verify: the typing box must no longer contain the message
        val cleared = waitFor(4000L) {
            val r = a11y.rootInActiveWindow
            val i = r?.let { a11y.findInputField(it) }
            i == null || i.text?.toString() != message
        }
        logs.add("Send verified (input cleared): $cleared")
        return if (cleared) {
            AutomationResult(true, sentSpoken(label, message), logs)
        } else {
            AutomationResult(false, "मैसेज भेजने की पुष्टि नहीं हो सकी, कृपया चैट देख लीजिए।", logs)
        }
    }

    /**
     * Verifies the presence of the Send button via AccessibilityNodeInfo and performs click.
     */
    private suspend fun verifyAndClickSendButton(logs: MutableList<String>): Boolean {
        val a11y = MaxAccessibilityService.instance
        if (a11y != null) {
            val root = a11y.rootInActiveWindow
            if (root != null) {
                val sendNode = a11y.findSendButton(root)
                if (sendNode != null) {
                    logs.add("Located Send button node in hierarchy: ${sendNode.viewIdResourceName}")
                    val clicked = a11y.clickNode(sendNode) || a11y.gestureClickNode(sendNode)
                    if (clicked) {
                        logs.add("Successfully clicked Send button via Accessibility.")
                        return true
                    }
                }
            }
        }

        // Root: find the real send button on screen and tap it. (The old fallback pressed Enter, which only adds a new line in
        // WhatsApp and still reported "sent".)
        val nodes = RootUi.dump()
        val send = nodes.firstOrNull { n ->
            val l = n.label.lowercase()
            val id = n.id.lowercase()
            (id.endsWith("/send") || id.contains("send_btn") || id.contains("send_button") || l == "send" ||
                (l.startsWith("send") && !l.contains("audio")) || l.contains("भेजें")) && !l.contains("voice")
        }
        if (send != null && RootUi.tap(send.cx, send.cy)) {
            logs.add("Tapped the Send button through root at (${send.cx}, ${send.cy}).")
            return true
        }
        logs.add("Send button not found on screen: nothing was sent.")
        return false
    }

    /**
     * Launches and automates non-messaging applications (Spotify, Chrome, Camera, Phone, Settings, etc.)
     */
    suspend fun automateGenericApp(
        context: Context,
        appName: String,
        action: String,
        query: String = ""
    ): AutomationResult = withContext(Dispatchers.IO) {
        val app = appName.lowercase().trim()
        val pkg = SUPPORTED_APPS[app] ?: app

        when {
            // Spotify & Music Playback
            app.contains("spotify") || action.contains("music") || action.contains("play") -> {
                val playbackRes = AudioPlaybackEngine.playTrack(context, query, "spotify")
                return@withContext AutomationResult(
                    success = playbackRes.success,
                    spokenResponse = playbackRes.message,
                    details = listOf(playbackRes.message)
                )
            }

            // Chrome / Web Browser
            app.contains("chrome") || app.contains("browser") -> {
                val url = if (query.startsWith("http")) query else "https://www.google.com/search?q=${URLEncoder.encode(query, "UTF-8")}"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    setPackage("com.android.chrome")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return@withContext try {
                    context.startActivity(intent)
                    AutomationResult(true, "Searching for $query on Chrome.")
                } catch (e: Exception) {
                    AutomationResult(false, "Could not open Chrome: ${e.message}")
                }
            }

            // Camera
            app.contains("camera") -> {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return@withContext try {
                    context.startActivity(intent)
                    AutomationResult(true, "Camera is open.")
                } catch (e: Exception) {
                    val res = DeviceController.openApp(context, "camera")
                    AutomationResult(res.success, if (res.success) "Camera is open." else res.message)
                }
            }

            // Gallery / Photos
            app.contains("gallery") || app.contains("photo") -> {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    type = "image/*"
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return@withContext try {
                    context.startActivity(intent)
                    AutomationResult(true, "Opening your gallery.")
                } catch (e: Exception) {
                    val res = DeviceController.openApp(context, "gallery")
                    AutomationResult(res.success, if (res.success) "Gallery is opened." else res.message)
                }
            }

            // Phone Dialer
            app.contains("phone") || app.contains("dialer") -> {
                val intent = if (query.isNotBlank()) {
                    Intent(Intent.ACTION_DIAL, Uri.parse("tel:$query"))
                } else {
                    Intent(Intent.ACTION_DIAL)
                }.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return@withContext try {
                    context.startActivity(intent)
                    AutomationResult(true, if (query.isNotBlank()) "Dialer opened for $query." else "Dialer opened.")
                } catch (e: Exception) {
                    AutomationResult(false, "Dialer could not be opened: ${e.message}")
                }
            }

            // Settings
            app.contains("settings") -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return@withContext try {
                    context.startActivity(intent)
                    AutomationResult(true, "Device settings opened.")
                } catch (e: Exception) {
                    AutomationResult(false, "Settings could not be opened: ${e.message}")
                }
            }

            // Direct App Launching via PackageManager
            else -> {
                val res = DeviceController.openApp(context, pkg)
                val msg = if (res.success) "Opened $appName." else res.message
                return@withContext AutomationResult(res.success, msg, listOf(res.message))
            }
        }
    }
}

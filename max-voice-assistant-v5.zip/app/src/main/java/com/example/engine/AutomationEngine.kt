package com.example.engine

import android.content.Context
import android.util.Log
import com.example.brain.ContextEngine
import com.example.brain.MemoryManager
import com.example.brain.NotificationBrain
import com.example.brain.PersonalityEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * AutomationEngine (MAX AI OS)
 *
 * Implements automated behavioral modes and routines:
 * - Good Morning Mode (WiFi ON, weather, messages, Spotify)
 * - Night Mode (Brightness low, battery saver, DND)
 * - Gaming Mode (Game DND, only calls/family/OTP allowed)
 * - Work Mode (Work notifications priority, moderate volume)
 * - Driving Mode (Bluetooth ON, maximum volume, hands-free speech)
 */
object AutomationEngine {
    private const val TAG = "AutomationEngine"

    data class RoutineResult(
        val success: Boolean,
        val mode: ContextEngine.OperatingMode,
        val spokenResponse: String,
        val actionsExecuted: List<String>
    )

    suspend fun executeRoutine(
        context: Context,
        mode: ContextEngine.OperatingMode,
        onProgress: (String) -> Unit = {}
    ): RoutineResult = withContext(Dispatchers.IO) {
        val actions = mutableListOf<String>()
        val contextEngine = ContextEngine.getInstance(context)
        contextEngine.setOperatingMode(mode)

        when (mode) {
            ContextEngine.OperatingMode.GOOD_MORNING -> {
                onProgress("Initiating Good Morning protocol...")
                // 1. Enable WiFi
                DeviceController.toggleWiFi(true)
                actions.add("Enabled WiFi")
                delay(600L)

                // 2. Set Volume
                DeviceController.setVolume(context, "set", 60)
                actions.add("Adjusted volume to 60%")

                // 3. Greeting & Weather check
                val greeting = PersonalityEngine.formatGreeting()
                actions.add("Prepared morning briefing")

                // 4. Summarize unread messages
                val notifBrain = NotificationBrain.getInstance(context)
                val notifSummary = notifBrain.summarizeAllNotifications()
                actions.add("Summarized notifications: $notifSummary")

                // 5. Open Spotify
                AppAutomationEngine.automateGenericApp(context, "spotify", "open")
                actions.add("Opened Spotify")

                val spoken = "$greeting I have enabled WiFi and opened Spotify. $notifSummary"
                RoutineResult(true, mode, PersonalityEngine.enforceRespectfulAddress(spoken), actions)
            }

            ContextEngine.OperatingMode.NIGHT -> {
                onProgress("Activating Night Mode...")
                // 1. Lower Brightness
                DeviceController.setBrightness(10)
                actions.add("Lowered brightness to 10%")

                // 2. Enable Battery Saver
                DeviceController.toggleBatterySaver(true)
                actions.add("Enabled battery saver")

                // 3. Lower Volume
                DeviceController.setVolume(context, "set", 15)
                actions.add("Set volume to quiet level")

                // 4. Set DND Filter
                MemoryManager.getInstance(context).setGamingMode(true)
                actions.add("Enabled quiet DND filter")

                val spoken = "नाइट मोड चालू कर दिया है: स्क्रीन धीमी, बैटरी सेवर और शांत सूचनाएँ। शुभ रात्रि।"
                RoutineResult(true, mode, PersonalityEngine.enforceRespectfulAddress(spoken), actions)
            }

            ContextEngine.OperatingMode.GAMING -> {
                onProgress("Engaging Gaming Optimization Mode...")
                // 1. Enable Gaming DND (Only Calls, Family, OTP allowed)
                MemoryManager.getInstance(context).setGamingMode(true)
                actions.add("Enabled Gaming DND filter")

                // 2. Boost performance governor via root if available
                RootCommandEngine.execute("for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do [ -f \"\$g\" ] && echo performance > \"\$g\"; done")
                actions.add("Configured performance CPU governor")

                val spoken = "गेमिंग मोड चालू है। अब सिर्फ़ ज़रूरी कॉल, परिवार के मैसेज और OTP की सूचना ही बोलूँगा।"
                RoutineResult(true, mode, PersonalityEngine.enforceRespectfulAddress(spoken), actions)
            }

            ContextEngine.OperatingMode.WORK -> {
                onProgress("Applying Work Focus Mode...")
                DeviceController.setVolume(context, "set", 30)
                actions.add("Media volume set to 30%")

                MemoryManager.getInstance(context).setGamingMode(false)
                actions.add("Work and team notifications prioritized")

                val spoken = "वर्क मोड चालू है। आवाज़ और सूचनाएँ काम के हिसाब से सेट कर दी हैं।"
                RoutineResult(true, mode, PersonalityEngine.enforceRespectfulAddress(spoken), actions)
            }

            ContextEngine.OperatingMode.DRIVING -> {
                onProgress("Engaging Driving Mode...")
                // 1. Enable Bluetooth for in-car system
                DeviceController.toggleBluetooth(true)
                actions.add("Enabled Bluetooth for car audio")

                // 2. Maximize volume for clarity
                DeviceController.setVolume(context, "set", 90)
                actions.add("Volume set to 90% for navigation")

                val spoken = "ड्राइविंग मोड चालू है। आवाज़ बढ़ा दी है और मैं बिना हाथ लगाए आपकी बात सुनने के लिए तैयार हूँ।"
                RoutineResult(true, mode, PersonalityEngine.enforceRespectfulAddress(spoken), actions)
            }

            ContextEngine.OperatingMode.NORMAL -> {
                MemoryManager.getInstance(context).setGamingMode(false)
                val spoken = "सामान्य मोड वापस लग गया है।"
                RoutineResult(true, mode, PersonalityEngine.enforceRespectfulAddress(spoken), listOf("Reset to Normal"))
            }
        }
    }

    suspend fun setAlarm(
        context: Context,
        hour: Int,
        minute: Int,
        message: String = "MAX Alarm"
    ): RoutineResult = withContext(Dispatchers.IO) {
        val safeHour = hour.coerceIn(0, 23)
        val safeMin = minute.coerceIn(0, 59)
        val actions = mutableListOf<String>()
        var dispatched = false
        val safeMsg = message.replace(Regex("[^\\p{L}\\p{M}\\p{N} ._-]"), "").take(40).ifBlank { "MAX Alarm" }
        try {
            val intent = android.content.Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(android.provider.AlarmClock.EXTRA_HOUR, safeHour)
                putExtra(android.provider.AlarmClock.EXTRA_MINUTES, safeMin)
                putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, safeMsg)
                putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            dispatched = true
            actions.add("Dispatched AlarmClock intent for $safeHour:$safeMin")
        } catch (e: Exception) {
            Log.w(TAG, "Standard alarm intent failed: ${e.message}. Using root shell fallback.")
            val cmd = "am start -a android.intent.action.SET_ALARM --ei android.intent.extra.alarm.HOUR $safeHour --ei android.intent.extra.alarm.MINUTES $safeMin --es android.intent.extra.alarm.MESSAGE \"$safeMsg\" --ez android.intent.extra.alarm.SKIP_UI true"
            val res = RootCommandEngine.execute(cmd)
            actions.add("Executed root alarm command: exit=${res.exitCode}")
            dispatched = res.exitCode == 0
        }
        val spoken = if (dispatched) "${com.example.utils.TimeParser.spokenClockHindi(safeHour, safeMin)} का अलार्म सेट कर दिया है।"
            else "अलार्म सेट नहीं हो पाया। घड़ी ऐप ने अनुरोध नहीं माना, एक बार फिर कोशिश करूँ?"
        RoutineResult(dispatched, ContextEngine.OperatingMode.NORMAL, spoken, actions)
    }

    suspend fun setTimer(
        context: Context,
        seconds: Int,
        message: String = "MAX Timer"
    ): RoutineResult = withContext(Dispatchers.IO) {
        val safeSec = seconds.coerceAtLeast(1)
        val actions = mutableListOf<String>()
        var dispatched = false
        val safeMsg = message.replace(Regex("[^\\p{L}\\p{M}\\p{N} ._-]"), "").take(40).ifBlank { "MAX Timer" }
        try {
            val intent = android.content.Intent(android.provider.AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(android.provider.AlarmClock.EXTRA_LENGTH, safeSec)
                putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, safeMsg)
                putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            dispatched = true
            actions.add("Dispatched Timer intent for $safeSec seconds")
        } catch (e: Exception) {
            val cmd = "am start -a android.intent.action.SET_TIMER --ei android.intent.extra.alarm.LENGTH $safeSec --es android.intent.extra.alarm.MESSAGE \"$safeMsg\" --ez android.intent.extra.alarm.SKIP_UI true"
            val res = RootCommandEngine.execute(cmd)
            actions.add("Executed root timer command: exit=${res.exitCode}")
            dispatched = res.exitCode == 0
        }
        val mins = safeSec / 60
        val secs = safeSec % 60
        val timeDesc = if (mins > 0 && secs > 0) "$mins मिनट $secs सेकंड" else if (mins > 0) "$mins मिनट" else "$secs सेकंड"
        val spoken = if (dispatched) "$timeDesc का टाइमर शुरू कर दिया गया है।" else "टाइमर शुरू नहीं हो पाया, एक बार फिर कोशिश करूँ?"
        RoutineResult(dispatched, ContextEngine.OperatingMode.NORMAL, spoken, actions)
    }
}

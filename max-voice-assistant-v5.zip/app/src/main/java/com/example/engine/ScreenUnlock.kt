package com.example.engine

import android.content.Context
import android.util.Log
import com.example.utils.PreferencesManager
import com.example.utils.ShellQuote
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Hands-free on a locked phone. Before MAX touches the screen it wakes the phone and opens the lock screen:
 *  - no lock / swipe lock: `wm dismiss-keyguard`
 *  - PIN lock: types the PIN, but ONLY if the user told MAX the PIN ("मेरा PIN 1234 है, याद रखो"). It is kept encrypted on the phone,
 *    never sent to Gemini (it is taken out of the sentence before anything else sees it) and never written to the chat history.
 *  - pattern / fingerprint / face: cannot be done by anyone but you; MAX says so.
 * After a task that MAX unlocked the phone for, it puts the screen back to sleep.
 */
object ScreenUnlock {

    private const val TAG = "ScreenUnlock"
    private const val KEY_PIN = "unlock_pin"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ---------------------------------------------------------------- pure helpers (unit-tested)
    private val PIN_WORDS = "(?:(?<![A-Za-z])pin(?![A-Za-z])|पिन|passcode|पासकोड|password|पासवर्ड|लॉक\\s*कोड|lock\\s*code|unlock\\s*code)"

    /** "मेरा PIN 1 2 3 4 है" -> "1234". Digits spoken one by one or together; null when there is no 4-8 digit PIN. */
    fun extractPin(text: String): String? {
        val m = Regex("(?i)$PIN_WORDS\\D{0,20}((?:\\d[\\s-]?){4,8})").find(text) ?: return null
        val digits = m.groupValues[1].filter { it.isDigit() }
        return digits.takeIf { it.length in 4..8 }
    }

    /** Is the user telling MAX to remember a PIN (and not just mentioning a number after the word PIN)? */
    fun isSavePinRequest(text: String): Boolean =
        extractPin(text) != null && Regex("(?i)(याद|रख|save|remember|set|store|सेव|है|is)").containsMatchIn(text)

    fun isForgetPinRequest(text: String): Boolean =
        Regex("(?i)$PIN_WORDS").containsMatchIn(text) && Regex("(?i)(भूल|हटा|मिटा|delete|forget|remove|clear)").containsMatchIn(text)

    /** For anything that is stored or logged: a PIN, password or lock code is replaced by dots. */
    fun redactSecrets(text: String): String =
        Regex("(?i)($PIN_WORDS\\D{0,20})((?:\\d[\\s-]?){3,12})").replace(text) { it.groupValues[1] + "••••" }

    /** Locked when the screen is asleep or the lock screen is showing. Parses the `dumpsys` text; unknown means "not locked". */
    fun parseLocked(windowDump: String, powerDump: String): Boolean {
        val asleep = Regex("mWakefulness=(Asleep|Dozing)", RegexOption.IGNORE_CASE).containsMatchIn(powerDump)
        val keyguard = Regex("(isKeyguardShowing|mShowingLockscreen|mDreamingLockscreen|isStatusBarKeyguardShowing)\\s*=\\s*true", RegexOption.IGNORE_CASE)
            .containsMatchIn(windowDump)
        return asleep || keyguard
    }

    // ---------------------------------------------------------------- the PIN
    fun hasPin(context: Context): Boolean = PreferencesManager.getString(context, KEY_PIN, "").isNotBlank()

    /** Handles "remember / forget my PIN" before the sentence goes anywhere else. Returns what MAX says, or null if it was not about the PIN. */
    fun handlePinCommand(context: Context, text: String): String? {
        if (isSavePinRequest(text)) {
            val pin = extractPin(text) ?: return null
            PreferencesManager.putString(context, KEY_PIN, pin)
            return "ठीक है, PIN याद रख लिया। वह इसी फ़ोन में एन्क्रिप्ट होकर रहेगा, Gemini को या चैट हिस्ट्री में नहीं जाएगा। हटाने के लिए बोलिए: मेरा PIN भूल जाओ।"
        }
        if (isForgetPinRequest(text)) {
            PreferencesManager.putString(context, KEY_PIN, "")
            return "PIN हटा दिया है। अब लॉक होने पर मैं सिर्फ़ बिना-PIN वाला लॉक खोल पाऊँगा।"
        }
        return null
    }

    // ---------------------------------------------------------------- state and unlocking
    suspend fun isLocked(): Boolean {
        val out = RootCommandEngine.execute(
            "dumpsys window | grep -iE 'isKeyguardShowing|mShowingLockscreen|mDreamingLockscreen|isStatusBarKeyguardShowing'; echo ---POWER---; dumpsys power | grep -m1 mWakefulness="
        ).stdout
        val parts = out.split("---POWER---")
        return parseLocked(parts.getOrElse(0) { "" }, parts.getOrElse(1) { "" })
    }

    /** True when the screen is usable afterwards. [unlockedByMax] tells the caller it should lock the phone again when it is done. */
    data class Result(val usable: Boolean, val unlockedByMax: Boolean, val reason: String)

    suspend fun ensureUnlocked(context: Context): Result {
        if (!RootCommandEngine.isRootAvailable()) return Result(true, false, "no root, screen state not checked")
        if (!isLocked()) return Result(true, false, "already unlocked")

        RootCommandEngine.execute("input keyevent 224; wm dismiss-keyguard")   // wake + open a lock screen without a PIN
        delay(600L)
        if (!isLocked()) return Result(true, true, "opened the lock screen")

        val pin = PreferencesManager.getString(context, KEY_PIN, "")
        if (pin.isBlank()) return Result(false, false, "the phone has a PIN, pattern or biometric lock and MAX does not have a PIN")
        val (w, h) = RootUi.screenSize()
        RootUi.swipe(w / 2, (h * 0.85).toInt(), w / 2, (h * 0.25).toInt(), 250)   // pull the lock screen up to the PIN pad
        delay(600L)
        RootCommandEngine.execute("input text ${ShellQuote.q(pin)}; input keyevent 66")
        delay(1000L)
        return if (!isLocked()) Result(true, true, "unlocked with the saved PIN")
        else Result(false, false, "the saved PIN did not open the phone (or this is a pattern / biometric lock)")
    }

    /** Puts the screen to sleep a few seconds after a task that MAX unlocked the phone for. */
    fun lockLater(delayMs: Long = 8000L) {
        scope.launch {
            delay(delayMs)
            try { RootCommandEngine.execute("input keyevent 223") } catch (e: Exception) { Log.w(TAG, "lock failed: ${e.message}") }
        }
    }
}

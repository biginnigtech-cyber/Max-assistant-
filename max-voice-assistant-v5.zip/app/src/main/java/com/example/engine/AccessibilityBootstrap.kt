package com.example.engine

import android.content.ComponentName
import android.content.Context
import android.os.SystemClock
import android.util.Log
import com.example.service.MaxAccessibilityService
import com.example.utils.ShellQuote
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * "Accessibility is on in Settings but MAX says it is off."
 * The switch can be on while Android has not bound the service (after an update, a force-stop or a crash), so
 * `MaxAccessibilityService.instance` stays null. On a rooted phone MAX repairs this by itself: it takes its own service
 * out of the enabled list and puts it back, which makes Android bind it again. No tapping through Settings.
 */
object AccessibilityBootstrap {

    private const val TAG = "A11yBootstrap"
    private val mutex = Mutex()
    @Volatile private var lastAttemptMs = 0L

    suspend fun ensure(context: Context): MaxAccessibilityService? {
        MaxAccessibilityService.instance?.let { return it }
        return mutex.withLock {
            MaxAccessibilityService.instance?.let { return@withLock it }
            val now = SystemClock.elapsedRealtime()
            if (now - lastAttemptMs < 45_000L) return@withLock waitForInstance(2500L)
            lastAttemptMs = now
            if (!RootCommandEngine.isRootAvailable()) return@withLock null

            val component = ComponentName(context, MaxAccessibilityService::class.java).flattenToString()
            val current = RootCommandEngine.execute("settings get secure enabled_accessibility_services").stdout.trim()
            val others = current.split(':').map { it.trim() }.filter { it.isNotEmpty() && it != "null" && it != component }
            Log.i(TAG, "Accessibility service not bound; re-enabling $component through root")

            RootCommandEngine.execute(
                if (others.isEmpty()) "settings delete secure enabled_accessibility_services"
                else "settings put secure enabled_accessibility_services ${ShellQuote.q(others.joinToString(":"))}"
            )
            delay(700L)
            RootCommandEngine.execute(
                "settings put secure enabled_accessibility_services ${ShellQuote.q((others + component).joinToString(":"))}; " +
                    "settings put secure accessibility_enabled 1"
            )
            waitForInstance(5000L)
        }
    }

    private suspend fun waitForInstance(timeoutMs: Long): MaxAccessibilityService? {
        val end = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < end) {
            MaxAccessibilityService.instance?.let { return it }
            delay(120L)
        }
        return MaxAccessibilityService.instance
    }

    const val NOT_RUNNING_MESSAGE =
        "MAX की Accessibility सेवा चल नहीं रही और मैं उसे अपने आप चालू नहीं कर पाया। सेटिंग्स में Accessibility खोलकर MAX को एक बार बंद करके फिर चालू कीजिए।"
}

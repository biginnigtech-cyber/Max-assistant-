package com.example.engine

import android.util.Log

/**
 * Normalizes and extracts structured intents from long or complex voice prompts
 * before handing them off to Gemini or underlying execution layers.
 *
 * Provides instant zero-latency routing for device controls, app launching,
 * music playback, compound messaging, time/date queries, and core assistant chat.
 */
object VoicePromptNormalizer {
    private const val TAG = "VoicePromptNormalizer"

    enum class ActionType {
        OPEN_APP,
        SEND_MESSAGE,
        PLAY_MUSIC,
        DEVICE_CONTROL,
        SYSTEM_COMMAND,
        TIME_QUERY,
        DIRECT_CHAT,
        GENERAL_QUERY
    }

    data class ParsedPrompt(
        val rawPrompt: String,
        val cleanPrompt: String,
        val actionType: ActionType,
        val targetApp: String, // app name or package or action
        val targetEntity: String, // contact name or query or subaction
        val messageContent: String, // message to send or spoken override
        val hasExplicitAction: Boolean
    )

    private val PREFIX_PATTERNS = listOf(
        Regex("^(hey\\s+)?max[,\\s]*", RegexOption.IGNORE_CASE),
        Regex("^(अरे\\s+)?मैक्स[,\\s]*", RegexOption.IGNORE_CASE),
        Regex("^(मैक्स|max)[,\\s]*", RegexOption.IGNORE_CASE),
        Regex("^(सुनो\\s+)?(मैक्स|max)[,\\s]*", RegexOption.IGNORE_CASE),
        Regex("^(please\\s+)?(can\\s+you\\s+)?", RegexOption.IGNORE_CASE),
        Regex("^(कृपया\\s+)?", RegexOption.IGNORE_CASE),
        Regex("^(जरा\\s+)?", RegexOption.IGNORE_CASE)
    )

    /**
     * Cleans wake words and polite greetings from the prompt.
     */
    fun cleanPrompt(raw: String): String {
        var text = raw.trim()
        for (pattern in PREFIX_PATTERNS) {
            text = text.replace(pattern, "").trim()
        }
        return text
    }

    /** Removes the nukta so "बढ़ाओ" / "आवाज़" match however the speech engine wrote them. */
    private fun norm(text: String): String =
        java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFD).replace("\u093C", "")

    /** Whole-word match (Latin or Devanagari). "on" no longer fires inside "phone" or "konsa". */
    private fun hasWord(text: String, vararg words: String): Boolean {
        val t = norm(text.lowercase())
        return words.any { w ->
            Regex("(?<![\\p{L}\\p{M}\\p{N}])" + Regex.escape(norm(w.lowercase())) + "(?![\\p{L}\\p{M}\\p{N}])").containsMatchIn(t)
        }
    }

    private val MESSAGE_OR_MEDIA_INTENT = Regex(
        "(?<![\\p{L}\\p{M}])(message|msg|sms|whatsapp|telegram|messenger|bolo|bhejo|send|play|gana|gaana|song|spotify|youtube|call)(?![\\p{L}\\p{M}])" +
            "|मैसेज|मेसेज|संदेश|बोलो|भेजो|कह\\s*दो|लिखो|गाना|गाने|चलाओ|बजाओ|व्हाट्सएप|व्हाट्सऐप|यूट्यूब|स्पॉटिफाई|कॉल|टेलीग्राम"
    )

    /**
     * Parses voice queries into a structured intent representation.
     *
     * Local shortcuts are only trusted for SHORT, single-purpose sentences. A long or mixed sentence
     * ("Rahul ko bolo wifi band kar diya", "thanks, now play a song") goes to Gemini, which understands
     * the whole sentence, instead of being hijacked by one keyword inside it.
     */
    fun parse(rawPrompt: String): ParsedPrompt {
        val clean = cleanPrompt(rawPrompt)
        val lower = clean.lowercase()
        val wordCount = lower.split(Regex("\\s+")).count { it.isNotBlank() }
        val mixedIntent = MESSAGE_OR_MEDIA_INTENT.containsMatchIn(lower)

        // 1. Direct Assistant Core Chat / Identity / Status / Help commands
        val chatResult = if (wordCount <= 8 && !mixedIntent) parseDirectChatPrompt(clean, lower) else null
        if (chatResult != null) {
            Log.d(TAG, "Parsed direct chat/identity prompt: $chatResult")
            return chatResult
        }

        // 2. Device hardware & OS controls (Torch, Bluetooth, WiFi, Volume, Brightness, Battery, Screenshot)
        val deviceResult = if (wordCount <= 10 && !mixedIntent) parseDeviceControlPrompt(clean, lower) else null
        if (deviceResult != null) {
            Log.d(TAG, "Parsed device control prompt: $deviceResult")
            return deviceResult
        }

        // 3. Time & Date queries
        val timeResult = if (!mixedIntent) parseTimeQueryPrompt(clean, lower) else null
        if (timeResult != null) {
            Log.d(TAG, "Parsed time/date prompt: $timeResult")
            return timeResult
        }

        // 4. Check for compound WhatsApp/Messaging commands using SmartEntityExtractor:
        val smartResult = SmartEntityExtractor.extract(clean)
        if (smartResult != null) {
            val parsed = ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.SEND_MESSAGE,
                targetApp = smartResult.targetApp,
                targetEntity = smartResult.contact,
                messageContent = smartResult.message,
                hasExplicitAction = true
            )
            Log.d(TAG, "SmartEntityExtractor parsed messaging prompt: $parsed")
            return parsed
        }

        val messagingResult = parseMessagingPrompt(clean, lower)
        if (messagingResult != null) {
            Log.d(TAG, "Parsed compound messaging prompt: $messagingResult")
            return messagingResult
        }

        // 5. Check for Spotify or YouTube music playback:
        val musicResult = parseMusicPrompt(clean, lower)
        if (musicResult != null) {
            Log.d(TAG, "Parsed music playback prompt: $musicResult")
            return musicResult
        }

        // 6. Check for Direct App Launch commands:
        val openAppResult = parseOpenAppPrompt(clean, lower)
        if (openAppResult != null) {
            Log.d(TAG, "Parsed app launch prompt: $openAppResult")
            return openAppResult
        }

        // 7. Default: General query
        return ParsedPrompt(
            rawPrompt = rawPrompt,
            cleanPrompt = clean,
            actionType = ActionType.GENERAL_QUERY,
            targetApp = "",
            targetEntity = "",
            messageContent = "",
            hasExplicitAction = false
        )
    }

    private fun parseDirectChatPrompt(clean: String, lower: String): ParsedPrompt? {
        val s = lower.trim()

        // Creator questions
        if (s.contains("creator") || s.contains("who made you") || s.contains("who created you") ||
            s.contains("tumhe kisne banaya") || s.contains("kisne banaya") || s.contains("malik kaun hai") ||
            s.contains("owner kaun") || s.contains("tumhara malik")) {
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DIRECT_CHAT,
                targetApp = "",
                targetEntity = "creator",
                messageContent = "मुझे मिस्टर राम नारायण द्वारा विकसित किया गया है।",
                hasExplicitAction = true
            )
        }

        // Identity / Name questions
        if (s == "who are you" || s == "what is your name" || s.contains("tum kaun ho") ||
            s.contains("tumhara naam") || s.contains("apna naam") || s.contains("aapka naam") ||
            s.contains("what is your name") || s.contains("who are you")) {
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DIRECT_CHAT,
                targetApp = "",
                targetEntity = "identity",
                messageContent = "मेरा नाम MAX है। मैं आपका इंटेलिजेंट AI वॉइस असिस्टेंट हूँ।",
                hasExplicitAction = true
            )
        }

        // "Kam karo" / "Thik karo" / User frustration or readiness commands
        if (s.contains("kam karo") || s.contains("kaam karo") || s.contains("thik karo") ||
            s.contains("theek karo") || s.contains("kam kar yrr") || s.contains("kaam karo yrr") ||
            s.contains("work now") || s.contains("fix it") || s.contains("start working")) {
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DIRECT_CHAT,
                targetApp = "",
                targetEntity = "work_ready",
                messageContent = "हाँ जी, मैं पूरी तरह तैयार और सक्रिय हूँ! आप मुझे ऐप खोलने, टॉर्च, ब्लूटूथ, वाई-फाई, वॉल्यूम, स्क्रीनशॉट या किसी भी टूल का आदेश दे सकते हैं।",
                hasExplicitAction = true
            )
        }

        // Thanks
        if (s.contains("thank you") || s.contains("thanks") || s.contains("dhanyawad") || s.contains("shukriya") || s.contains("धन्यवाद")) {
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DIRECT_CHAT,
                targetApp = "",
                targetEntity = "thanks",
                messageContent = "आपका स्वागत है! किसी भी अन्य काम के लिए मुझे बताइए।",
                hasExplicitAction = true
            )
        }

        // Help / Capabilities
        if (s == "help" || s == "madad" || s == "kya kar sakte ho" || s.contains("features") || s.contains("capabilities")) {
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DIRECT_CHAT,
                targetApp = "",
                targetEntity = "help",
                messageContent = "मैं आपके फोन के ऐप्स खोल सकता हूँ, टॉर्च, ब्लूटूथ, वाई-फाई और वॉल्यूम नियंत्रित कर सकता हूँ, स्क्रीनशॉट ले सकता हूँ, गाने बजा सकता हूँ और संदेश भेज सकता हूँ।",
                hasExplicitAction = true
            )
        }

        return null
    }

    private fun parseDeviceControlPrompt(clean: String, lower: String): ParsedPrompt? {
        val s = lower.trim()

        // 1. Torch / Flashlight
        val isTorchWord = hasWord(s, "torch", "flashlight", "flash", "टॉर्च", "फ्लैशलाइट", "टार्च")
        if (isTorchWord) {
            val isOff = hasWord(s, "off", "band", "bujhao", "stop", "बंद", "बुझाओ", "ऑफ", "बन्द")
            val isOn = hasWord(s, "on", "chalu", "jalao", "start", "चालू", "जलाओ", "ऑन")
            val action = if (isOff) "off" else if (isOn) "on" else "toggle"
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DEVICE_CONTROL,
                targetApp = "torch",
                targetEntity = action,
                messageContent = "",
                hasExplicitAction = true
            )
        }

        // 2. Bluetooth
        val isBluetoothWord = s.contains("bluetooth") || s.contains("ब्लूटूथ")
        if (isBluetoothWord) {
            val isOff = hasWord(s, "off", "band", "disable", "बंद", "बन्द", "ऑफ")
            val action = if (isOff) "off" else "on"
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DEVICE_CONTROL,
                targetApp = "bluetooth",
                targetEntity = action,
                messageContent = "",
                hasExplicitAction = true
            )
        }

        // 3. Wi-Fi
        val isWifiWord = s.contains("wifi") || s.contains("wi-fi") || s.contains("वाईफाई") || s.contains("वाई-फाई")
        if (isWifiWord && !s.contains("scan") && !s.contains("स्लैन") && !s.contains("चिपसेट")) {
            val isOff = hasWord(s, "off", "band", "disable", "बंद", "बन्द", "ऑफ")
            val action = if (isOff) "off" else "on"
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DEVICE_CONTROL,
                targetApp = "wifi",
                targetEntity = action,
                messageContent = "",
                hasExplicitAction = true
            )
        }

        // 4. Volume
        val isVolumeWord = hasWord(s, "volume", "awaaz", "awaz", "sound", "आवाज", "वॉल्यूम", "वाल्यूम")
        if (isVolumeWord) {
            val action = when {
                hasWord(s, "mute", "chup", "silent", "म्यूट") -> "mute"
                hasWord(s, "max", "maximum", "full", "100", "पूरी", "पूरा", "फुल") -> "max"
                hasWord(s, "badhao", "badha", "up", "increase", "higher", "tez", "ज़्यादा", "ज्यादा", "बढ़ाओ", "बढ़ा", "बढाओ", "बढ़ाइए") -> "up"
                hasWord(s, "kam", "kum", "down", "decrease", "lower", "dheemi", "halki", "कम", "घटाओ", "घटा", "धीमी", "धीरे") -> "down"
                else -> "up"
            }
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DEVICE_CONTROL,
                targetApp = "volume",
                targetEntity = action,
                messageContent = "",
                hasExplicitAction = true
            )
        }

        // 5. Brightness
        val isBrightnessWord = hasWord(s, "brightness", "chamak", "ब्राइटनेस")
        if (isBrightnessWord) {
            val pct = when {
                hasWord(s, "full", "max", "maximum", "100", "फुल", "पूरी") -> "100"
                hasWord(s, "badhao", "badha", "up", "increase", "बढ़ाओ", "बढ़ा", "बढाओ") -> "85"
                hasWord(s, "kam", "down", "decrease", "कम", "घटाओ", "घटा") -> "35"
                else -> "70"
            }
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DEVICE_CONTROL,
                targetApp = "brightness",
                targetEntity = pct,
                messageContent = "",
                hasExplicitAction = true
            )
        }

        // 6. Screenshot
        if (s.contains("screenshot") || s.contains("स्क्रीनशॉट") || s.contains("screen capture")) {
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DEVICE_CONTROL,
                targetApp = "screenshot",
                targetEntity = "take",
                messageContent = "",
                hasExplicitAction = true
            )
        }

        // 7. Battery & System Metrics
        if (s.contains("battery") || s.contains("बैटरी") || s.contains("charging") ||
            s.contains("system metrics") || s.contains("phone status") || s.contains("ram status")) {
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.DEVICE_CONTROL,
                targetApp = "battery",
                targetEntity = "metrics",
                messageContent = "",
                hasExplicitAction = true
            )
        }

        return null
    }

    private fun parseTimeQueryPrompt(clean: String, lower: String): ParsedPrompt? {
        val s = norm(lower.trim())
        // Alarms, timers and reminders also contain clock words: never treat them as "what time is it?"
        if (Regex("alarm|अलार्म|timer|टाइमर|remind|रिमाइंडर|बजे का|बजे के लिए|बजे उठा|जगा").containsMatchIn(s)) return null

        val isTime = Regex(
            "what('s| is)?\\s+the\\s+time|current\\s+time|what\\s+time\\s+is\\s+it|time\\s+(kya|kitna|batao|bata)|abhi\\s+(ka\\s+)?time|kitne\\s+baje|kya\\s+baja|kitna\\s+baja|" +
                "टाइम\\s*(क्या|कितना|बताओ|बता)|समय\\s*(क्या|कितना|बताओ|बता)|कितने\\s+बजे|क्या\\s+बजा|कितना\\s+बजा|अभी\\s+(का\\s+)?(टाइम|समय)"
        ).containsMatchIn(s)
        // A bare "date" / "तारीख" / "time" / "टाइम" is NOT a question. Only a complete question is answered here;
        // anything else goes to Gemini, which asks what the user wants to know (which date, which day, how many days...).
        val isDate = Regex(
            "what('s| is)?\\s+(the\\s+)?(today'?s\\s+)?date(\\s+today)?\\b|today'?s\\s+date\\s+(please|batao|bata|kya)|what\\s+day\\s+is\\s+(it|today)|" +
                "aaj\\s+(ki\\s+|ka\\s+)?(date|tarikh)\\s*(kya|kaun|konsi|batao|bata|hai)|(date|tarikh)\\s+(kya|konsi|kaun\\s*si|batao|bata)|" +
                "(konsi|kaun\\s*si|kaunsi)\\s+(date|tarikh)|aaj\\s+(kaun\\s*sa|konsa)\\s+din|" +
                "आज\\s+(की\\s+)?(तारीख|date|डेट)\\s*(क्या|कौन|बताओ|बता|है)|(कौन\\s*सी|कौनसी)\\s+(तारीख|date|डेट)|(तारीख|डेट)\\s+(क्या|कौन|बताओ|बता)|" +
                "कौन\\s*सा\\s+दिन|आज\\s+क्या\\s+(दिन|वार)"
        ).containsMatchIn(s)

        if (isTime || isDate) {
            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.TIME_QUERY,
                targetApp = if (isDate) "date" else "time",
                targetEntity = "",
                messageContent = "",
                hasExplicitAction = true
            )
        }
        return null
    }

    private fun parseMessagingPrompt(clean: String, lower: String): ParsedPrompt? {
        val isWhatsApp = lower.contains("whatsapp") || lower.contains("व्हाट्सएप") || lower.contains("व्हाट्सऐप")
        val isTelegram = lower.contains("telegram") || lower.contains("टेलीग्राम")
        val isSms = lower.contains("sms") || lower.contains("text message") || lower.contains("एसएमएस")

        val targetApp = when {
            isWhatsApp -> "whatsapp"
            isTelegram -> "telegram"
            isSms -> "sms"
            else -> {
                if (lower.contains("message") || lower.contains("संदेश") || lower.contains("मैसेज") || lower.contains("बोलो")) {
                    "whatsapp" // default chat app
                } else {
                    return null
                }
            }
        }

        // Pattern 1 (English): open whatsapp and (tell|message|send) <Contact> (that|saying|to)? <Message>
        val enPattern = Regex(
            "(?:open\\s+whatsapp\\s+(?:and\\s+)?|send\\s+(?:a\\s+)?message\\s+to\\s+|tell\\s+|message\\s+)([a-zA-Z0-9_]+)\\s+(?:on\\s+whatsapp\\s+)?(?:that\\s+|saying\\s+|to\\s+|:)?(.+)",
            RegexOption.IGNORE_CASE
        )
        val enMatch = enPattern.find(clean)
        if (enMatch != null) {
            val contact = enMatch.groupValues[1].trim()
            val msg = enMatch.groupValues[2].trim()
            if (contact.isNotBlank() && msg.isNotBlank()) {
                return ParsedPrompt(
                    rawPrompt = clean,
                    cleanPrompt = clean,
                    actionType = ActionType.SEND_MESSAGE,
                    targetApp = targetApp,
                    targetEntity = contact,
                    messageContent = msg,
                    hasExplicitAction = true
                )
            }
        }

        // Pattern 2 (Hindi / Hinglish):
        val hiPattern = Regex(
            "(?:whatsapp|व्हाट्सएप|व्हाट्सऐप)?(?:\\s*खोलो\\s*और\\s*|\\s*पर\\s*|\\s*में\\s*)?([\\p{L}a-zA-Z0-9_]+)\\s*(?:को|से)\\s*(?:बोलो|मैसेज\\s*करो|कह\\s*दो|लिखो|भेजो)\\s*(?:कि\\s*)?(.+)",
            RegexOption.IGNORE_CASE
        )
        val hiMatch = hiPattern.find(clean)
        if (hiMatch != null) {
            val contact = hiMatch.groupValues[1].trim()
            val msg = hiMatch.groupValues[2].trim()
            if (contact.isNotBlank() && msg.isNotBlank() && !contact.equals("whatsapp", ignoreCase = true)) {
                return ParsedPrompt(
                    rawPrompt = clean,
                    cleanPrompt = clean,
                    actionType = ActionType.SEND_MESSAGE,
                    targetApp = targetApp,
                    targetEntity = contact,
                    messageContent = msg,
                    hasExplicitAction = true
                )
            }
        }

        return null
    }

    private fun parseMusicPrompt(clean: String, lower: String): ParsedPrompt? {
        val isSpotify = lower.contains("spotify") || lower.contains("स्पॉटिफाई")
        val isYouTube = lower.contains("youtube") || lower.contains("यूट्यूब")
        val isGenericMusic = lower.contains("gaana") || lower.contains("गाना") || lower.contains("song") || lower.contains("music")

        if (isSpotify) {
            var song = clean
                .replace(Regex("open\\s+spotify\\s+(and\\s+)?(play\\s+)?", RegexOption.IGNORE_CASE), "")
                .replace(Regex("play\\s+", RegexOption.IGNORE_CASE), "")
                .replace(Regex("\\s+on\\s+spotify", RegexOption.IGNORE_CASE), "")
                .replace(Regex("spotify\\s*(par|pe)?\\s*(gaana|song)?\\s*(bajao|play)?", RegexOption.IGNORE_CASE), "")
                .replace(Regex("spotify", RegexOption.IGNORE_CASE), "")
                .trim()

            if (song.isBlank()) song = "top hits"

            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.PLAY_MUSIC,
                targetApp = "spotify",
                targetEntity = song,
                messageContent = "",
                hasExplicitAction = true
            )
        }

        if (isYouTube && (isGenericMusic || lower.contains("chalao") || lower.contains("play") || lower.contains("bajao") || lower.contains("search"))) {
            var query = clean
                .replace(Regex("open\\s+youtube\\s+(and\\s+)?(play\\s+)?", RegexOption.IGNORE_CASE), "")
                .replace(Regex("play\\s+", RegexOption.IGNORE_CASE), "")
                .replace(Regex("\\s+on\\s+youtube", RegexOption.IGNORE_CASE), "")
                .replace(Regex("youtube\\s*(par|pe)?\\s*(chalao|dekhao|bajao|search\\s*karo|play)?", RegexOption.IGNORE_CASE), "")
                .replace(Regex("youtube", RegexOption.IGNORE_CASE), "")
                .trim()

            if (query.isBlank()) query = "trending music"

            return ParsedPrompt(
                rawPrompt = clean,
                cleanPrompt = clean,
                actionType = ActionType.PLAY_MUSIC,
                targetApp = "youtube",
                targetEntity = query,
                messageContent = "",
                hasExplicitAction = true
            )
        }

        return null
    }

    private fun parseOpenAppPrompt(clean: String, lower: String): ParsedPrompt? {
        // Regex patterns for app opening:
        // "open <App>", "launch <App>", "start <App>", "<App> kholo", "<App> open karo", "<App> chalao"
        val openPatterns = listOf(
            Regex("^(?:open|launch|start)\\s+([a-zA-Z0-9_\\s]+)$", RegexOption.IGNORE_CASE),
            Regex("^([a-zA-Z0-9_\\s]+)\\s+(?:kholo|khol\\s*do|kholna|chalao|chalana)$", RegexOption.IGNORE_CASE),
            Regex("^([a-zA-Z0-9_\\s]+)\\s+(?:open\\s*karo|open\\s*kar\\s*do)$", RegexOption.IGNORE_CASE),
            Regex("^(?:kholo|chalao)\\s+([a-zA-Z0-9_\\s]+)$", RegexOption.IGNORE_CASE)
        )

        for (pattern in openPatterns) {
            val match = pattern.find(clean)
            if (match != null) {
                var app = match.groupValues[1].trim()
                app = app.replace(Regex("^(the|an|a)\\s+", RegexOption.IGNORE_CASE), "").trim()
                if (app.isNotBlank() && app.length < 35 && !app.equals("max", ignoreCase = true)) {
                    return ParsedPrompt(
                        rawPrompt = clean,
                        cleanPrompt = clean,
                        actionType = ActionType.OPEN_APP,
                        targetApp = app,
                        targetEntity = app,
                        messageContent = "",
                        hasExplicitAction = true
                    )
                }
            }
        }

        return null
    }
}

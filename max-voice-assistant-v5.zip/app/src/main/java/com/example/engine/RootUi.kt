package com.example.engine

import kotlinx.coroutines.delay

/**
 * Reading and driving the screen with ROOT, without the Accessibility service.
 * `uiautomator dump` gives the same view tree (text, description, id, bounds) that accessibility would,
 * and `input tap / swipe / keyevent` do the touching. On a rooted phone MAX therefore never has to ask for
 * the accessibility permission just to scroll, go back, tap a result or press a send button.
 */
object RootUi {

    data class Node(
        val pkg: String,
        val id: String,
        val text: String,
        val desc: String,
        val cls: String,
        val clickable: Boolean,
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int
    ) {
        val width get() = right - left
        val height get() = bottom - top
        val cx get() = (left + right) / 2
        val cy get() = (top + bottom) / 2
        val label get() = (desc + " " + text).trim()
    }

    private const val DUMP_FILE = "/data/local/tmp/max_ui.xml"
    private val NODE_TAG = Regex("<node\\b([^>]*?)/?>")
    private val ATTR = Regex("([\\w:-]+)=\"([^\"]*)\"")
    private val BOUNDS = Regex("\\[(-?\\d+),(-?\\d+)]\\[(-?\\d+),(-?\\d+)]")

    private fun unescape(s: String): String = s
        .replace("&#10;", "\n").replace("&#13;", "\r")
        .replace("&quot;", "\"").replace("&apos;", "'")
        .replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")

    /** Pure parser, kept separate so it can be unit-tested. */
    fun parse(xml: String): List<Node> {
        val out = ArrayList<Node>()
        for (m in NODE_TAG.findAll(xml)) {
            val attrs = HashMap<String, String>()
            for (a in ATTR.findAll(m.groupValues[1])) attrs[a.groupValues[1]] = unescape(a.groupValues[2])
            val b = BOUNDS.find(attrs["bounds"] ?: "") ?: continue
            out.add(
                Node(
                    pkg = attrs["package"].orEmpty(),
                    id = attrs["resource-id"].orEmpty(),
                    text = attrs["text"].orEmpty(),
                    desc = attrs["content-desc"].orEmpty(),
                    cls = attrs["class"].orEmpty(),
                    clickable = attrs["clickable"] == "true",
                    left = b.groupValues[1].toInt(),
                    top = b.groupValues[2].toInt(),
                    right = b.groupValues[3].toInt(),
                    bottom = b.groupValues[4].toInt()
                )
            )
        }
        return out
    }

    /** Current screen as nodes. Empty when the dump failed (the player screen sometimes refuses once). */
    suspend fun dump(): List<Node> {
        repeat(3) {
            val res = RootCommandEngine.execute("uiautomator dump $DUMP_FILE >/dev/null 2>&1; cat $DUMP_FILE")
            if (res.stdout.contains("<hierarchy")) return parse(res.stdout)
            delay(350L)
        }
        return emptyList()
    }

    /** Screen off or on the lock screen: wake it, and dismiss a lock screen that has no PIN. Harmless when it is already on. */
    suspend fun wakeScreen() {
        RootCommandEngine.execute("input keyevent 224; wm dismiss-keyguard")
        delay(500L)
    }

    suspend fun tap(x: Int, y: Int): Boolean = RootCommandEngine.execute("input tap $x $y").success

    suspend fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Int = 320): Boolean =
        RootCommandEngine.execute("input swipe $x1 $y1 $x2 $y2 $durationMs").success

    suspend fun key(code: Int): Boolean = RootCommandEngine.execute("input keyevent $code").success

    suspend fun screenSize(): Pair<Int, Int> {
        val out = RootCommandEngine.execute("wm size").stdout
        val m = Regex("(\\d{3,5})x(\\d{3,5})").findAll(out).lastOrNull()
        return if (m != null) Pair(m.groupValues[1].toInt(), m.groupValues[2].toInt()) else Pair(1080, 2400)
    }

    /**
     * One screen action by name. Returns true/false for done/not done, or null when this action is not something
     * root can do on its own (the caller then tries Accessibility).
     */
    suspend fun perform(action: String, params: Map<String, String>, times: Int): Boolean? {
        val a = action.lowercase().replace(" ", "_")
        return when {
            a.contains("scroll") || a.contains("swipe_up") || a.contains("swipe_down") -> {
                val (w, h) = screenSize()
                // "scroll_down" / "swipe_up" = see content further down = the finger moves up.
                val backward = a.contains("scroll_up") || a.contains("swipe_down")
                var ok = true
                repeat(times) {
                    val fromY = if (backward) (h * 0.30).toInt() else (h * 0.72).toInt()
                    val toY = if (backward) (h * 0.72).toInt() else (h * 0.30).toInt()
                    ok = swipe(w / 2, fromY, w / 2, toY) && ok
                    delay(450L)
                }
                ok
            }
            a.contains("swipe_left") || a == "next" -> { val (w, h) = screenSize(); swipe((w * 0.80).toInt(), h / 2, (w * 0.20).toInt(), h / 2) }
            a.contains("swipe_right") || a == "previous" -> { val (w, h) = screenSize(); swipe((w * 0.20).toInt(), h / 2, (w * 0.80).toInt(), h / 2) }
            a.contains("back") -> key(4)
            a.contains("home") -> key(3)
            a.contains("recent") -> key(187)
            a.contains("notification") -> RootCommandEngine.execute("cmd statusbar expand-notifications").success
            a.contains("tap_nth") || a.contains("tap_first") || a.contains("tap_item") || a.contains("click_nth") -> {
                val idx = (params["index"]?.toIntOrNull() ?: 1).coerceAtLeast(1)
                val items = dump().filter { it.clickable && it.width > 120 && it.height > 80 && it.pkg != "com.android.systemui" }
                    .sortedWith(compareBy({ it.top }, { it.left }))
                val n = items.getOrNull(idx - 1) ?: return false
                tap(n.cx, n.cy)
            }
            a.contains("tap") || a.contains("click") -> {
                val wanted = (params["text"] ?: params["target"] ?: "").trim().lowercase()
                if (wanted.isBlank()) return false
                val n = dump().filter { it.label.lowercase().contains(wanted) }.minByOrNull { it.width * it.height } ?: return false
                tap(n.cx, n.cy)
            }
            else -> null
        }
    }
}

package com.example.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.util.Log
import com.example.brain.NotificationClassifier
import com.example.brain.VoiceIntentRouter
import com.example.receiver.AutomationReceiver
import com.example.tts.TTSManager
import com.example.utils.PreferencesManager
import com.example.utils.TimeParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * "Do it for me, by yourself": rules the user speaks once and MAX runs later without being asked again.
 *   "रोज़ सुबह 7 बजे मौसम बताओ" · "बैटरी 20% पर battery saver चालू करो" · "राहुल का कॉल आए तो मुझे बताओ"
 *   "चार्जर लगते ही brightness कम करो" · "10 मिनट बाद YouTube पर गाना लगाओ"
 * Gemini turns the sentence into a rule (when + what). The WHAT is kept as the user's own words and, when the time comes,
 * is handed to the same router that handles live voice commands, so Gemini decides how to do it then. Nothing is a fixed script.
 */
object Automations {

    private const val TAG = "Automations"
    private const val PREF_KEY = "automation_rules"
    const val ACTION_FIRE = "com.example.AUTOMATION_FIRE"
    const val EXTRA_RULE_ID = "rule_id"
    const val EXTRA_CONTEXT = "extra"

    data class Rule(
        val id: String,
        val name: String,
        val trigger: String,          // time | battery_below | charger_connected | charger_disconnected | notification | call
        val hour: Int = 0,
        val minute: Int = 0,
        val days: String = "daily",   // daily | weekdays | weekends | mon,tue,...
        val atMs: Long = 0L,          // one exact moment ("in 10 minutes")
        val percent: Int = 0,
        val match: List<String> = emptyList(),
        val command: String,
        val once: Boolean = false,
        val silent: Boolean = false
    )

    data class Outcome(val success: Boolean, val spoken: String)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ------------------------------------------------------------------ storage
    private fun toJson(r: Rule) = JSONObject()
        .put("id", r.id).put("name", r.name).put("trigger", r.trigger).put("hour", r.hour).put("minute", r.minute)
        .put("days", r.days).put("atMs", r.atMs).put("percent", r.percent).put("match", JSONArray(r.match))
        .put("command", r.command).put("once", r.once).put("silent", r.silent)

    private fun fromJson(o: JSONObject): Rule {
        val m = ArrayList<String>()
        o.optJSONArray("match")?.let { for (i in 0 until it.length()) m.add(it.optString(i)) }
        return Rule(
            o.optString("id"), o.optString("name"), o.optString("trigger"), o.optInt("hour"), o.optInt("minute"),
            o.optString("days", "daily"), o.optLong("atMs"), o.optInt("percent"), m, o.optString("command"),
            o.optBoolean("once"), o.optBoolean("silent")
        )
    }

    @Synchronized
    fun load(context: Context): List<Rule> = try {
        val arr = JSONArray(PreferencesManager.getString(context, PREF_KEY, "[]"))
        (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }.filter { it.id.isNotBlank() && it.command.isNotBlank() }
    } catch (e: Exception) {
        Log.w(TAG, "Could not read the rules: ${e.message}")
        emptyList()
    }

    @Synchronized
    private fun save(context: Context, rules: List<Rule>) {
        val arr = JSONArray()
        rules.forEach { arr.put(toJson(it)) }
        PreferencesManager.putString(context, PREF_KEY, arr.toString())
    }

    // ------------------------------------------------------------------ pure helpers (unit-tested)
    private val DAY_INDEX = mapOf(
        "sun" to Calendar.SUNDAY, "mon" to Calendar.MONDAY, "tue" to Calendar.TUESDAY, "wed" to Calendar.WEDNESDAY,
        "thu" to Calendar.THURSDAY, "fri" to Calendar.FRIDAY, "sat" to Calendar.SATURDAY
    )

    fun allowedDays(days: String): Set<Int> {
        val d = days.trim().lowercase()
        return when {
            d.isBlank() || d == "daily" || d == "everyday" || d == "every_day" || d.contains("रोज") -> DAY_INDEX.values.toSet()
            d == "weekdays" -> setOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY)
            d == "weekends" -> setOf(Calendar.SATURDAY, Calendar.SUNDAY)
            else -> d.split(',', ' ', ';').mapNotNull { DAY_INDEX[it.trim().take(3)] }.toSet().ifEmpty { DAY_INDEX.values.toSet() }
        }
    }

    /** Next moment a time rule should run after [nowMs], or -1 when there is none (a one-off that already passed). */
    fun nextTriggerMs(rule: Rule, nowMs: Long): Long {
        if (rule.trigger != "time") return -1L
        if (rule.atMs > 0L) return if (rule.atMs > nowMs) rule.atMs else -1L
        val allowed = allowedDays(rule.days)
        val cal = Calendar.getInstance().apply {
            timeInMillis = nowMs
            set(Calendar.HOUR_OF_DAY, rule.hour.coerceIn(0, 23)); set(Calendar.MINUTE, rule.minute.coerceIn(0, 59))
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        repeat(8) {
            if (cal.timeInMillis > nowMs && cal.get(Calendar.DAY_OF_WEEK) in allowed) return cal.timeInMillis
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        return -1L
    }

    /** Does a call / notification belong to the rule? An empty list means "any". "unknown" means a caller without a name. */
    fun matches(rule: Rule, appName: String, sender: String?): Boolean {
        if (rule.match.isEmpty()) return true
        val hay = (appName + " " + (sender ?: "")).lowercase()
        return rule.match.any { m ->
            val k = m.trim().lowercase()
            if (k.isEmpty()) false
            else if (k == "unknown" || k == "अननोन" || k == "अज्ञात") sender == null
            else hay.contains(k)
        }
    }

    private fun daysHindi(days: String): String {
        val d = days.trim().lowercase()
        return when {
            d.isBlank() || d == "daily" || d == "everyday" -> "रोज़"
            d == "weekdays" -> "सोमवार से शुक्रवार"
            d == "weekends" -> "शनिवार-रविवार को"
            else -> "चुने हुए दिनों में"
        }
    }

    fun describe(r: Rule): String {
        val what = r.command
        return when (r.trigger) {
            "time" -> if (r.atMs > 0L) "एक बार, तय समय पर: $what"
                else "${daysHindi(r.days)} ${TimeParser.spokenClockHindi(r.hour, r.minute)} पर: $what"
            "battery_below" -> "बैटरी ${r.percent}% या उससे कम होने पर: $what"
            "charger_connected" -> "चार्जर लगाते ही: $what"
            "charger_disconnected" -> "चार्जर हटाते ही: $what"
            "call" -> "${if (r.match.isEmpty()) "किसी का भी" else r.match.first() + " का"} कॉल आने पर: $what"
            "notification" -> "${r.match.firstOrNull() ?: "किसी"} की सूचना आने पर: $what"
            else -> what
        }
    }

    private fun normalizeTrigger(raw: String): String {
        val t = raw.trim().lowercase().replace(' ', '_').replace('-', '_')
        return when {
            t in setOf("time", "schedule", "daily", "at_time", "timer", "clock") -> "time"
            t.contains("battery") -> "battery_below"
            t.contains("disconnect") || t.contains("unplug") -> "charger_disconnected"
            t.contains("charger") || t.contains("plug") || t.contains("charging") -> "charger_connected"
            t.contains("call") -> "call"
            t.contains("notif") || t.contains("message") -> "notification"
            else -> ""
        }
    }

    // ------------------------------------------------------------------ create / list / delete (spoken answers)
    suspend fun create(context: Context, p: Map<String, String>, userText: String): Outcome {
        val trigger = normalizeTrigger(p["trigger"] ?: p["type"] ?: "")
        if (trigger.isEmpty()) return Outcome(false, "यह काम कब या किस बात पर होना चाहिए? समय, बैटरी, चार्जर, कॉल या किसी की सूचना में से बताइए।")
        val command = (p["command"] ?: p["task"] ?: p["action"] ?: "").trim()
        if (command.isBlank()) return Outcome(false, "उस वक़्त मुझे क्या करना है? काम बताइए।")
        val name = (p["name"] ?: command).take(40)
        val silent = p["silent"].equals("true", true)
        val id = "r" + System.currentTimeMillis().toString(36)
        val match = (p["match"] ?: "").split(',').map { it.trim() }.filter { it.isNotEmpty() }

        val rule: Rule = when (trigger) {
            "time" -> {
                val delayMin = p["delay_minutes"]?.toIntOrNull()
                if (delayMin != null && delayMin > 0) {
                    Rule(id, name, trigger, atMs = System.currentTimeMillis() + delayMin * 60_000L, command = command, once = true, silent = silent)
                } else {
                    val t = TimeParser.alarmFromParameters(p + mapOf("time" to (p["time"] ?: "")))
                        ?: return Outcome(false, "किस समय पर करना है? समय बताइए।")
                    Rule(id, name, trigger, t.hour, t.minute, days = p["days"] ?: "daily", command = command,
                        once = p["once"].equals("true", true), silent = silent)
                }
            }
            "battery_below" -> {
                val pct = p["percent"]?.toIntOrNull()?.takeIf { it in 1..99 }
                    ?: return Outcome(false, "बैटरी कितने प्रतिशत पर यह होना चाहिए?")
                Rule(id, name, trigger, percent = pct, command = command, silent = silent, once = p["once"].equals("true", true))
            }
            "notification" -> {
                if (match.isEmpty()) return Outcome(false, "किस ऐप या किस व्यक्ति की सूचना आने पर? नाम बताइए।")
                Rule(id, name, trigger, match = match, command = command, silent = silent, once = p["once"].equals("true", true))
            }
            else -> Rule(id, name, trigger, match = match, command = command, silent = silent, once = p["once"].equals("true", true))
        }
        save(context, load(context) + rule)
        if (rule.trigger == "time") {
            RootCommandEngine.execute("appops set ${context.packageName} SCHEDULE_EXACT_ALARM allow")   // exact alarms without a Settings trip
            schedule(context, rule)
        }
        return Outcome(true, "ठीक है, नियम बना दिया: ${describe(rule)}।")
    }

    fun list(context: Context): Outcome {
        val rules = load(context)
        if (rules.isEmpty()) return Outcome(true, "अभी कोई automation बना हुआ नहीं है।")
        val lines = rules.mapIndexed { i, r -> "${i + 1}. ${describe(r)}" }
        return Outcome(true, "आपके ${rules.size} automation हैं। " + lines.joinToString("। ") + "।")
    }

    fun delete(context: Context, p: Map<String, String>): Outcome {
        val rules = load(context)
        if (rules.isEmpty()) return Outcome(false, "हटाने के लिए कोई automation है ही नहीं।")
        val all = p["all"].equals("true", true) || (p["name"] ?: "").trim().lowercase() == "all"
        val key = ((p["name"] ?: p["match"] ?: p["id"]) ?: "").trim().lowercase()
        val idx = p["index"]?.toIntOrNull()
        val toRemove = when {
            all -> rules
            idx != null -> listOfNotNull(rules.getOrNull(idx - 1))
            key.isNotBlank() -> rules.filter { it.id == key || it.name.lowercase().contains(key) || it.command.lowercase().contains(key) || it.match.any { m -> m.lowercase().contains(key) } }
            else -> emptyList()
        }
        if (toRemove.isEmpty()) return Outcome(false, "इस नाम का कोई automation नहीं मिला। सूची सुनने के लिए बोलिए: मेरे automation बताओ।")
        toRemove.forEach { cancelAlarm(context, it) }
        save(context, rules.filter { r -> toRemove.none { it.id == r.id } })
        return Outcome(true, if (all) "सारे automation हटा दिए हैं।" else "हटा दिया: ${toRemove.joinToString("; ") { describe(it) }}।")
    }

    // ------------------------------------------------------------------ scheduling (time rules)
    private fun pendingFor(context: Context, rule: Rule): PendingIntent {
        val intent = Intent(context, AutomationReceiver::class.java).setAction(ACTION_FIRE).putExtra(EXTRA_RULE_ID, rule.id)
        return PendingIntent.getBroadcast(context, rule.id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(context: Context, rule: Rule) {
        val at = nextTriggerMs(rule, System.currentTimeMillis())
        if (at < 0) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingFor(context, rule)
        try {
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancelAlarm(context: Context, rule: Rule) {
        try { (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pendingFor(context, rule)) } catch (_: Exception) {}
    }

    fun scheduleAll(context: Context) = load(context).filter { it.trigger == "time" }.forEach { schedule(context, it) }

    // ------------------------------------------------------------------ running a rule
    suspend fun fire(context: Context, ruleId: String, extra: String = "") {
        val rule = load(context).firstOrNull { it.id == ruleId } ?: return
        // A one-off is removed BEFORE it runs, so a crash can never make it repeat. A repeating time rule books its next run first.
        if (rule.once) { save(context, load(context).filter { it.id != rule.id }); cancelAlarm(context, rule) }
        else if (rule.trigger == "time") schedule(context, rule)

        val key = PreferencesManager.getApiKey(context)
        if (key.isBlank()) { Log.w(TAG, "Rule '${rule.name}' skipped: no API key"); return }
        val command = if (extra.isBlank()) rule.command else "${rule.command}\n(Trigger details: $extra)"
        Log.i(TAG, "Running automation '${rule.name}': $command")
        val result = try {
            VoiceIntentRouter.getInstance(context).routeAndExecute(
                userQuery = command, apiKey = key, selectedModel = PreferencesManager.getSelectedModel(context), history = emptyList(),
                onStatusChange = {}, onProgress = {}, onOutputLine = {}
            )
        } catch (e: Exception) {
            Log.e(TAG, "Automation failed: ${e.message}", e)
            null
        }
        if (!rule.silent) {
            val say = result?.spokenResponse?.takeIf { it.isNotBlank() } ?: "'${rule.name}' वाला काम चलाने में दिक्कत आई।"
            TTSManager.getInstance(context).speakIndependent(say)
        }
    }

    private fun launchFire(context: Context, id: String, extra: String) {
        val app = context.applicationContext
        scope.launch { fire(app, id, extra) }
    }

    // ------------------------------------------------------------------ event hooks
    fun onCharger(context: Context, connected: Boolean) {
        val wanted = if (connected) "charger_connected" else "charger_disconnected"
        load(context).filter { it.trigger == wanted }.forEach { launchFire(context, it.id, "") }
    }

    @Volatile private var lastBatteryLevel = -1

    /** Fires "battery below X" once, when the level crosses X on the way down. */
    fun onBattery(context: Context, level: Int, charging: Boolean) {
        val previous = lastBatteryLevel
        lastBatteryLevel = level
        if (charging || previous < 0 || level >= previous) return
        load(context).filter { it.trigger == "battery_below" && previous > it.percent && level <= it.percent }
            .forEach { launchFire(context, it.id, "battery is at $level%") }
    }

    /** Called by the notification listener for every notification and call. Only the sender and app name are passed on, never the message body. */
    fun onNotification(context: Context, appName: String, title: String, text: String, isCall: Boolean) {
        val rules = load(context)
        if (rules.isEmpty()) return
        if (isCall) {
            val caller = NotificationClassifier.getInstance(context).callerName(title, text)
            rules.filter { it.trigger == "call" && matches(it, appName, caller) }
                .forEach { launchFire(context, it.id, "incoming call from ${caller ?: "an unknown number"}") }
        } else {
            rules.filter { it.trigger == "notification" && matches(it, appName, title) }
                .forEach { launchFire(context, it.id, "notification from ${title.take(40)} in $appName") }
        }
    }

    private var batteryReceiver: BroadcastReceiver? = null

    /** Needs a live receiver (battery-level broadcasts cannot be declared in the manifest): started with the voice service. */
    fun startBatteryWatcher(context: Context) {
        if (batteryReceiver != null) return
        val app = context.applicationContext
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
                if (level >= 0 && scale > 0) onBattery(app, level * 100 / scale, charging)
            }
        }
        try { app.registerReceiver(r, IntentFilter(Intent.ACTION_BATTERY_CHANGED)); batteryReceiver = r } catch (e: Exception) { Log.w(TAG, "Battery watcher failed: ${e.message}") }
    }

    fun stopBatteryWatcher(context: Context) {
        try { batteryReceiver?.let { context.applicationContext.unregisterReceiver(it) } } catch (_: Exception) {}
        batteryReceiver = null
    }
}

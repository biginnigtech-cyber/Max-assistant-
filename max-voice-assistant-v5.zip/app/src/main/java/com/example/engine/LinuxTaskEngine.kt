package com.example.engine

import android.content.Context
import android.util.Log
import com.example.brain.PersonalityEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.withContext

/**
 * LinuxTaskEngine (MAX AI OS)
 *
 * Capabilities:
 * - Run standard Linux commands (via Magisk root shell).
 * - Run Termux environment commands (inside Termux prefix).
 * - Run Kali NetHunter chroot commands.
 * - Live stream terminal output to UI.
 * - Track and report execution progress.
 * - Detect sensitive operations for user confirmation.
 * - Absolute rule: Never fakes terminal output.
 */
object LinuxTaskEngine {
    private const val TAG = "LinuxTaskEngine"

    enum class TargetEnvironment {
        ROOT_LINUX,
        TERMUX,
        KALI_NETHUNTER
    }

    data class LinuxTaskResult(
        val success: Boolean,
        val exitCode: Int,
        val output: String,
        val error: String,
        val environment: TargetEnvironment,
        val durationMs: Long,
        val spokenSummary: String
    )

    private val _streamFlow = MutableSharedFlow<String>(extraBufferCapacity = 128)
    val streamFlow: SharedFlow<String> = _streamFlow.asSharedFlow()

    // Sensitive commands requiring confirmation
    // "format" used to match "information" and "chroot" is how every Kali command runs, so both asked for pointless confirmation.
    private val DANGEROUS = Regex(
        "(^|[\\s;&|])(rm\\s+-[a-z]*r[a-z]*f|rm\\s+-[a-z]*f[a-z]*r|mkfs(\\.\\w+)?|dd\\s+if=|wipe(fs)?|fastboot\\s+erase|iptables\\s+-F|kill\\s+-9\\s+1)(\\s|$)|drop\\s+database",
        RegexOption.IGNORE_CASE
    )

    fun requiresConfirmation(command: String): Boolean = DANGEROUS.containsMatchIn(command)

    /**
     * Dispatches command to specified environment with live streaming and progress updates.
     */
    suspend fun executeTask(
        command: String,
        environment: TargetEnvironment = TargetEnvironment.ROOT_LINUX,
        onProgress: (String) -> Unit = {}
    ): LinuxTaskResult = withContext(Dispatchers.IO) {
        val cleanCmd = command.trim()
        val startTime = System.currentTimeMillis()

        onProgress("${environment.name} पर काम शुरू: $cleanCmd")
        _streamFlow.emit("[MAX-OS] Dispatching to ${environment.name}: $cleanCmd")

        when (environment) {
            TargetEnvironment.ROOT_LINUX -> {
                val res = RootCommandEngine.execute(cleanCmd)
                val duration = System.currentTimeMillis() - startTime
                val output = res.stdout.ifBlank { res.stderr }
                _streamFlow.emit(output)

                val summary = if (res.success) {
                    PersonalityEngine.formatCompletion("Linux command execution")
                } else {
                    PersonalityEngine.formatFailure("Linux command execution", res.stderr.take(80))
                }

                LinuxTaskResult(
                    success = res.success,
                    exitCode = res.exitCode,
                    output = res.stdout,
                    error = res.stderr,
                    environment = environment,
                    durationMs = duration,
                    spokenSummary = summary
                )
            }

            TargetEnvironment.TERMUX -> {
                val res = TermuxCommandEngine.execute(cleanCmd)
                val duration = System.currentTimeMillis() - startTime
                val output = res.output.ifBlank { res.error }
                _streamFlow.emit(output)

                val summary = if (res.success) {
                    PersonalityEngine.formatCompletion("Termux operation")
                } else {
                    PersonalityEngine.formatFailure("Termux operation", res.error.take(80))
                }

                LinuxTaskResult(
                    success = res.success,
                    exitCode = res.exitCode,
                    output = res.output,
                    error = res.error,
                    environment = environment,
                    durationMs = duration,
                    spokenSummary = summary
                )
            }

            TargetEnvironment.KALI_NETHUNTER -> {
                val parts = cleanCmd.split(" ", limit = 2)
                val tool = parts[0]
                val args = if (parts.size > 1) parts[1] else ""
                val res = KaliCommandEngine.execute(
                    tool = tool,
                    arguments = args,
                    onProgress = { onProgress(it) },
                    onOutputLine = { _streamFlow.tryEmit(it) }
                )
                val duration = System.currentTimeMillis() - startTime
                val output = res.output.ifBlank { res.error }
                _streamFlow.emit(output)

                val summary = if (res.success) {
                    PersonalityEngine.formatCompletion("Kali NetHunter security tool $tool")
                } else {
                    PersonalityEngine.formatFailure("Kali operation $tool", res.error.take(80))
                }

                LinuxTaskResult(
                    success = res.success,
                    exitCode = res.exitCode,
                    output = res.output,
                    error = res.error,
                    environment = environment,
                    durationMs = duration,
                    spokenSummary = summary
                )
            }
        }
    }
}

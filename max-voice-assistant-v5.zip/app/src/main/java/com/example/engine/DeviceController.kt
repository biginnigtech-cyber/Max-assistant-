package com.example.engine

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import com.example.utils.ShellQuote
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

object DeviceController {
    private const val TAG = "DeviceController"

    data class DeviceActionResult(
        val success: Boolean,
        val message: String,
        val details: List<String> = emptyList()
    )

    private var isTorchOn = false

    /** 0 = idle, 1 = ringing, 2 = in a call; null when it could not be read. */
    private suspend fun callState(): Int? {
        val out = RootCommandEngine.execute("dumpsys telephony.registry | grep mCallState").stdout
        val states = Regex("mCallState=(\\d)").findAll(out).map { it.groupValues[1].toInt() }.toList()
        if (states.isEmpty()) return null
        return states.maxOrNull()
    }

    /** Presses the phone's answer key through root, then checks the phone really went into the call. */
    suspend fun answerCall(): DeviceActionResult {
        if (callState() == 0) return DeviceActionResult(false, "अभी कोई कॉल बज नहीं रही।")
        RootCommandEngine.execute("input keyevent 5")
        delay(1200L)
        return if (callState() == 2) DeviceActionResult(true, "कॉल उठा ली है।")
        else DeviceActionResult(false, "कॉल उठाने की कोशिश की, पर फ़ोन कॉल में गया नहीं। आप स्क्रीन से उठा लीजिए।")
    }

    suspend fun rejectCall(): DeviceActionResult {
        if (callState() == 0) return DeviceActionResult(false, "अभी कोई कॉल बज नहीं रही।")
        RootCommandEngine.execute("input keyevent 6")
        delay(1000L)
        return if (callState() == 0) DeviceActionResult(true, "कॉल काट दी है।")
        else DeviceActionResult(false, "कॉल काटने की कोशिश की, पर वह अभी भी चल रही है।")
    }

    suspend fun openApp(context: Context, appNameOrPackage: String): DeviceActionResult = withContext(Dispatchers.IO) {
        val rawTarget = appNameOrPackage.trim()
        val target = rawTarget.lowercase()
        val pm = context.packageManager

        // 1. Direct package match
        var matchedPackage: String? = null
        if (target.contains(".")) {
            try {
                pm.getPackageInfo(rawTarget, 0)
                matchedPackage = rawTarget
            } catch (_: Exception) {
            }
        }

        // 2. Common application aliases dictionary
        if (matchedPackage == null) {
            matchedPackage = when (target) {
                "whatsapp", "व्हाट्सएप", "व्हाट्सऐप" -> "com.whatsapp"
                "spotify", "स्पॉटिफाई" -> "com.spotify.music"
                "youtube", "यूट्यूब" -> "com.google.android.youtube"
                "chrome", "browser", "क्रोम" -> "com.android.chrome"
                "camera", "कैमरा" -> "com.google.android.GoogleCamera"
                "settings", "सेटिंग्स" -> "com.android.settings"
                "termux", "टर्मक्स" -> "com.termux"
                "instagram", "इंस्टाग्राम" -> "com.instagram.android"
                "telegram", "टेलीग्राम" -> "org.telegram.messenger"
                "nethunter", "kali" -> "com.offsec.nethunter"
                "calculator", "कैलकुलेटर" -> "com.google.android.calculator"
                "gallery", "photos", "गैलरी" -> "com.google.android.apps.photos"
                "phone", "dialer", "फोन" -> "com.google.android.dialer"
                "messages", "sms" -> "com.google.android.apps.messaging"
                "gmail", "email" -> "com.google.android.gm"
                "clock", "alarm" -> "com.google.android.deskclock"
                "maps" -> "com.google.android.apps.maps"
                else -> null
            }
        }

        // 3. Search installed applications by label and package name
        if (matchedPackage == null) {
            try {
                val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                // Exact label match first
                for (app in installedApps) {
                    val label = pm.getApplicationLabel(app).toString().lowercase().trim()
                    if (label == target) {
                        matchedPackage = app.packageName
                        break
                    }
                }
                // Partial label match. An empty or tiny label ("", "X", "Go") used to match every request via
                // target.contains(label) and could open a random app, so short labels are ignored.
                if (matchedPackage == null && target.length >= 3) {
                    for (app in installedApps) {
                        val label = pm.getApplicationLabel(app).toString().lowercase().trim()
                        if (label.length < 3) continue
                        if (label.contains(target) || (label.length >= 4 && target.contains(label))) {
                            matchedPackage = app.packageName
                            break
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error querying installed applications: ${e.message}")
            }
        }

        if (matchedPackage != null) {
            try {
                val launchIntent = pm.getLaunchIntentForPackage(matchedPackage)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    context.startActivity(launchIntent)
                    Log.d(TAG, "Successfully launched $matchedPackage via packageManager launchIntent")
                    return@withContext DeviceActionResult(true, "Opened $rawTarget successfully.")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Standard launch failed for $matchedPackage: ${e.message}, attempting root launch")
            }

            // Fallback via root am start / monkey
            val rootRes = RootCommandEngine.execute("monkey -p $matchedPackage -c android.intent.category.LAUNCHER 1")
            if (rootRes.success) {
                return@withContext DeviceActionResult(true, "Launched $rawTarget via root.")
            }
            val amRes = RootCommandEngine.execute("cmd package compile -m speed $matchedPackage; am start $(cmd package resolve-activity --brief $matchedPackage | tail -n 1)")
            if (amRes.success) {
                return@withContext DeviceActionResult(true, "Launched $rawTarget.")
            }
        }

        DeviceActionResult(false, "Application '$rawTarget' is not installed or could not be launched on this device.")
    }

    private val PACKAGE_REGEX = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

    suspend fun closeApp(packageNameOrName: String, context: Context? = null): DeviceActionResult = withContext(Dispatchers.IO) {
        val target = packageNameOrName.trim()
        // Find the real package. Guessing "com.<name>" closed nothing for most apps, and the raw text went into a root shell.
        var pkg: String? = if (PACKAGE_REGEX.matches(target)) target else null
        if (pkg == null && context != null) {
            try {
                val pm = context.packageManager
                val lower = target.lowercase()
                pkg = pm.getInstalledApplications(PackageManager.GET_META_DATA).firstOrNull {
                    val label = pm.getApplicationLabel(it).toString().lowercase().trim()
                    label.isNotEmpty() && (label == lower || (lower.length >= 3 && label.length >= 3 && label.contains(lower)))
                }?.packageName
            } catch (e: Exception) {
                Log.w(TAG, "closeApp lookup failed: ${e.message}")
            }
        }
        if (pkg == null || !PACKAGE_REGEX.matches(pkg)) {
            return@withContext DeviceActionResult(false, "'$target' नाम का ऐप नहीं मिला, इसलिए कुछ बंद नहीं किया।")
        }
        val cmd = "am force-stop ${ShellQuote.q(pkg)}"
        val res = RootCommandEngine.execute(cmd)
        if (res.success) {
            DeviceActionResult(true, "Force-stopped $pkg successfully", listOf(cmd))
        } else {
            DeviceActionResult(false, "Failed to close $pkg: ${res.stderr}")
        }
    }

    suspend fun setVolume(context: Context, action: String, levelPercent: Int? = null): DeviceActionResult = withContext(Dispatchers.IO) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val maxVol = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15

        when (action.lowercase()) {
            "mute" -> {
                audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                RootCommandEngine.execute("cmd media_session volume --set 0 || cmd audio set-volume 3 0")
                DeviceActionResult(true, "Media volume muted.")
            }
            "max", "100" -> {
                audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, maxVol, AudioManager.FLAG_SHOW_UI)
                RootCommandEngine.execute("cmd media_session volume --set $maxVol || cmd audio set-volume 3 $maxVol")
                DeviceActionResult(true, "Volume set to maximum.")
            }
            "up" -> {
                // A real, noticeable step (about 20% of the range), not a single tick
                val step = maxOf(2, Math.round(maxVol * 0.2f))
                val cur = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
                audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, minOf(maxVol, cur + step), AudioManager.FLAG_SHOW_UI)
                DeviceActionResult(true, "Volume increased.")
            }
            "down" -> {
                val step = maxOf(2, Math.round(maxVol * 0.2f))
                val cur = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
                audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, maxOf(0, cur - step), AudioManager.FLAG_SHOW_UI)
                DeviceActionResult(true, "Volume decreased.")
            }
            "set" -> {
                if (levelPercent == null) return@withContext DeviceActionResult(false, "कितने प्रतिशत आवाज़ रखूँ, यह नहीं सुना।")
                val pct = levelPercent.coerceIn(0, 100)
                val targetVol = ((pct / 100f) * maxVol).toInt()
                audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, AudioManager.FLAG_SHOW_UI)
                RootCommandEngine.execute("cmd media_session volume --set $targetVol")
                DeviceActionResult(true, "Volume set to $pct%.")
            }
            else -> DeviceActionResult(false, "Unknown volume action: $action")
        }
    }

    suspend fun setBrightness(levelPercent: Int): DeviceActionResult = withContext(Dispatchers.IO) {
        val pct = levelPercent.coerceIn(0, 100)
        val value255 = ((pct / 100f) * 255).toInt().coerceIn(0, 255)
        val cmd = "settings put system screen_brightness $value255"
        val res = RootCommandEngine.execute(cmd)
        if (res.success) {
            DeviceActionResult(true, "Brightness adjusted to $pct%.")
        } else {
            DeviceActionResult(false, "Failed to adjust brightness: ${res.stderr}")
        }
    }

    suspend fun toggleFlashlight(context: Context, enable: Boolean? = null): DeviceActionResult = withContext(Dispatchers.IO) {
        val targetState = enable ?: !isTorchOn
        try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                try {
                    cameraManager.getCameraCharacteristics(id)
                        .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } catch (_: Exception) { false }
            }
            if (cameraManager != null && cameraId != null) {
                cameraManager.setTorchMode(cameraId, targetState)
                isTorchOn = targetState
                return@withContext DeviceActionResult(true, if (targetState) "Flashlight turned on." else "Flashlight turned off.")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Standard camera torch failed: ${e.message}. Using root fallback.")
        }

        // Root fallback via sysfs
        val valStr = if (targetState) "1" else "0"
        // Exit code is 0 only if at least one LED file was really written (before: always "success").
        val res = RootCommandEngine.execute(
            "c=0; for f in /sys/class/leds/*torch*/brightness /sys/class/leds/*flashlight*/brightness; do if [ -f \"\$f\" ]; then echo $valStr > \"\$f\"; c=1; fi; done; [ \$c -eq 1 ]"
        )
        if (res.success) isTorchOn = targetState
        DeviceActionResult(res.success, if (!res.success) "टॉर्च नहीं जल पाई, फ़ोन पर फ़्लैश की पहुँच नहीं मिली।" else if (targetState) "Flashlight turned on via root." else "Flashlight turned off via root.")
    }

    suspend fun toggleBluetooth(enable: Boolean): DeviceActionResult = withContext(Dispatchers.IO) {
        val cmd = if (enable) "cmd bluetooth enable || svc bluetooth enable" else "cmd bluetooth disable || svc bluetooth disable"
        val res = RootCommandEngine.execute(cmd)
        if (res.success) {
            DeviceActionResult(true, if (enable) "Bluetooth enabled." else "Bluetooth disabled.")
        } else {
            DeviceActionResult(false, "Failed to toggle Bluetooth: ${res.stderr}")
        }
    }

    suspend fun toggleWiFi(enable: Boolean): DeviceActionResult = withContext(Dispatchers.IO) {
        val cmd = if (enable) "svc wifi enable" else "svc wifi disable"
        val res = RootCommandEngine.execute(cmd)
        if (res.success) {
            DeviceActionResult(true, if (enable) "WiFi enabled." else "WiFi disabled.")
        } else {
            DeviceActionResult(false, "Failed to toggle WiFi: ${res.stderr}")
        }
    }

    suspend fun toggleBatterySaver(enable: Boolean): DeviceActionResult = withContext(Dispatchers.IO) {
        val valStr = if (enable) "1" else "0"
        val cmd = "settings put global low_power $valStr"
        val res = RootCommandEngine.execute(cmd)
        if (res.success) {
            DeviceActionResult(true, if (enable) "Battery saver enabled." else "Battery saver disabled.")
        } else {
            DeviceActionResult(false, "Failed to toggle Battery Saver: ${res.stderr}")
        }
    }

    suspend fun takeScreenshot(): DeviceActionResult = withContext(Dispatchers.IO) {
        val ts = System.currentTimeMillis()
        val dir = "/sdcard/Pictures/Screenshots"
        val path = "$dir/screenshot_$ts.png"
        val cmd = "mkdir -p $dir && screencap -p $path"
        val res = RootCommandEngine.execute(cmd)
        if (res.success) {
            DeviceActionResult(true, "Screenshot captured and saved to $path", listOf(path))
        } else {
            DeviceActionResult(false, "Failed to capture screenshot: ${res.stderr}")
        }
    }

    suspend fun recordScreen(seconds: Int = 15): DeviceActionResult = withContext(Dispatchers.IO) {
        val ts = System.currentTimeMillis()
        val dir = "/sdcard/Movies"
        val path = "$dir/screenrecord_$ts.mp4"
        val safeSec = seconds.coerceIn(5, 60)
        val cmd = "mkdir -p $dir && screenrecord --time-limit $safeSec $path &"
        val res = RootCommandEngine.execute(cmd)
        if (res.success) {
            DeviceActionResult(true, "Screen recording started for $safeSec seconds: $path")
        } else {
            DeviceActionResult(false, "Failed to start screen recording: ${res.stderr}")
        }
    }

    suspend fun rebootDevice(): DeviceActionResult = withContext(Dispatchers.IO) {
        Log.w(TAG, "Executing confirmed device reboot...")
        val res = RootCommandEngine.execute("svc power reboot || reboot")
        DeviceActionResult(res.success, "Reboot command dispatched.")
    }

    suspend fun rebootRecovery(): DeviceActionResult = withContext(Dispatchers.IO) {
        Log.w(TAG, "Executing confirmed reboot to recovery...")
        val res = RootCommandEngine.execute("reboot recovery")
        DeviceActionResult(res.success, "Rebooting to recovery mode.")
    }

    suspend fun rebootBootloader(): DeviceActionResult = withContext(Dispatchers.IO) {
        Log.w(TAG, "Executing confirmed reboot to bootloader/fastboot...")
        val res = RootCommandEngine.execute("reboot bootloader")
        DeviceActionResult(res.success, "Rebooting to bootloader mode.")
    }

    suspend fun toggleHotspot(enable: Boolean): DeviceActionResult = withContext(Dispatchers.IO) {
        val cmd = if (enable) {
            "cmd connectivity tether start-tethering wifi || svc wifi tether enable"
        } else {
            "cmd connectivity tether stop-tethering wifi || svc wifi tether disable"
        }
        val res = RootCommandEngine.execute(cmd)
        DeviceActionResult(res.success, if (enable) "Hotspot enabled." else "Hotspot disabled.")
    }

    suspend fun toggleAutoRotation(enable: Boolean): DeviceActionResult = withContext(Dispatchers.IO) {
        val valStr = if (enable) "1" else "0"
        val cmd = "settings put system accelerometer_rotation $valStr"
        val res = RootCommandEngine.execute(cmd)
        DeviceActionResult(res.success, if (enable) "Auto-rotation enabled." else "Auto-rotation disabled.")
    }

    suspend fun launchSplitScreen(): DeviceActionResult = withContext(Dispatchers.IO) {
        // App switch + split screen key event
        val res = RootCommandEngine.execute("input keyevent --longpress 187 || cmd window split-screen")
        DeviceActionResult(res.success, "Split screen invoked.")
    }

    suspend fun launchFloatingWindow(packageName: String): DeviceActionResult = withContext(Dispatchers.IO) {
        val cleanPkg = packageName.trim()
        if (!PACKAGE_REGEX.matches(cleanPkg)) return@withContext DeviceActionResult(false, "यह ऐप का सही पैकेज नाम नहीं है।")
        // Windowing mode 5 represents freeform / floating window on Android
        val cmd = "settings put global enable_freeform_support 1 && am start --windowingMode 5 \$(pm dump $cleanPkg | grep -A 1 'MAIN' | grep '/' | head -n 1 | awk '{print \$2}')"
        val res = RootCommandEngine.execute(cmd)
        DeviceActionResult(res.success, "Floating window launched for $cleanPkg.")
    }

    data class SystemMetrics(
        val batteryPct: Int,
        val isCharging: Boolean,
        val cpuUsagePercent: Int,
        val ramUsedMb: Long,
        val ramTotalMb: Long,
        val storageFreeGb: Double,
        val storageTotalGb: Double,
        val thermalTempCelsius: Float,
        val summaryHindi: String
    )

    suspend fun getSystemMetrics(context: Context): SystemMetrics = withContext(Dispatchers.IO) {
        // 1. Battery
        var batPct = -1
        var isCharging = false
        try {
            val ifilter = android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val bIntent = context.registerReceiver(null, ifilter)
            val level = bIntent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bIntent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
            batPct = if (level >= 0 && scale > 0) ((level / scale.toFloat()) * 100).toInt() else level
            val status = bIntent?.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1) ?: -1
            isCharging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING || status == android.os.BatteryManager.BATTERY_STATUS_FULL
        } catch (_: Exception) {}

        // 2. RAM via ActivityManager
        var ramUsed = 0L
        var ramTotal = 0L
        try {
            val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
            val memInfo = android.app.ActivityManager.MemoryInfo()
            actManager?.getMemoryInfo(memInfo)
            ramTotal = memInfo.totalMem / (1024 * 1024)
            ramUsed = (memInfo.totalMem - memInfo.availMem) / (1024 * 1024)
        } catch (_: Exception) {}

        // 3. Storage
        var storageFreeGb = 0.0
        var storageTotalGb = 0.0
        try {
            val stat = android.os.StatFs(android.os.Environment.getDataDirectory().path)
            val bytesAvailable = stat.availableBlocksLong * stat.blockSizeLong
            val bytesTotal = stat.blockCountLong * stat.blockSizeLong
            storageFreeGb = String.format(java.util.Locale.US, "%.1f", bytesAvailable / (1024.0 * 1024 * 1024)).toDoubleOrNull() ?: 0.0
            storageTotalGb = String.format(java.util.Locale.US, "%.1f", bytesTotal / (1024.0 * 1024 * 1024)).toDoubleOrNull() ?: 0.0
        } catch (_: Exception) {}

        // 4. CPU and Thermal via root / sysfs
        var cpuUsage = 15
        var thermalCelsius = 36.0f
        try {
            val thermalRes = RootCommandEngine.execute("cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null | head -n 1")
            if (thermalRes.success && thermalRes.stdout.isNotBlank()) {
                val rawTemp = thermalRes.stdout.trim().toFloatOrNull()
                if (rawTemp != null) {
                    thermalCelsius = if (rawTemp > 1000) rawTemp / 1000f else rawTemp
                }
            }
            val cpuRes = RootCommandEngine.execute("dumpsys cpuinfo | grep 'TOTAL' | awk '{print \$1}' | tr -d '%'")
            if (cpuRes.success && cpuRes.stdout.isNotBlank()) {
                val parsed = cpuRes.stdout.trim().lines().firstOrNull()?.toFloatOrNull()?.toInt()
                if (parsed != null && parsed in 0..100) cpuUsage = parsed
            }
        } catch (_: Exception) {}

        val summary = "बैटरी $batPct% ${if (isCharging) "(चार्जिंग)" else ""}, रैम ${ramUsed}MB/${ramTotal}MB, स्टोरेज ${storageFreeGb}GB खाली, और तापमान ${thermalCelsius.toInt()}°C है।"

        SystemMetrics(
            batteryPct = batPct,
            isCharging = isCharging,
            cpuUsagePercent = cpuUsage,
            ramUsedMb = ramUsed,
            ramTotalMb = ramTotal,
            storageFreeGb = storageFreeGb,
            storageTotalGb = storageTotalGb,
            thermalTempCelsius = thermalCelsius,
            summaryHindi = summary
        )
    }
}

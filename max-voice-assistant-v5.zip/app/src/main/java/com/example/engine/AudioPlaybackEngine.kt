package com.example.engine

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.KeyEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.URLEncoder

/**
 * Robust audio and music playback automation for Spotify and default local music player.
 *
 * Uses:
 * 1. Spotify URI direct intents (spotify:search:<query>)
 * 2. MediaStore Search Intent (android.media.action.MEDIA_SEARCH)
 * 3. Media playback key events (KEYCODE_MEDIA_PLAY)
 * 4. Fallback to package launching with query
 *
 * Returns truthful success/failure status.
 */
object AudioPlaybackEngine {
    private const val TAG = "AudioPlaybackEngine"
    private const val SPOTIFY_PACKAGE = "com.spotify.music"

    data class PlaybackResult(
        val success: Boolean,
        val message: String,
        val appUsed: String
    )

    /**
     * Plays track on Spotify or local media player.
     */
    suspend fun playTrack(
        context: Context,
        query: String,
        targetApp: String = "spotify"
    ): PlaybackResult = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim()
        val app = targetApp.lowercase().trim()

        if (app.contains("youtube")) {
            val yt = YouTubeAIEngine.playVideo(context, cleanQuery)
            return@withContext PlaybackResult(yt.success, yt.message, "YouTube")
        } else if (app.contains("spotify")) {
            return@withContext playOnSpotify(context, cleanQuery)
        } else {
            return@withContext playOnDefaultMusicPlayer(context, cleanQuery)
        }
    }

    private suspend fun playOnSpotify(context: Context, query: String): PlaybackResult {
        val pm = context.packageManager
        val isSpotifyInstalled = try {
            pm.getPackageInfo(SPOTIFY_PACKAGE, 0)
            true
        } catch (_: Exception) {
            false
        }

        if (!isSpotifyInstalled) {
            Log.w(TAG, "Spotify app is not installed. Attempting default media search intent.")
            return playOnDefaultMusicPlayer(context, query)
        }

        try {
            // Method 1: Spotify Search & Play intent with extras
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val mediaSearchIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                setPackage(SPOTIFY_PACKAGE)
                putExtra(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE)
                putExtra(SearchManager.QUERY, query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            if (mediaSearchIntent.resolveActivity(pm) != null) {
                context.startActivity(mediaSearchIntent)
                Log.d(TAG, "Dispatched MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH to Spotify for '$query'")
                delay(1200L)
                val playing = startAndVerify(context)
                return PlaybackResult(
                    success = playing,
                    message = if (playing) "$query Spotify पर चल रहा है।" else "Spotify खुल गया और '$query' खोज लिया, पर गाना शुरू नहीं हुआ। एक बार स्क्रीन से प्ले दबा दीजिए।",
                    appUsed = "Spotify"
                )
            }

            // Method 2: Spotify URI search
            val spotifyUri = Uri.parse("spotify:search:$encodedQuery")
            val viewIntent = Intent(Intent.ACTION_VIEW, spotifyUri).apply {
                setPackage(SPOTIFY_PACKAGE)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
            Log.d(TAG, "Dispatched ACTION_VIEW spotify:search URI for '$query'")
            delay(1500L)
            val playing = startAndVerify(context)

            return PlaybackResult(
                success = playing,
                message = if (playing) "$query Spotify पर चल रहा है।" else "Spotify पर '$query' खुल गया, पर गाना शुरू नहीं हुआ। एक बार स्क्रीन से प्ले दबा दीजिए।",
                appUsed = "Spotify"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch Spotify: ${e.message}", e)
            return PlaybackResult(
                success = false,
                message = "Spotify पर $query नहीं चल पाया।",
                appUsed = "Spotify"
            )
        }
    }

    private suspend fun playOnDefaultMusicPlayer(context: Context, query: String): PlaybackResult {
        try {
            val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                putExtra(SearchManager.QUERY, query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val pm = context.packageManager
            if (intent.resolveActivity(pm) != null) {
                context.startActivity(intent)
                delay(1000L)
                val playing = startAndVerify(context)
                return PlaybackResult(
                    success = playing,
                    message = if (playing) "$query म्यूज़िक प्लेयर पर चल रहा है।" else "म्यूज़िक प्लेयर खुल गया, पर '$query' शुरू नहीं हुआ।",
                    appUsed = "Default Music Player"
                )
            }

            // Fallback: Launch generic music intent
            val musicIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_APP_MUSIC)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (musicIntent.resolveActivity(pm) != null) {
                context.startActivity(musicIntent)
                delay(1000L)
                val playing = startAndVerify(context)
                return PlaybackResult(
                    success = playing,
                    message = if (playing) "म्यूज़िक प्लेयर पर संगीत चल रहा है।" else "म्यूज़िक प्लेयर खुल गया, पर '$query' शुरू नहीं हुआ।",
                    appUsed = "Music Player"
                )
            }

            return PlaybackResult(
                success = false,
                message = "फ़ोन में कोई म्यूज़िक या ऑडियो प्लेयर ऐप नहीं मिला।",
                appUsed = "None"
            )
        } catch (e: Exception) {
            return PlaybackResult(
                success = false,
                message = "संगीत चल नहीं पाया।",
                appUsed = "Music Player"
            )
        }
    }

    /** True only when audio is really playing. "I sent the intent" is not the same as "it plays". */
    private suspend fun waitAudible(context: Context, timeoutMs: Long = 4500L): Boolean {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (am.isMusicActive) return true
            delay(300L)
        }
        return am.isMusicActive
    }

    /** Sent through the system and, if nothing plays, again through root (works even when no media session is active). */
    private suspend fun startAndVerify(context: Context): Boolean {
        sendMediaPlayKeyEvent(context)
        if (waitAudible(context, 3000L)) return true
        RootCommandEngine.execute("input keyevent 126")
        if (waitAudible(context, 3000L)) return true
        RootCommandEngine.execute("cmd media_session dispatch play")
        return waitAudible(context, 2500L)
    }

    private fun sendMediaPlayKeyEvent(context: Context) {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            val eventDown = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY)
            val eventUp = KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY)
            audioManager.dispatchMediaKeyEvent(eventDown)
            audioManager.dispatchMediaKeyEvent(eventUp)
        } catch (e: Exception) {
            Log.w(TAG, "Could not dispatch media play key event: ${e.message}")
        }
    }
}

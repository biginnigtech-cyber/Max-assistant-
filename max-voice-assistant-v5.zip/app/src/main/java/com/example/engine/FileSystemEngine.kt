package com.example.engine

import android.app.DownloadManager
import android.content.Context
import android.database.Cursor
import android.util.Log
import com.example.brain.PersonalityEngine
import com.example.utils.ShellQuote
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * FileSystemEngine (MAX AI OS)
 *
 * Capabilities:
 * - Search files across internal storage or root paths.
 * - Move, rename, copy files.
 * - Delete files (sensitive action requiring user confirmation).
 * - Compress files/directories to ZIP.
 * - Extract ZIP archives.
 * - Android DownloadManager integration.
 */
object FileSystemEngine {
    private const val TAG = "FileSystemEngine"

    data class FileSearchResult(
        val path: String,
        val name: String,
        val sizeBytes: Long,
        val isDirectory: Boolean
    )

    data class FileActionResult(
        val success: Boolean,
        val message: String,
        val spokenResponse: String
    )

    suspend fun searchFiles(
        query: String,
        searchRoot: String = "/sdcard",
        maxResults: Int = 20
    ): List<FileSearchResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<FileSearchResult>()
        try {
            // First attempt using fast find via root shell
            val safeQuery = query.replace(Regex("[*?\\[\\]]"), "")
            val rootCmd = "find ${ShellQuote.q(searchRoot)} -iname ${ShellQuote.q("*$safeQuery*")} 2>/dev/null | head -n ${maxResults.coerceIn(1, 100)}"
            val res = RootCommandEngine.execute(rootCmd)
            if (res.success && res.stdout.isNotBlank()) {
                res.stdout.lines().filter { it.isNotBlank() }.forEach { path ->
                    val f = File(path)
                    results.add(FileSearchResult(path, f.name, if (f.isFile) f.length() else 0L, f.isDirectory))
                }
                return@withContext results
            }
        } catch (e: Exception) {
            Log.w(TAG, "Root find failed: ${e.message}, falling back to Java File recursion.")
        }

        // Java File traversal fallback
        val root = File(searchRoot)
        if (root.exists() && root.canRead()) {
            searchRecursive(root, query.lowercase(), results, maxResults, 0)
        }
        results
    }

    private fun searchRecursive(
        dir: File,
        query: String,
        results: MutableList<FileSearchResult>,
        maxResults: Int,
        depth: Int
    ) {
        if (results.size >= maxResults || depth > 12) return
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (results.size >= maxResults) return
            if (f.name.lowercase().contains(query)) {
                results.add(FileSearchResult(f.absolutePath, f.name, if (f.isFile) f.length() else 0L, f.isDirectory))
            }
            if (f.isDirectory && !f.name.startsWith(".")) {
                searchRecursive(f, query, results, maxResults, depth + 1)
            }
        }
    }

    suspend fun moveFile(sourcePath: String, destPath: String): FileActionResult = withContext(Dispatchers.IO) {
        if (ShellQuote.isProtectedPath(sourcePath) || ShellQuote.isProtectedPath(destPath)) {
            val refuse = "यह रास्ता सिस्टम के लिए ज़रूरी है, इसे मैं नहीं हिलाऊँगा।"
            return@withContext FileActionResult(false, refuse, refuse)
        }
        val src = File(sourcePath)
        val dst = File(destPath)
        val ok = src.renameTo(dst) || RootCommandEngine.execute("mv ${ShellQuote.q(sourcePath)} ${ShellQuote.q(destPath)}").success
        val msg = if (ok) "फ़ाइल $destPath पर भेज दी गई है।" else "$sourcePath को हिला नहीं पाया।"
        FileActionResult(ok, msg, msg)
    }

    suspend fun renameFile(filePath: String, newName: String): FileActionResult = withContext(Dispatchers.IO) {
        val cleanName = ShellQuote.safeFileName(newName)
        if (cleanName.isBlank() || ShellQuote.isProtectedPath(filePath)) {
            val refuse = "इस नाम या रास्ते से फ़ाइल का नाम नहीं बदल सकता।"
            return@withContext FileActionResult(false, refuse, refuse)
        }
        val src = File(filePath)
        val dst = File(src.parentFile, cleanName)
        val ok = src.renameTo(dst) || RootCommandEngine.execute("mv ${ShellQuote.q(filePath)} ${ShellQuote.q(dst.absolutePath)}").success
        val msg = if (ok) "फ़ाइल का नाम बदलकर $cleanName कर दिया है।" else "फ़ाइल का नाम नहीं बदल पाया।"
        FileActionResult(ok, msg, msg)
    }

    suspend fun copyFile(sourcePath: String, destPath: String): FileActionResult = withContext(Dispatchers.IO) {
        if (ShellQuote.isProtectedPath(destPath)) {
            val refuse = "इस जगह पर कॉपी नहीं कर सकता, यह सिस्टम का रास्ता है।"
            return@withContext FileActionResult(false, refuse, refuse)
        }
        val ok = RootCommandEngine.execute("cp -r ${ShellQuote.q(sourcePath)} ${ShellQuote.q(destPath)}").success
        val msg = if (ok) "फ़ाइल $destPath पर कॉपी हो गई है।" else "फ़ाइल कॉपी नहीं हो पाई।"
        FileActionResult(ok, msg, msg)
    }

    suspend fun deleteFile(filePath: String): FileActionResult = withContext(Dispatchers.IO) {
        // Never delete the storage root, system folders or anything with ".." in it, whatever was asked.
        if (ShellQuote.isProtectedPath(filePath)) {
            val refuse = "यह रास्ता सिस्टम या पूरी स्टोरेज का है, इसलिए मैं इसे नहीं मिटाऊँगा। किसी ख़ास फ़ाइल या फ़ोल्डर का नाम बताइए।"
            return@withContext FileActionResult(false, refuse, refuse)
        }
        val f = File(filePath)
        val ok = (f.exists() && f.delete()) || RootCommandEngine.execute("rm -rf ${ShellQuote.q(filePath)}").success
        val msg = if (ok) "$filePath मिटा दिया है।" else "$filePath को मिटा नहीं पाया।"
        FileActionResult(ok, msg, msg)
    }

    suspend fun compressToZip(sourcePath: String, zipPath: String): FileActionResult = withContext(Dispatchers.IO) {
        try {
            val src = File(sourcePath)
            val zip = File(zipPath)
            zip.parentFile?.mkdirs()

            ZipOutputStream(FileOutputStream(zip)).use { zos ->
                if (src.isDirectory) {
                    compressDirectory(src, src, zos)
                } else {
                    FileInputStream(src).use { fis ->
                        zos.putNextEntry(ZipEntry(src.name))
                        fis.copyTo(zos)
                        zos.closeEntry()
                    }
                }
            }
            FileActionResult(true, "Compressed to $zipPath", "ज़िप फ़ाइल $zipPath पर बन गई है।")
        } catch (e: Exception) {
            Log.e(TAG, "Compression error: ${e.message}")
            // Root fallback
            val rootRes = RootCommandEngine.execute("zip -r ${ShellQuote.q(zipPath)} ${ShellQuote.q(sourcePath)}")
            val msg = if (rootRes.success) "ज़िप फ़ाइल $zipPath पर बन गई है।" else "ज़िप नहीं बन पाई: ${e.message}"
            FileActionResult(rootRes.success, msg, msg)
        }
    }

    private fun compressDirectory(root: File, source: File, zos: ZipOutputStream) {
        val files = source.listFiles() ?: return
        for (f in files) {
            if (f.isDirectory) {
                compressDirectory(root, f, zos)
            } else {
                val relativePath = root.toURI().relativize(f.toURI()).path
                zos.putNextEntry(ZipEntry(relativePath))
                FileInputStream(f).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    suspend fun extractZip(zipPath: String, destDirPath: String): FileActionResult = withContext(Dispatchers.IO) {
        try {
            val destDir = File(destDirPath)
            destDir.mkdirs()
            val destCanonical = destDir.canonicalPath
            ZipInputStream(FileInputStream(zipPath)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val newFile = File(destDir, entry.name)
                    // Zip-slip guard: an entry named "../../x" must not escape the destination folder.
                    if (!newFile.canonicalPath.startsWith(destCanonical + File.separator) && newFile.canonicalPath != destCanonical) {
                        throw SecurityException("Blocked unsafe path inside the archive: ${entry.name}")
                    }
                    if (entry.isDirectory) {
                        newFile.mkdirs()
                    } else {
                        newFile.parentFile?.mkdirs()
                        FileOutputStream(newFile).use { fos -> zis.copyTo(fos) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            FileActionResult(true, "Extracted to $destDirPath", "ज़िप फ़ाइल $destDirPath में खोल दी गई है।")
        } catch (e: Exception) {
            Log.e(TAG, "Extraction error: ${e.message}")
            if (e is SecurityException) {
                val blocked = "इस ज़िप में असुरक्षित रास्ते थे (बाहर लिखने की कोशिश), इसलिए मैंने इसे नहीं खोला।"
                return@withContext FileActionResult(false, blocked, blocked)
            }
            val rootRes = RootCommandEngine.execute("unzip -o ${ShellQuote.q(zipPath)} -d ${ShellQuote.q(destDirPath)}")
            val msg = if (rootRes.success) "ज़िप फ़ाइल $destDirPath में खोल दी गई है।" else "ज़िप खुल नहीं पाई: ${e.message}"
            FileActionResult(rootRes.success, msg, msg)
        }
    }

    suspend fun getRecentDownloads(context: Context, limit: Int = 5): List<String> = withContext(Dispatchers.IO) {
        val list = mutableListOf<String>()
        try {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager ?: return@withContext list
            val query = DownloadManager.Query()
            val cursor: Cursor? = dm.query(query)
            cursor?.use {
                val titleIdx = it.getColumnIndex(DownloadManager.COLUMN_TITLE)
                val statusIdx = it.getColumnIndex(DownloadManager.COLUMN_STATUS)
                while (it.moveToNext() && list.size < limit) {
                    val title = if (titleIdx >= 0) it.getString(titleIdx) else "File"
                    val status = if (statusIdx >= 0) it.getInt(statusIdx) else 0
                    if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        list.add(title)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying downloads: ${e.message}")
        }
        list
    }
}

package com.example.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.receiver.AutomationReceiver
import com.example.service.MaxNotificationListenerService
import com.example.service.MaxVoiceService
import com.example.utils.PreferencesManager
import com.example.utils.ShellQuote
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * On a rooted phone MAX gives itself everything it needs, so the user never has to walk through Settings:
 *  - runtime permissions (microphone, contacts, call log for caller names, SMS, location for weather, notifications),
 *  - access to notifications (the listener that announces calls and messages),
 *  - exemption from battery optimisation and background limits (so it keeps listening and the automations keep running),
 *  - exact alarms for the automations.
 * Every step is optional and safe to repeat; a refusal on one phone never stops the others.
 */
object RootSetup {

    private const val TAG = "RootSetup"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var running = false

    private val PERMISSIONS = listOf(
        "android.permission.RECORD_AUDIO", "android.permission.READ_CONTACTS", "android.permission.READ_CALL_LOG",
        "android.permission.READ_PHONE_STATE", "android.permission.RECEIVE_SMS", "android.permission.READ_SMS",
        "android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION", "android.permission.POST_NOTIFICATIONS",
        "android.permission.CAMERA"
    )

    /** Commands for [pkg], built in one place so they can be unit-tested. */
    fun commandsFor(pkg: String, listenerComponent: String): List<String> {
        val p = ShellQuote.q(pkg)
        return buildList {
            PERMISSIONS.forEach { add("pm grant $p $it") }
            add("cmd notification allow_listener ${ShellQuote.q(listenerComponent)}")
            add("dumpsys deviceidle whitelist +$pkg")
            // Android 11 only lets the microphone be used "while in use". "allow" lifts that, so "Hey MAX" still works with the app closed.
            add("cmd appops set $p RECORD_AUDIO allow")
            add("cmd appops set $p CAMERA allow")
            add("cmd appops set $p RUN_ANY_IN_BACKGROUND allow")
            add("cmd appops set $p RUN_IN_BACKGROUND allow")
            add("cmd appops set $p SCHEDULE_EXACT_ALARM allow")
        }
    }

    const val ACTION_KEEPALIVE = "com.example.MAX_KEEPALIVE"
    private const val BOOT_SCRIPT = "/data/adb/service.d/max_assistant.sh"
    private const val KEEPALIVE_MS = 10 * 60 * 1000L

    /** Root command that starts the listening service (works even when the app was force-stopped; no Activity needed). */
    fun startCommand(component: String): String =
        "am start-foreground-service --user 0 -n ${ShellQuote.q(component)} -a ${ShellQuote.q(MaxVoiceService.ACTION_START)}"

    /** Magisk / KernelSU run every script in service.d at boot, as root, before the user unlocks the phone. */
    fun bootScript(component: String): String = """
        #!/system/bin/sh
        # Written by MAX: starts the voice assistant after every boot so "Hey MAX" works without opening the app.
        until [ "${'$'}(getprop sys.boot_completed)" = "1" ]; do sleep 5; done
        sleep 20
        ${startCommand(component)}
    """.trimIndent() + "\n"

    private fun keepAliveIntent(context: Context) =
        PendingIntent.getBroadcast(
            context, 7711, Intent(context, AutomationReceiver::class.java).setAction(ACTION_KEEPALIVE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** Checks every ~10 minutes that the listening service is alive and starts it again if the system killed it. */
    fun scheduleKeepAlive(context: Context) {
        if (!PreferencesManager.isAlwaysOn(context)) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = System.currentTimeMillis() + KEEPALIVE_MS
        try {
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, keepAliveIntent(context))
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, keepAliveIntent(context))
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, keepAliveIntent(context))
        }
    }

    /** Starts the listening service now (from a receiver or after being swiped away). Root first, normal start as the fallback. */
    fun startListeningService(context: Context) {
        if (!PreferencesManager.isAlwaysOn(context)) return
        val app = context.applicationContext
        scope.launch {
            val component = ComponentName(app, MaxVoiceService::class.java).flattenToString()
            val viaRoot = RootCommandEngine.isRootAvailable() && RootCommandEngine.execute(startCommand(component)).success
            if (!viaRoot) {
                try {
                    val i = Intent(app, MaxVoiceService::class.java).setAction(MaxVoiceService.ACTION_START)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) app.startForegroundService(i) else app.startService(i)
                } catch (e: Exception) {
                    Log.w(TAG, "Could not start the listening service: ${e.message}")
                }
            }
        }
    }

    /** Tells the Magisk module (its watchdog) that the user stopped MAX on purpose, or started it again. */
    fun markStopped(stopped: Boolean) {
        scope.launch {
            if (RootCommandEngine.isRootAvailable()) {
                RootCommandEngine.execute(if (stopped) "touch /data/adb/max_assistant_stopped" else "rm -f /data/adb/max_assistant_stopped")
            }
        }
    }

    fun restartSoon(context: Context) {
        val app = context.applicationContext
        scope.launch { delay(1500L); startListeningService(app) }
    }

    fun run(context: Context) {
        if (running) return
        running = true
        val app = context.applicationContext
        scope.launch {
            try {
                if (!RootCommandEngine.isRootAvailable()) return@launch
                val listener = ComponentName(app, MaxNotificationListenerService::class.java).flattenToString()
                var failed = 0
                for (cmd in commandsFor(app.packageName, listener)) {
                    if (!RootCommandEngine.execute(cmd).success) failed++
                }
                Log.i(TAG, "Root setup done ($failed command(s) not accepted on this phone)")
                // Start by itself after every boot (needs a Magisk / KernelSU service.d folder; otherwise the BOOT_COMPLETED receiver does it).
                if (PreferencesManager.isAlwaysOn(app)) {
                    val component = ComponentName(app, MaxVoiceService::class.java).flattenToString()
                    RootCommandEngine.execute(
                        "[ -d /data/adb/service.d ] && [ ! -d /data/adb/modules/max_assistant ] && printf %s ${ShellQuote.q(bootScript(component))} > ${ShellQuote.q(BOOT_SCRIPT)} && chmod 755 ${ShellQuote.q(BOOT_SCRIPT)}"
                    )
                    scheduleKeepAlive(app)
                } else {
                    RootCommandEngine.execute("rm -f ${ShellQuote.q(BOOT_SCRIPT)}")
                }
                AccessibilityBootstrap.ensure(app)
            } catch (e: Exception) {
                Log.w(TAG, "Root setup failed: ${e.message}")
            } finally {
                running = false
            }
        }
    }
}

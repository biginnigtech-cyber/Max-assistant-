package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import androidx.core.content.ContextCompat
import com.example.utils.ShellQuote
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Takes a real photo with no camera app, no screen and no accessibility service: Camera2 opens the chosen camera, lets exposure and focus
 * settle, takes the picture, and root puts the file in DCIM/Camera so it shows up in the gallery. The camera permission is given through root.
 */
object CameraCapture {

    private const val TAG = "CameraCapture"

    data class Result(val success: Boolean, val files: List<String>, val facing: String, val detail: String)

    /** One file name per second, sortable, like a normal camera app. Pure: unit-tested. */
    fun fileName(nowMs: Long, index: Int = 0): String =
        "MAX_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(nowMs)) + (if (index > 0) "_$index" else "") + ".jpg"

    /** "front" or "back" from whatever Gemini wrote; null when it was not said. */
    fun parseFacing(raw: String?): String? {
        val f = (raw ?: "").trim().lowercase()
        return when {
            f.isEmpty() -> null
            f.contains("front") || f.contains("selfie") || f.contains("सेल्फी") || f.contains("आगे") -> "front"
            f.contains("back") || f.contains("rear") || f.contains("पीछे") || f.contains("main") -> "back"
            else -> null
        }
    }

    private suspend fun ensureCameraAccess(context: Context): Boolean {
        fun granted() = ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (!granted() && RootCommandEngine.isRootAvailable()) {
            RootCommandEngine.execute("pm grant ${context.packageName} android.permission.CAMERA")
        }
        // Android 11 only allows the camera "while in use": allow it for the background service too.
        if (RootCommandEngine.isRootAvailable()) RootCommandEngine.execute("cmd appops set ${context.packageName} CAMERA allow")
        return granted()
    }

    suspend fun takePhotos(context: Context, facing: String, count: Int = 1): Result = withContext(Dispatchers.Default) {
        if (!ensureCameraAccess(context)) return@withContext Result(false, emptyList(), facing, "camera permission not granted")
        val saved = mutableListOf<String>()
        var lastError = ""
        repeat(count.coerceIn(1, 5)) { i ->
            val bytes = shoot(context, facing == "front")
            if (bytes == null) {
                lastError = "the camera did not deliver a picture"
            } else {
                val name = fileName(System.currentTimeMillis(), i)
                val tmp = File(context.cacheDir, name)
                try {
                    tmp.writeBytes(bytes)
                    val dest = "/sdcard/DCIM/Camera/$name"
                    val cp = RootCommandEngine.execute(
                        "mkdir -p /sdcard/DCIM/Camera; cp ${ShellQuote.q(tmp.absolutePath)} ${ShellQuote.q(dest)}; chmod 666 ${ShellQuote.q(dest)}; " +
                            "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d ${ShellQuote.q("file://$dest")} >/dev/null 2>&1"
                    )
                    if (cp.success) saved.add(dest) else lastError = "could not save the picture to the gallery folder"
                } catch (e: Exception) {
                    lastError = "could not save the picture: ${e.message}"
                } finally {
                    try { tmp.delete() } catch (_: Exception) {}
                }
            }
            if (i < count - 1) delay(900L)
        }
        Result(saved.isNotEmpty(), saved, facing, if (saved.isEmpty()) lastError else "saved ${saved.size}")
    }

    @SuppressLint("MissingPermission")
    private suspend fun shoot(context: Context, front: Boolean): ByteArray? {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val wanted = if (front) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
        val id = try {
            manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == wanted }
        } catch (e: Exception) { null } ?: return null
        val chars = manager.getCameraCharacteristics(id)
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return null
        val size = map.getOutputSizes(ImageFormat.JPEG).filter { it.width * it.height <= 12_000_000 }
            .maxByOrNull { it.width * it.height } ?: return null
        val previewSize = map.getOutputSizes(SurfaceTexture::class.java).minByOrNull { Math.abs(it.width * it.height - 640 * 480) }
        val orientation = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90   // phone held upright

        val thread = HandlerThread("MaxCamera").also { it.start() }
        val handler = Handler(thread.looper)
        val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 2)
        val texture = SurfaceTexture(10).also { if (previewSize != null) it.setDefaultBufferSize(previewSize.width, previewSize.height) }
        val previewSurface = Surface(texture)
        val result = CompletableDeferred<ByteArray?>()
        var device: CameraDevice? = null
        var session: CameraCaptureSession? = null

        reader.setOnImageAvailableListener({ r ->
            try {
                val img = r.acquireLatestImage()
                if (img != null) {
                    try {
                        val buf = img.planes[0].buffer
                        val b = ByteArray(buf.remaining()); buf.get(b)
                        result.complete(b)
                    } finally {
                        img.close()
                    }
                }
            } catch (e: Exception) { result.complete(null) }
        }, handler)

        try {
            manager.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    device = d
                    try {
                        @Suppress("DEPRECATION")
                        d.createCaptureSession(listOf(previewSurface, reader.surface), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                session = s
                                try {
                                    val preview = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                                        addTarget(previewSurface)
                                        set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                                        set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                                    }
                                    s.setRepeatingRequest(preview.build(), null, handler)
                                    // Let exposure and focus settle before the shot, otherwise the picture is dark or blurred.
                                    handler.postDelayed({
                                        try {
                                            val still = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                                                addTarget(reader.surface)
                                                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                                                set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                                                set(CaptureRequest.JPEG_ORIENTATION, orientation)
                                                set(CaptureRequest.JPEG_QUALITY, 95.toByte())
                                            }
                                            s.capture(still.build(), null, handler)
                                        } catch (e: Exception) { Log.w(TAG, "capture failed: ${e.message}"); result.complete(null) }
                                    }, 1400L)
                                } catch (e: Exception) { Log.w(TAG, "preview failed: ${e.message}"); result.complete(null) }
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) { result.complete(null) }
                        }, handler)
                    } catch (e: Exception) { Log.w(TAG, "session failed: ${e.message}"); result.complete(null) }
                }
                override fun onDisconnected(d: CameraDevice) { d.close(); result.complete(null) }
                override fun onError(d: CameraDevice, error: Int) { Log.w(TAG, "camera error $error"); d.close(); result.complete(null) }
            }, handler)
            return withTimeoutOrNull(15_000L) { result.await() }
        } catch (e: CameraAccessException) {
            Log.w(TAG, "camera access: ${e.message}")
            return null
        } catch (e: SecurityException) {
            Log.w(TAG, "camera permission: ${e.message}")
            return null
        } finally {
            try { session?.close() } catch (_: Exception) {}
            try { device?.close() } catch (_: Exception) {}
            try { reader.close() } catch (_: Exception) {}
            try { previewSurface.release(); texture.release() } catch (_: Exception) {}
            thread.quitSafely()
        }
    }
}

package com.example.engine

import android.content.Context
import android.media.AudioManager
import android.provider.Settings

/**
 * Short memory of what MAX just did, so the user can say "undo that", "turn it off again",
 * "make it lower", "do it again" and the AI brain works out the reverse action itself.
 *
 * Nothing here decides what the reverse is. It only keeps the facts (what was asked, what happened,
 * what the phone looked like BEFORE, and Gemini's own undo_hint) and hands them back to Gemini as a
 * RECENT_ACTIONS block on the next turn.
 */
object ActionLog {

    data class Entry(
        val id: Int,
        val atMs: Long,
        val request: String,
        val module: String,
        val intent: String,
        val params: String,
        val result: String,
        val success: Boolean,
        val undoHint: String,
        val stateBefore: String
    )

    private const val MAX_ENTRIES = 12
    private const val WINDOW_MS = 45 * 60 * 1000L
    private val entries = ArrayDeque<Entry>()
    private var nextId = 1

    private val NON_ACTION_MODULES = setOf("CHAT", "IGNORED", "WAKE", "TASK_PLAN", "SYSTEM", "WEATHER", "CLARIFY", "TIME", "TEMPORAL", "TIME_QUERY", "MEMORY")

    /** Cheap, permission-free picture of the phone, taken BEFORE a command runs. */
    fun snapshot(context: Context): String {
        val parts = mutableListOf<String>()
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (am != null) {
                parts.add("music volume ${am.getStreamVolume(AudioManager.STREAM_MUSIC)}/${am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)}")
                parts.add("ringer mode ${am.ringerMode}")
            }
        } catch (_: Exception) {}
        try {
            val b = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
            parts.add("brightness $b/255")
        } catch (_: Exception) {}
        fun flag(name: String, label: String) {
            try {
                val v = Settings.Global.getInt(context.contentResolver, name, -1)
                if (v >= 0) parts.add("$label ${if (v == 1) "on" else "off"}")
            } catch (_: Exception) {}
        }
        flag("wifi_on", "wifi")
        flag("bluetooth_on", "bluetooth")
        flag("airplane_mode_on", "airplane mode")
        return parts.joinToString("; ")
    }

    private fun clip(s: String, n: Int) = s.replace(Regex("\\s+"), " ").trim().let { if (it.length > n) it.take(n) + "…" else it }

    @Synchronized
    fun record(
        request: String, module: String, intent: String, params: String, result: String,
        success: Boolean, undoHint: String, stateBefore: String, nowMs: Long = System.currentTimeMillis()
    ) {
        entries.addLast(Entry(nextId++, nowMs, clip(request, 140), module, intent, clip(params, 200), clip(result, 140), success, clip(undoHint, 140), stateBefore))
        while (entries.size > MAX_ENTRIES) entries.removeFirst()
    }

    /** Called once per finished command. Chat, ignored speech and questions are not actions. */
    fun recordFromResult(
        request: String, module: String, spoken: String, success: Boolean, awaitingConfirmation: Boolean,
        command: com.example.data.MaxCommandResponse?, stateBefore: String, nowMs: Long = System.currentTimeMillis()
    ) {
        if (awaitingConfirmation) return
        val mod = module.trim().uppercase()
        val intent = command?.intent?.trim()?.uppercase().orEmpty()
        val chatLike = intent == "CHAT" || intent == "CLARIFY" || intent == "IGNORE" || intent.contains("GREETING") || intent.contains("QUESTION")
        if (mod in NON_ACTION_MODULES || chatLike) return
        if (command == null && mod == "CORE") return
        record(
            request = request,
            module = mod,
            intent = intent,
            params = command?.parameters?.filterKeys { !it.startsWith("_") }?.entries?.joinToString(", ") { "${it.key}=${it.value}" }.orEmpty() +
                (if (command?.shell_commands?.isNotEmpty() == true) " | shell: " + command.shell_commands.joinToString(" ; ") else ""),
            result = spoken,
            success = success,
            undoHint = command?.undo_hint.orEmpty(),
            stateBefore = stateBefore,
            nowMs = nowMs
        )
    }

    @Synchronized
    fun contextBlock(nowMs: Long = System.currentTimeMillis()): String {
        val recent = entries.filter { nowMs - it.atMs <= WINDOW_MS }.takeLast(6)
        if (recent.isEmpty()) return ""
        val sb = StringBuilder("RECENT_ACTIONS (newest last; use these to understand undo / fix / repeat requests):\n")
        for (e in recent) {
            val ageSec = ((nowMs - e.atMs) / 1000L).coerceAtLeast(0)
            val age = if (ageSec < 90) "${ageSec}s ago" else "${ageSec / 60} min ago"
            sb.append("- #${e.id} ($age) asked: \"${e.request}\" | module=${e.module} intent=${e.intent}")
            if (e.params.isNotBlank()) sb.append(" | ${e.params}")
            sb.append(" | outcome: ${if (e.success) "ok" else "FAILED"}, said: \"${e.result}\"")
            if (e.undoHint.isNotBlank()) sb.append(" | undo_hint: ${e.undoHint}")
            if (e.stateBefore.isNotBlank()) sb.append(" | phone state BEFORE: ${e.stateBefore}")
            sb.append('\n')
        }
        return sb.toString().trimEnd()
    }

    @Synchronized
    fun clear() { entries.clear(); nextId = 1 }
}

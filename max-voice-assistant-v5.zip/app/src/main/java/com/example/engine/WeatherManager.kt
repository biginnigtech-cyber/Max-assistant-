package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.TimeZone
import java.util.concurrent.TimeUnit

object WeatherManager {
    private const val TAG = "WeatherManager"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    data class LiveWeatherData(
        val temperatureC: Double,
        val feelsLikeC: Double,
        val humidity: Int,
        val precipitationMm: Double,
        val rainMm: Double,
        val weatherCode: Int,
        val conditionTextHindi: String,
        val conditionTextEnglish: String,
        val windSpeedKmh: Double,
        val maxRainProbToday: Int,
        val maxTempToday: Double,
        val minTempToday: Double
    )

    data class WeatherAnomaly(
        val isHazardous: Boolean,
        val hazardType: String,
        val alertSummaryHindi: String,
        val alertSummaryEnglish: String,
        val rawData: LiveWeatherData
    )

    @Volatile
    private var lastCachedWeather: LiveWeatherData? = null
    @Volatile
    private var lastFetchTimestamp: Long = 0L
    @Volatile
    private var lastProactiveAlertTimestamp: Long = 0L

    // 15 minutes cache for weather data
    private const val CACHE_EXPIRY_MS = 15 * 60 * 1000L
    // 30 minutes cooldown between proactive spoken weather alerts
    private const val PROACTIVE_ALERT_COOLDOWN_MS = 30 * 60 * 1000L

    @SuppressLint("MissingPermission")
    /** Location permission through root: no trip to Settings, and no weather for the wrong city. */
    private suspend fun ensureLocationPermission(context: Context) {
        try {
            val granted = androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!granted && RootCommandEngine.isRootAvailable()) {
                RootCommandEngine.execute("pm grant ${context.packageName} android.permission.ACCESS_COARSE_LOCATION; pm grant ${context.packageName} android.permission.ACCESS_FINE_LOCATION")
            }
        } catch (e: Exception) {
            Log.d(TAG, "Could not grant location through root: ${e.message}")
        }
    }

    private fun getApproximateCoordinates(context: Context): Pair<Double, Double>? {
        try {
            val locManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            if (locManager != null) {
                val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
                for (p in providers) {
                    if (locManager.isProviderEnabled(p)) {
                        val loc: Location? = locManager.getLastKnownLocation(p)
                        if (loc != null && loc.latitude != 0.0 && loc.longitude != 0.0) {
                            return Pair(loc.latitude, loc.longitude)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "Location permission not granted or unavailable: ${e.message}")
        }

        // Timezone based default coordinates fallback
        val tzId = TimeZone.getDefault().id.lowercase()
        return when {
            tzId.contains("calcutta") || tzId.contains("kolkata") || tzId.contains("india") -> Pair(28.6139, 77.2090) // New Delhi
            tzId.contains("kathmandu") || tzId.contains("nepal") -> Pair(27.7172, 85.3240) // Kathmandu
            tzId.contains("karachi") -> Pair(24.8607, 67.0011) // Karachi
            tzId.contains("dhaka") -> Pair(23.8103, 90.4125) // Dhaka
            tzId.contains("dubai") -> Pair(25.2048, 55.2708) // Dubai
            tzId.contains("london") -> Pair(51.5074, -0.1278) // London
            tzId.contains("new_york") -> Pair(40.7128, -74.0060) // New York
            tzId.contains("los_angeles") -> Pair(34.0522, -118.2437) // Los Angeles
            // Unknown region: no data is better than the weather of a city the user is not in.
            else -> null
        }
    }

    suspend fun fetchLiveWeather(context: Context, forceRefresh: Boolean = false): LiveWeatherData? = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (!forceRefresh && lastCachedWeather != null && (now - lastFetchTimestamp) < CACHE_EXPIRY_MS) {
            return@withContext lastCachedWeather
        }

        try {
            ensureLocationPermission(context)
            val (lat, lon) = getApproximateCoordinates(context) ?: return@withContext lastCachedWeather
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto"

            val request = Request.Builder().url(url).build()
            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.w(TAG, "Open-Meteo weather fetch failed with HTTP ${response.code}")
                return@withContext lastCachedWeather
            }

            val body = response.body?.string() ?: return@withContext lastCachedWeather
            val json = JSONObject(body)

            val current = json.getJSONObject("current")
            val temp = current.optDouble("temperature_2m", 25.0)
            val feelsLike = current.optDouble("apparent_temperature", temp)
            val humidity = current.optInt("relative_humidity_2m", 50)
            val precip = current.optDouble("precipitation", 0.0)
            val rain = current.optDouble("rain", 0.0)
            val weatherCode = current.optInt("weather_code", 0)
            val wind = current.optDouble("wind_speed_10m", 10.0)

            val daily = json.optJSONObject("daily")
            val maxRainProb = daily?.optJSONArray("precipitation_probability_max")?.optInt(0, 0) ?: 0
            val maxTemp = daily?.optJSONArray("temperature_2m_max")?.optDouble(0, temp + 4) ?: (temp + 4)
            val minTemp = daily?.optJSONArray("temperature_2m_min")?.optDouble(0, temp - 4) ?: (temp - 4)

            val (condHindi, condEnglish) = mapWmoWeatherCode(weatherCode)

            val data = LiveWeatherData(
                temperatureC = temp,
                feelsLikeC = feelsLike,
                humidity = humidity,
                precipitationMm = precip,
                rainMm = rain,
                weatherCode = weatherCode,
                conditionTextHindi = condHindi,
                conditionTextEnglish = condEnglish,
                windSpeedKmh = wind,
                maxRainProbToday = maxRainProb,
                maxTempToday = maxTemp,
                minTempToday = minTemp
            )

            lastCachedWeather = data
            lastFetchTimestamp = now
            Log.d(TAG, "Live Weather fetched: $temp°C, $condEnglish, Rain Prob: $maxRainProb%, Wind: $wind km/h")
            return@withContext data
        } catch (e: Exception) {
            Log.w(TAG, "Error fetching live weather: ${e.message}")
            return@withContext lastCachedWeather
        }
    }

    private fun mapWmoWeatherCode(code: Int): Pair<String, String> {
        return when (code) {
            0 -> Pair("साफ आसमान", "Clear Sky")
            1 -> Pair("मुख्यतः साफ", "Mainly Clear")
            2 -> Pair("आंशिक रूप से बादल", "Partly Cloudy")
            3 -> Pair("घने बादल छाए हुए", "Overcast")
            45, 48 -> Pair("घना कोहरा", "Foggy")
            51, 53, 55 -> Pair("हल्की बूंदाबांदी", "Drizzle")
            56, 57 -> Pair("शीतकालीन बूंदाबांदी", "Freezing Drizzle")
            61, 63 -> Pair("बारिश", "Rain")
            65 -> Pair("तेज भारी बारिश", "Heavy Rain")
            66, 67 -> Pair("जमा देने वाली बारिश", "Freezing Rain")
            71, 73, 75 -> Pair("बर्फबारी", "Snowfall")
            77 -> Pair("बर्फ के दाने", "Snow grains")
            80, 81 -> Pair("बारिश की फुहारें", "Rain showers")
            82 -> Pair("तेज मूसलाधार बारिश", "Violent rain showers")
            85, 86 -> Pair("बर्फबारी की फुहारें", "Snow showers")
            95 -> Pair("गरज के साथ आंधी-तूफान", "Thunderstorm")
            96, 99 -> Pair("ओलावृष्टि के साथ भीषण तूफान", "Severe thunderstorm with hail")
            else -> Pair("सामान्य मौसम", "Moderate Weather")
        }
    }

    /**
     * Checks if current weather or upcoming forecast indicates hazardous or severe conditions
     * (e.g. thunderstorm, heavy downpour, heatwave, gale winds) suitable for proactive voice warning.
     */
    suspend fun checkSevereWeatherAnomaly(context: Context): WeatherAnomaly? = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (now - lastProactiveAlertTimestamp < PROACTIVE_ALERT_COOLDOWN_MS) {
            return@withContext null
        }

        val weather = fetchLiveWeather(context) ?: return@withContext null

        var isSevere = false
        var hazardType = ""
        var alertHindi = ""
        var alertEnglish = ""

        when {
            // Thunderstorms or severe storms
            weather.weatherCode in listOf(95, 96, 99) -> {
                isSevere = true
                hazardType = "THUNDERSTORM"
                alertHindi = "सर, बाहर गरज के साथ तेज आंधी-तूफान की चेतावनी है। कृपया सावधानी बरतें और सुरक्षित स्थान पर रहें।"
                alertEnglish = "Sir, there is a severe thunderstorm warning in your area. Please stay safe and take shelter."
            }
            // Heavy or violent rain
            weather.weatherCode in listOf(65, 82) || weather.precipitationMm > 4.0 || weather.maxRainProbToday >= 85 -> {
                isSevere = true
                hazardType = "HEAVY_RAIN"
                alertHindi = "सर, मौसम खराब होने और तेज बारिश की भारी संभावना है। अगर आप बाहर जा रहे हैं तो छाता साथ रख लें।"
                alertEnglish = "Sir, heavy rain is expected in your area. Make sure to carry an umbrella if heading outside."
            }
            // Extreme gale winds
            weather.windSpeedKmh > 35.0 -> {
                isSevere = true
                hazardType = "HIGH_WIND"
                alertHindi = "सर, बाहर लगभग ${weather.windSpeedKmh.toInt()} किलोमीटर प्रति घंटे की तेज आंधी चल रही है। संभलकर रहें।"
                alertEnglish = "Sir, strong winds of around ${weather.windSpeedKmh.toInt()} km/h are blowing outside. Please stay cautious."
            }
            // Heatwave
            weather.temperatureC >= 41.0 -> {
                isSevere = true
                hazardType = "HEATWAVE"
                alertHindi = "सर, बाहर तापमान ${weather.temperatureC.toInt()} डिग्री सेल्सियस है, काफी तेज गर्मी और लू का अलर्ट है। पानी पीते रहें।"
                alertEnglish = "Sir, extreme heatwave outside with temperatures touching ${weather.temperatureC.toInt()}°C. Stay hydrated."
            }
        }

        if (isSevere) {
            lastProactiveAlertTimestamp = now
            return@withContext WeatherAnomaly(
                isHazardous = true,
                hazardType = hazardType,
                alertSummaryHindi = alertHindi,
                alertSummaryEnglish = alertEnglish,
                rawData = weather
            )
        }

        return@withContext null
    }

    /**
     * Builds a detailed live context summary for Gemini Brain to answer any weather question dynamically.
     */
    suspend fun buildLiveWeatherContext(context: Context): String = withContext(Dispatchers.IO) {
        val weather = fetchLiveWeather(context)
        if (weather == null) {
            return@withContext "CURRENT SENSOR WEATHER: Weather sensor data temporarily unavailable. Answer based on general season/climate context."
        }

        return@withContext """
            LIVE REAL-TIME WEATHER INTELLIGENCE:
            - Current Temperature: ${weather.temperatureC}°C (Feels like: ${weather.feelsLikeC}°C)
            - Conditions: ${weather.conditionTextHindi} (${weather.conditionTextEnglish})
            - Precipitation Probability Today: ${weather.maxRainProbToday}%
            - Humidity: ${weather.humidity}%
            - Wind Speed: ${weather.windSpeedKmh} km/h
            - Today's Expected Range: Min ${weather.minTempToday}°C to Max ${weather.maxTempToday}°C
            - Directive: Use these exact live numbers and condition in your natural, charismatic Jarvis persona to inform the user in Hindi/Hinglish.
        """.trimIndent()
    }
}

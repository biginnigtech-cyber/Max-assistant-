package com.example.engine

import android.content.Context
import com.example.utils.PreferencesManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * "Understands without being told": MAX notices what the user does at about the same time on several days and mentions it, offering to make
 * it an automation. Only the kind of action and the hour are kept (never message text or names). Gemini decides when and how to bring it up.
 */
object HabitTracker {

    private const val PREF_KEY = "habit_events"
    private const val MAX_EVENTS = 300
    private const val WINDOW_DAYS = 14
    private const val DAY_MS = 24 * 60 * 60 * 1000L

    data class Event(val atMs: Long, val key: String)
    data class Pattern(val key: String, val hour: Int, val days: Int)

    private fun hourOf(ms: Long) = Calendar.getInstance().apply { timeInMillis = ms }.get(Calendar.HOUR_OF_DAY)
    private fun dayOf(ms: Long) = ms / DAY_MS

    /** Pure (unit-tested): actions done around the same hour on at least [minDays] different days in the last two weeks. */
    fun patterns(events: List<Event>, nowMs: Long, minDays: Int = 3): List<Pattern> {
        val recent = events.filter { nowMs - it.atMs <= WINDOW_DAYS * DAY_MS }
        val out = mutableListOf<Pattern>()
        for ((key, list) in recent.groupBy { it.key }) {
            val byHour = (0..23).map { h ->
                // an hour counts events from one hour before to one hour after, so 6:55 and 7:10 are the same habit
                h to list.filter { val eh = hourOf(it.atMs); eh == h || eh == (h + 1) % 24 || eh == (h + 23) % 24 }.map { dayOf(it.atMs) }.toSet().size
            }
            val best = byHour.maxByOrNull { it.second } ?: continue
            if (best.second >= minDays) out.add(Pattern(key, best.first, best.second))
        }
        return out
    }

    /** Patterns whose hour is now (within one hour), for the hint block. */
    fun dueNow(events: List<Event>, nowMs: Long): List<Pattern> {
        val h = hourOf(nowMs)
        return patterns(events, nowMs).filter { val d = Math.abs(it.hour - h); minOf(d, 24 - d) <= 1 }
    }

    private fun load(context: Context): List<Event> = try {
        val arr = JSONArray(PreferencesManager.getString(context, PREF_KEY, "[]"))
        (0 until arr.length()).map { Event(arr.getJSONObject(it).optLong("t"), arr.getJSONObject(it).optString("k")) }
    } catch (_: Exception) { emptyList() }

    @Synchronized
    fun record(context: Context, key: String, nowMs: Long = System.currentTimeMillis()) {
        if (key.isBlank()) return
        val events = (load(context) + Event(nowMs, key)).filter { nowMs - it.atMs <= WINDOW_DAYS * DAY_MS }.takeLast(MAX_EVENTS)
        val arr = JSONArray()
        events.forEach { arr.put(JSONObject().put("t", it.atMs).put("k", it.key)) }
        PreferencesManager.putString(context, PREF_KEY, arr.toString())
    }

    /** A line for Gemini's context, or empty. Gemini decides whether the moment is right and offers to automate it. */
    fun hintBlock(context: Context, existingAutomations: List<Automations.Rule>, nowMs: Long = System.currentTimeMillis()): String {
        val due = dueNow(load(context), nowMs).filter { p -> existingAutomations.none { it.command.contains(p.key.substringAfter('|'), true) } }
        if (due.isEmpty()) return ""
        return "HABITS NOTICED (about this time of day): " + due.joinToString("; ") { "the user usually does '${it.key.replace('|', ' ')}' around ${it.hour}:00 (${it.days} different days in two weeks)" } +
            ". Mention it only if it fits naturally in this reply, briefly, and offer to make it an automation. Never nag and never repeat an offer already made in this conversation."
    }
}

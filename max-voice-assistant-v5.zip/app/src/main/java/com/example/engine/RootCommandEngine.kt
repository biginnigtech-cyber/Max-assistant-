package com.example.engine

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.util.UUID

/**
 * RootCommandEngine:
 * Persistent Root Shell Session Manager (UID 0).
 *
 * Maintains a single, continuous interactive `su` process so Magisk / KernelSU / APatch
 * only requests or evaluates root permissions ONCE when initialized. This prevents repeated
 * system toasts, prompts, and popups on every subsequent command execution.
 */
object RootCommandEngine {
    private const val TAG = "RootCommandEngine"

    data class RootExecutionResult(
        val exitCode: Int,
        val stdout: String,
        val stderr: String,
        val success: Boolean,
        val durationMs: Long = 0
    )

    private const val COMMAND_TIMEOUT_MS = 60_000L
    private const val SPAWN_TIMEOUT_MS = 20_000L
    private const val MAX_OUTPUT_CHARS = 200_000

    /** Runs a blocking [block] on a helper thread and returns false if it does not finish in time. */
    private fun runWithTimeout(timeoutMs: Long, block: () -> Unit): Boolean {
        var error: Throwable? = null
        val t = Thread {
            try { block() } catch (e: Throwable) { error = e }
        }
        t.isDaemon = true
        t.start()
        t.join(timeoutMs)
        if (t.isAlive) return false
        error?.let { throw it }
        return true
    }

    private val _liveStreamFlow = MutableSharedFlow<String>(extraBufferCapacity = 128)
    val liveStreamFlow: SharedFlow<String> = _liveStreamFlow.asSharedFlow()

    // Persistent interactive Root Shell session
    private var suProcess: Process? = null
    private var suWriter: DataOutputStream? = null
    private var suReader: BufferedReader? = null
    private val shellMutex = Mutex()
    private var isRootConfirmed: Boolean? = null

    /**
     * Initializes or verifies the persistent interactive su shell.
     * Keeps su alive so Magisk / KernelSU only authorizes ONCE on startup.
     */
    private fun getOrCreatePersistentShell(): Boolean {
        if (suProcess != null && suWriter != null && suReader != null) {
            try {
                suProcess?.exitValue()
                // If it reached here, process already exited
                closePersistentShell()
            } catch (_: IllegalThreadStateException) {
                // Process is still alive and running normally
                return true
            }
        }

        return try {
            Log.d(TAG, "Spawning persistent root shell (su)...")
            val p = Runtime.getRuntime().exec("su")
            val writer = DataOutputStream(p.outputStream)
            // Redirect stderr to stdout so we have unified output stream
            writer.writeBytes("exec 2>&1\n")
            writer.flush()
            val reader = BufferedReader(InputStreamReader(p.inputStream))

            // Check UID
            val marker = "CHECK_" + UUID.randomUUID().toString().take(8)
            writer.writeBytes("id\necho \"__MAX_READY_${marker}__ $?\"\n")
            writer.flush()

            var isUid0 = false
            val answered = runWithTimeout(SPAWN_TIMEOUT_MS) {
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val l = line ?: break
                    if (l.contains("uid=0")) {
                        isUid0 = true
                    }
                    if (l.startsWith("__MAX_READY_${marker}__")) {
                        break
                    }
                }
            }
            if (!answered) Log.w(TAG, "su did not answer within ${SPAWN_TIMEOUT_MS}ms (root prompt ignored or denied?)")

            if (isUid0) {
                suProcess = p
                suWriter = writer
                suReader = reader
                isRootConfirmed = true
                Log.d(TAG, "Persistent root shell successfully established (UID 0).")
                true
            } else {
                Log.w(TAG, "Persistent root shell spawned but UID != 0")
                isRootConfirmed = false
                try { p.destroy() } catch (_: Exception) {}
                // Close the pipes too so a half-started su does not leak file descriptors.
                try { writer.close() } catch (_: Exception) {}
                try { reader.close() } catch (_: Exception) {}
                false
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to create persistent root shell: ${e.message}")
            isRootConfirmed = false
            false
        }
    }

    fun closePersistentShell() {
        try {
            suWriter?.writeBytes("exit\n")
            suWriter?.flush()
            suWriter?.close()
        } catch (_: Exception) {}
        try {
            suReader?.close()
        } catch (_: Exception) {}
        try {
            suProcess?.destroy()
        } catch (_: Exception) {}
        suProcess = null
        suWriter = null
        suReader = null
    }

    suspend fun isRootAvailable(): Boolean = withContext(Dispatchers.IO) {
        shellMutex.withLock {
            if (isRootConfirmed == true && suProcess != null) return@withLock true
            getOrCreatePersistentShell()
        }
    }

    suspend fun getRootDetails(): Map<String, String> = withContext(Dispatchers.IO) {
        val details = mutableMapOf<String, String>()
        try {
            val res = execute("magisk -v || which su || id")
            details["root_info"] = res.stdout.trim()
            val selinux = execute("getenforce")
            details["selinux"] = selinux.stdout.trim().ifBlank { "Unknown" }
        } catch (e: Exception) {
            details["error"] = e.message ?: "Failed to read root info"
        }
        details
    }

    /**
     * Hard safety denylist. These commands are refused no matter what Gemini or the user asks,
     * because a single mis-heard word or injected text must never be able to wipe the phone.
     */
    private val BLOCKED_PATTERNS: List<Regex> = listOf(
        Regex("""\brm\s+(-\S+\s+)*(/|/\*|/data|/data/\*|/system|/vendor|/product|/sdcard|/sdcard/\*|/storage|/storage/\*|/storage/emulated(/0)?(/\*)?|~|~/\*)(\s|$)"""),
        Regex("""\bdd\b.*\bof=/dev/"""),
        Regex("""\bmkfs(\.\w+)?\b"""),
        Regex(""">\s*/dev/block/"""),
        Regex("""\b(wipe|fastboot|flash_image|erase_image|make_ext4fs)\b"""),
        Regex("""\bchmod\s+(-\S+\s+)*[0-7]*777\s+/(\s|$)"""),
        Regex("""\bmount\b.*\b(-o\s+)?remount\b.*\b/\b(\s|$)"""),
        Regex(""":\(\)\s*\{.*\};\s*:"""),
        Regex("""\bcurl\b[^|;]*\|\s*(su|sh|bash)\b"""),
        Regex("""\bwget\b[^|;]*\|\s*(su|sh|bash)\b""")
    )

    fun isBlockedCommand(command: String): Boolean =
        BLOCKED_PATTERNS.any { it.containsMatchIn(command) }

    /** Normal commands: 60 second limit. */
    suspend fun execute(
        command: String,
        onOutputLine: ((String) -> Unit)? = null
    ): RootExecutionResult = executeWith(command, onOutputLine, COMMAND_TIMEOUT_MS)

    /** Long jobs (scans, installs) with their own limit; same shell, same safety blocklist. */
    suspend fun executeLong(
        command: String,
        timeoutMs: Long,
        onOutputLine: ((String) -> Unit)? = null
    ): RootExecutionResult = executeWith(command, onOutputLine, timeoutMs.coerceIn(5_000L, 30 * 60_000L))

    private suspend fun executeWith(
        command: String,
        onOutputLine: ((String) -> Unit)?,
        timeoutMs: Long
    ): RootExecutionResult = withContext(Dispatchers.IO) {
        shellMutex.withLock {
            val startTime = System.currentTimeMillis()
            if (isBlockedCommand(command)) {
                Log.w(TAG, "Blocked unsafe root command by safety policy")
                return@withLock RootExecutionResult(-1, "", "यह कमांड सुरक्षा कारणों से रोक दी गई है।", false)
            }
            if (com.example.BuildConfig.DEBUG) Log.d(TAG, "Root execute: $command")
            _liveStreamFlow.tryEmit("[ROOT] $ $command")

            if (!getOrCreatePersistentShell()) {
                // Fallback to non-root execution if root is unavailable
                return@withLock executeNonRootFallback(command, onOutputLine, startTime)
            }

            val writer = suWriter ?: return@withLock RootExecutionResult(-1, "", "No su writer", false)
            val reader = suReader ?: return@withLock RootExecutionResult(-1, "", "No su reader", false)

            val token = UUID.randomUUID().toString().replace("-", "")
            val startMarker = "__MAX_START_${token}__"
            val endMarker = "__MAX_END_${token}__"

            val stdoutBuilder = StringBuilder()
            var exitCode = -1

            try {
                writer.writeBytes("echo \"$startMarker\"\n")
                writer.writeBytes("$command\n")
                writer.writeBytes("echo \"$endMarker \$?\"\n")
                writer.flush()

                // A readLine() that never returns (hung command, dead su) used to freeze every later command,
                // because the shell lock stayed held forever. Now the whole command gets a time limit.
                val finished = runWithTimeout(timeoutMs) {
                    var hasStarted = false
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        val l = line ?: break
                        if (!hasStarted) {
                            if (l == startMarker) {
                                hasStarted = true
                            }
                            continue
                        }

                        if (l.startsWith(endMarker)) {
                            val codeStr = l.substringAfter(endMarker).trim()
                            exitCode = codeStr.toIntOrNull() ?: 0
                            break
                        }

                        if (stdoutBuilder.length < MAX_OUTPUT_CHARS) stdoutBuilder.append(l).append("\n")
                        _liveStreamFlow.tryEmit("[OUT] $l")
                        onOutputLine?.invoke(l)
                    }
                }
                if (!finished) {
                    Log.w(TAG, "Root command timed out after ${timeoutMs}ms; resetting the shell")
                    closePersistentShell()
                    return@withLock RootExecutionResult(-1, stdoutBuilder.toString().trim(), "कमांड समय सीमा में पूरी नहीं हुई, इसलिए रोक दी गई।", false)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error executing in persistent shell: ${e.message}", e)
                closePersistentShell()
                return@withLock RootExecutionResult(-1, stdoutBuilder.toString(), e.message ?: "Execution error", false)
            }

            val duration = System.currentTimeMillis() - startTime
            val success = (exitCode == 0)
            Log.d(TAG, "Root command finished in ${duration}ms, exitCode=$exitCode, success=$success")

            RootExecutionResult(
                exitCode = exitCode,
                stdout = stdoutBuilder.toString().trim(),
                stderr = if (success) "" else stdoutBuilder.toString().trim(),
                success = success,
                durationMs = duration
            )
        }
    }

    private fun executeNonRootFallback(
        command: String,
        onOutputLine: ((String) -> Unit)?,
        startTime: Long
    ): RootExecutionResult {
        val stdoutBuilder = StringBuilder()
        var exitCode = -1
        try {
            val pb = ProcessBuilder("sh", "-c", command).redirectErrorStream(true)
            val process = pb.start()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val finished = runWithTimeout(timeoutMs) {
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val l = line ?: continue
                    if (stdoutBuilder.length < MAX_OUTPUT_CHARS) stdoutBuilder.append(l).append("\n")
                    _liveStreamFlow.tryEmit("[SH] $l")
                    onOutputLine?.invoke(l)
                }
            }
            if (!finished) {
                process.destroyForcibly()
                stdoutBuilder.append("समय सीमा पूरी हो गई।")
            } else {
                exitCode = if (process.waitFor(5, TimeUnit.SECONDS)) process.exitValue() else -1
            }
        } catch (e: Exception) {
            stdoutBuilder.append(e.message)
        }
        val duration = System.currentTimeMillis() - startTime
        return RootExecutionResult(
            exitCode = exitCode,
            stdout = stdoutBuilder.toString().trim(),
            stderr = if (exitCode == 0) "" else stdoutBuilder.toString().trim(),
            success = (exitCode == 0),
            durationMs = duration
        )
    }

    suspend fun executeBatch(
        commands: List<String>,
        onProgress: ((completed: Int, total: Int, currentCmd: String) -> Unit)? = null,
        onOutputLine: ((String) -> Unit)? = null
    ): RootExecutionResult = withContext(Dispatchers.IO) {
        val total = commands.size
        val allStdout = StringBuilder()
        val allStderr = StringBuilder()
        var overallSuccess = true
        var lastExitCode = 0
        val startTime = System.currentTimeMillis()

        for ((index, cmd) in commands.withIndex()) {
            onProgress?.invoke(index, total, cmd)
            val res = execute(cmd, onOutputLine)
            if (res.stdout.isNotBlank()) {
                allStdout.append(res.stdout).append("\n")
            }
            if (res.stderr.isNotBlank()) {
                allStderr.append(res.stderr).append("\n")
            }
            if (!res.success) {
                overallSuccess = false
                lastExitCode = res.exitCode
            }
        }
        onProgress?.invoke(total, total, "Completed")

        RootExecutionResult(
            exitCode = if (overallSuccess) 0 else lastExitCode,
            stdout = allStdout.toString().trim(),
            stderr = allStderr.toString().trim(),
            success = overallSuccess,
            durationMs = System.currentTimeMillis() - startTime
        )
    }
}

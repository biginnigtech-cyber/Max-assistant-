package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.service.MaxVoiceService.ServiceStatus
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

// Futuristic Cyan / Turquoise / Electric Blue Color Palette (NO ULTRON)
val HudCyan = Color(0xFF00E5FF)
val HudTurquoise = Color(0xFF00F5D4)
val HudElectricBlue = Color(0xFF0088FF)
val HudDeepNavy = Color(0xFF020817)
val HudGlowCyan = Color(0x6600E5FF)
val HudWhiteHot = Color(0xFFFFFFFF)
val HudErrorRed = Color(0xFFFF2A5F)

private data class NeuralNode3D(
    val x: Float,
    val y: Float,
    val z: Float,
    val phase: Float
)

@Composable
fun MaxCoreCanvas(
    status: ServiceStatus,
    modifier: Modifier = Modifier,
    size: Dp = 260.dp,
    audioLevel: Float = 0f,
    isSpeakingTts: Boolean = false,
    aiName: String = "MAX"
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hud_core_transition")

    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 628.318f, // 100 * 2PI
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 100000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "master_time"
    )

    // Dynamic rotation speeds & state animation targets
    val rotSpeedYTarget = when (status) {
        ServiceStatus.IDLE, ServiceStatus.MICROPHONE_OFF, ServiceStatus.SPEECH_SERVICE_MISSING -> 0.3f
        ServiceStatus.COMPLETED -> 0.6f
        ServiceStatus.LISTENING, ServiceStatus.LISTENING_FOR_WAKE_WORD, ServiceStatus.LISTENING_FOR_COMMAND -> 0.8f
        ServiceStatus.THINKING, ServiceStatus.EXECUTING, ServiceStatus.RUNNING_TOOL -> 3.5f // Fast processing core rotation
        ServiceStatus.SPEAKING -> 1.5f
        ServiceStatus.ERROR -> 0.2f
    }

    val rotSpeedXTarget = when (status) {
        ServiceStatus.IDLE, ServiceStatus.MICROPHONE_OFF, ServiceStatus.SPEECH_SERVICE_MISSING -> 0.2f
        ServiceStatus.COMPLETED -> 0.4f
        ServiceStatus.LISTENING, ServiceStatus.LISTENING_FOR_WAKE_WORD, ServiceStatus.LISTENING_FOR_COMMAND -> 0.5f
        ServiceStatus.THINKING, ServiceStatus.EXECUTING, ServiceStatus.RUNNING_TOOL -> 2.5f
        ServiceStatus.SPEAKING -> 1.0f
        ServiceStatus.ERROR -> 0.1f
    }

    val glowIntensityTarget = when (status) {
        ServiceStatus.IDLE -> 0.5f
        ServiceStatus.MICROPHONE_OFF, ServiceStatus.SPEECH_SERVICE_MISSING -> 0.3f
        ServiceStatus.COMPLETED -> 0.8f
        ServiceStatus.LISTENING, ServiceStatus.LISTENING_FOR_WAKE_WORD -> 0.75f
        ServiceStatus.LISTENING_FOR_COMMAND -> 0.95f
        ServiceStatus.THINKING, ServiceStatus.EXECUTING, ServiceStatus.RUNNING_TOOL -> 1.0f
        ServiceStatus.SPEAKING -> 0.9f
        ServiceStatus.ERROR -> 0.4f
    }

    val rotSpeedY by animateFloatAsState(
        targetValue = rotSpeedYTarget,
        animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing),
        label = "rotSpeedY"
    )

    val rotSpeedX by animateFloatAsState(
        targetValue = rotSpeedXTarget,
        animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing),
        label = "rotSpeedX"
    )

    val glowIntensity by animateFloatAsState(
        targetValue = glowIntensityTarget,
        animationSpec = tween(durationMillis = 400),
        label = "glowIntensity"
    )

    // Smooth audio level interpolation
    val smoothAudioLevel by animateFloatAsState(
        targetValue = audioLevel.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 80, easing = LinearEasing),
        label = "smoothAudioLevel"
    )

    // Pre-generate 3D Neural Nodes
    val neuralNodes = remember {
        val list = mutableListOf<NeuralNode3D>()
        val count = 42
        val phi = (1.0 + sqrt(5.0)) / 2.0 - 1.0
        for (i in 0 until count) {
            val y = 1f - (i.toFloat() / (count - 1)) * 2f
            val radiusAtY = sqrt((1f - y * y).toDouble()).toFloat()
            val theta = 2f * Math.PI.toFloat() * i * phi.toFloat()
            val x = cos(theta.toDouble()).toFloat() * radiusAtY
            val z = sin(theta.toDouble()).toFloat() * radiusAtY
            list.add(NeuralNode3D(x, y, z, (i * 0.35f) % (2f * Math.PI.toFloat())))
        }
        list
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val outerRadius = (minOf(this.size.width, this.size.height) / 2f) - 12.dp.toPx()

            val currentRotY = time * rotSpeedY
            val currentRotX = time * rotSpeedX
            val currentRotZ = if (status == ServiceStatus.THINKING || status == ServiceStatus.EXECUTING || status == ServiceStatus.RUNNING_TOOL) time * 2.0f else time * 0.15f

            // Dynamic pulse factor based on state and audio level / speaking
            val statePulse = when {
                isSpeakingTts || status == ServiceStatus.SPEAKING -> 1.05f + 0.15f * sin(time * 25.0f)
                status == ServiceStatus.LISTENING || status == ServiceStatus.LISTENING_FOR_COMMAND || status == ServiceStatus.LISTENING_FOR_WAKE_WORD -> 1.08f + 0.25f * smoothAudioLevel
                status == ServiceStatus.THINKING || status == ServiceStatus.EXECUTING || status == ServiceStatus.RUNNING_TOOL -> 1.02f + 0.12f * sin(time * 12.0f)
                status == ServiceStatus.COMPLETED -> 1.04f + 0.08f * sin(time * 6.0f)
                status == ServiceStatus.ERROR -> 1.0f + 0.05f * sin(time * 8.0f)
                else -> 1.0f + 0.04f * sin(time * 2.5f) // Subtle idle breath
            }

            val coreRadius = outerRadius * 0.48f * statePulse

            // Primary Accent Colors based on status
            val primaryCyan = if (status == ServiceStatus.ERROR) HudErrorRed else HudCyan
            val secondaryTurquoise = if (status == ServiceStatus.ERROR) Color(0xFFFF5500) else HudTurquoise
            val electricBlue = if (status == ServiceStatus.ERROR) Color(0xFF990033) else HudElectricBlue

            // --- HUD LAYER 1: Subtle Circular Radial Glow ---
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryCyan.copy(alpha = 0.22f * glowIntensity),
                        secondaryTurquoise.copy(alpha = 0.10f * glowIntensity),
                        HudDeepNavy.copy(alpha = 0.05f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = outerRadius * 1.1f
                ),
                radius = outerRadius * 1.1f,
                center = center
            )

            // --- HUD LAYER 2: Segmented Cyan Ring ---
            drawSegmentedRing(
                center = center,
                radius = outerRadius * 0.95f,
                color = primaryCyan.copy(alpha = 0.65f * glowIntensity),
                rotationAngle = time * (if (status == ServiceStatus.THINKING) 80f else 15f),
                segments = 8,
                strokeWidth = 2.dp.toPx()
            )

            // --- HUD LAYER 3: Thin Rotating Dashed Ring (Reverse direction) ---
            rotate(-time * (if (status == ServiceStatus.THINKING) 120f else 25f), center) {
                drawCircle(
                    color = secondaryTurquoise.copy(alpha = 0.5f * glowIntensity),
                    radius = outerRadius * 0.82f,
                    center = center,
                    style = Stroke(
                        width = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12.dp.toPx(), 8.dp.toPx()))
                    )
                )
            }

            // --- HUD LAYER 4: Small Radial Markers (Tick Notches) ---
            drawRadialTickMarkers(
                center = center,
                radius = outerRadius * 0.88f,
                color = primaryCyan.copy(alpha = 0.4f * glowIntensity),
                markerCount = 36,
                rotationAngle = time * 5f
            )

            // --- HUD LAYER 5: Occasional Scanning Arc ---
            drawScanningArc(
                center = center,
                radius = outerRadius * 0.75f,
                color = primaryCyan.copy(alpha = 0.7f * glowIntensity),
                rotationAngle = time * (if (status == ServiceStatus.THINKING) 250f else 45f)
            )

            // --- CENTRAL NEURAL CORE: 3D Projected Nodes & Synaptic Lines ---
            draw3DNeuralCore(
                center = center,
                baseRadius = coreRadius,
                nodes = neuralNodes,
                rotX = currentRotX,
                rotY = currentRotY,
                rotZ = currentRotZ,
                primaryColor = primaryCyan.copy(alpha = (0.9f * glowIntensity).coerceIn(0f, 1f)),
                secondaryColor = secondaryTurquoise.copy(alpha = (0.7f * glowIntensity).coerceIn(0f, 1f)),
                electricColor = electricBlue.copy(alpha = (0.5f * glowIntensity).coerceIn(0f, 1f)),
                time = time,
                status = status,
                audioLevel = smoothAudioLevel,
                isSpeaking = isSpeakingTts
            )

            // --- ORBITING PARTICLES ---
            drawOrbitingParticles(
                center = center,
                radius = coreRadius,
                status = status,
                time = time,
                primaryColor = primaryCyan,
                secondaryColor = secondaryTurquoise,
                glowIntensity = glowIntensity
            )

            // --- CENTRAL BRIGHT AI NUCLEUS ---
            drawCentralNucleus(
                center = center,
                radius = coreRadius * 0.38f,
                primaryColor = primaryCyan,
                time = time,
                glowIntensity = glowIntensity,
                isSpeaking = isSpeakingTts
            )
        }
    }
}

private fun DrawScope.drawSegmentedRing(
    center: Offset,
    radius: Float,
    color: Color,
    rotationAngle: Float,
    segments: Int,
    strokeWidth: Float
) {
    rotate(rotationAngle, center) {
        val segmentSweep = (360f / segments) * 0.65f
        val gapSweep = (360f / segments) * 0.35f
        for (i in 0 until segments) {
            val startAngle = i * (segmentSweep + gapSweep)
            drawArc(
                color = color,
                startAngle = startAngle,
                sweepAngle = segmentSweep,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = Size(radius * 2f, radius * 2f),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }
    }
}

private fun DrawScope.drawRadialTickMarkers(
    center: Offset,
    radius: Float,
    color: Color,
    markerCount: Int,
    rotationAngle: Float
) {
    rotate(rotationAngle, center) {
        val angleStep = 360f / markerCount
        for (i in 0 until markerCount) {
            val rad = Math.toRadians((i * angleStep).toDouble())
            val innerR = radius - (if (i % 3 == 0) 6.dp.toPx() else 3.dp.toPx())
            val outerR = radius
            val startX = center.x + innerR * cos(rad).toFloat()
            val startY = center.y + innerR * sin(rad).toFloat()
            val endX = center.x + outerR * cos(rad).toFloat()
            val endY = center.y + outerR * sin(rad).toFloat()

            drawLine(
                color = if (i % 3 == 0) color else color.copy(alpha = color.alpha * 0.5f),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = if (i % 3 == 0) 1.5.dp.toPx() else 1.dp.toPx()
            )
        }
    }
}

private fun DrawScope.drawScanningArc(
    center: Offset,
    radius: Float,
    color: Color,
    rotationAngle: Float
) {
    rotate(rotationAngle, center) {
        drawArc(
            color = color,
            startAngle = 0f,
            sweepAngle = 70f,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2f, radius * 2f),
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
        drawArc(
            color = color.copy(alpha = color.alpha * 0.4f),
            startAngle = 180f,
            sweepAngle = 40f,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2f, radius * 2f),
            style = Stroke(width = 1.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

private fun DrawScope.draw3DNeuralCore(
    center: Offset,
    baseRadius: Float,
    nodes: List<NeuralNode3D>,
    rotX: Float,
    rotY: Float,
    rotZ: Float,
    primaryColor: Color,
    secondaryColor: Color,
    electricColor: Color,
    time: Float,
    status: ServiceStatus,
    audioLevel: Float,
    isSpeaking: Boolean
) {
    val cosY = cos(rotY)
    val sinY = sin(rotY)
    val cosX = cos(rotX)
    val sinX = sin(rotX)
    val cosZ = cos(rotZ)
    val sinZ = sin(rotZ)

    val projectedNodes = mutableListOf<Triple<Offset, Float, NeuralNode3D>>()

    for (node in nodes) {
        val x1 = node.x * cosY + node.z * sinY
        val z1 = -node.x * sinY + node.z * cosY
        val y1 = node.y

        val y2 = y1 * cosX - z1 * sinX
        val z2 = y1 * sinX + z1 * cosX
        val x2 = x1

        val x3 = x2 * cosZ - y2 * sinZ
        val y3 = x2 * sinZ + y2 * cosZ
        val z3 = z2

        val perspective = 3.2f
        val scale = perspective / (perspective + z3)

        val px = center.x + x3 * baseRadius * scale
        val py = center.y + y3 * baseRadius * scale

        projectedNodes.add(Triple(Offset(px, py), z3, node))
    }

    projectedNodes.sortBy { it.second }

    val threshold3D = 1.3f
    for (i in projectedNodes.indices) {
        val (p1, z1, n1) = projectedNodes[i]
        for (j in i + 1 until projectedNodes.size) {
            val (p2, z2, n2) = projectedNodes[j]

            val dx = n1.x - n2.x
            val dy = n1.y - n2.y
            val dz = n1.z - n2.z
            val distSq = dx * dx + dy * dy + dz * dz

            if (distSq < threshold3D) {
                val depthAlpha = (((z1 + z2) / 2f) + 1f) / 2f
                val lineAlpha = (1f - distSq / threshold3D) * (0.25f + 0.75f * depthAlpha)

                drawLine(
                    color = secondaryColor.copy(alpha = (lineAlpha * 0.6f).coerceIn(0f, 1f)),
                    start = p1,
                    end = p2,
                    strokeWidth = (1.2f * (0.5f + depthAlpha)).dp.toPx()
                )
            }
        }
    }

    for ((point, z, node) in projectedNodes) {
        val depthAlpha = ((z + 1f) / 2f).coerceIn(0.1f, 1.0f)
        val nodeRadius = (2.5f + 2.5f * depthAlpha).dp.toPx()

        val flash = 0.7f + 0.3f * sin(time * 6.0f + node.phase)

        if (z > 0.2f) {
            drawCircle(
                color = primaryColor.copy(alpha = (0.35f * depthAlpha * flash).coerceIn(0f, 1f)),
                radius = nodeRadius * 2.2f,
                center = point
            )
        }

        drawCircle(
            color = primaryColor.copy(alpha = (depthAlpha * flash).coerceIn(0f, 1f)),
            radius = nodeRadius,
            center = point
        )

        if (z > 0.4f) {
            drawCircle(
                color = HudWhiteHot.copy(alpha = (0.9f * depthAlpha).coerceIn(0f, 1f)),
                radius = nodeRadius * 0.45f,
                center = point
            )
        }
    }
}

private fun DrawScope.drawOrbitingParticles(
    center: Offset,
    radius: Float,
    status: ServiceStatus,
    time: Float,
    primaryColor: Color,
    secondaryColor: Color,
    glowIntensity: Float
) {
    val particleCount = if (status == ServiceStatus.THINKING) 20 else 12
    val speed = if (status == ServiceStatus.THINKING) 15f else 5f

    for (p in 0 until particleCount) {
        val angle = (p * (360f / particleCount) + time * speed) % 360f
        val rad = Math.toRadians(angle.toDouble())

        val progress = ((time * (speed * 0.06f) + p * 0.3f) % 1.0f)
        val particleDist = radius * (0.4f + progress * 1.2f)

        val px = center.x + particleDist * cos(rad).toFloat()
        val py = center.y + particleDist * sin(rad).toFloat()

        val alpha = (1.0f - progress).coerceIn(0f, 1f) * glowIntensity

        drawCircle(
            color = if (p % 2 == 0) primaryColor.copy(alpha = alpha) else secondaryColor.copy(alpha = alpha),
            radius = (1.5f + 2f * (1f - progress)).dp.toPx(),
            center = Offset(px, py)
        )
    }
}

private fun DrawScope.drawCentralNucleus(
    center: Offset,
    radius: Float,
    primaryColor: Color,
    time: Float,
    glowIntensity: Float,
    isSpeaking: Boolean
) {
    val auraRadius = radius * (if (isSpeaking) 2.6f else 2.2f)

    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                HudWhiteHot.copy(alpha = (0.95f * glowIntensity).coerceIn(0f, 1f)),
                primaryColor.copy(alpha = (0.85f * glowIntensity).coerceIn(0f, 1f)),
                HudElectricBlue.copy(alpha = (0.35f * glowIntensity).coerceIn(0f, 1f)),
                Color.Transparent
            ),
            center = center,
            radius = auraRadius
        ),
        radius = auraRadius,
        center = center
    )

    drawCircle(
        color = primaryColor,
        radius = radius * 0.65f,
        center = center,
        style = Stroke(width = 2.5.dp.toPx())
    )

    drawCircle(
        color = HudWhiteHot,
        radius = radius * 0.35f,
        center = center
    )
}

/**
 * Legacy compatibility alias for MaxCoreCanvas
 */
@Composable
fun JarvisCoreCanvas(
    status: ServiceStatus,
    modifier: Modifier = Modifier,
    size: Dp = 260.dp,
    audioLevel: Float = 0f,
    isSpeakingTts: Boolean = false,
    aiName: String = "MAX"
) {
    MaxCoreCanvas(status, modifier, size, audioLevel, isSpeakingTts, aiName)
}

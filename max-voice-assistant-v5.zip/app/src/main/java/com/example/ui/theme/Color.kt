package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBackground = Color(0xFF050B14)
val CyberSurface = Color(0xFF0A1428)
val CyberSurfaceVariant = Color(0xFF10203C)
val NeonCyan = Color(0xFF00E5FF)
val NeonBlue = Color(0xFF0088FF)
val NeonGold = Color(0xFFFFB700)
val NeonGreen = Color(0xFF00FF9D)
val NeonRed = Color(0xFFFF2A5F)
val NeonTextPrimary = Color(0xFFE2F1FF)
val NeonTextSecondary = Color(0xFF769BCE)
val GroqOrange = Color(0xFFFF5500)
val GroqAccent = Color(0xFFF55036)

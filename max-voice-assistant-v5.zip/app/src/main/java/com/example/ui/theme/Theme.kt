package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CyberColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = CyberBackground,
    primaryContainer = CyberSurfaceVariant,
    onPrimaryContainer = NeonCyan,
    secondary = NeonBlue,
    onSecondary = CyberBackground,
    tertiary = NeonGold,
    background = CyberBackground,
    onBackground = NeonTextPrimary,
    surface = CyberSurface,
    onSurface = NeonTextPrimary,
    surfaceVariant = CyberSurfaceVariant,
    onSurfaceVariant = NeonTextSecondary,
    error = NeonRed
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CyberColorScheme,
        typography = Typography,
        content = content
    )
}

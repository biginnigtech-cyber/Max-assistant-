package com.example.executor

import android.util.Log
import com.example.engine.RootCommandEngine

/**
 * Kept for the callers that still use it, but it no longer runs its own `su`: RootCommandEngine is the single root shell
 * (persistent, with time limits, output limits and the safety blocklist). Two separate root implementations meant two
 * sets of bugs; the old one had no timeout and could freeze MAX forever on a hung command.
 */
object RootShellExecutor {
    private const val TAG = "RootShellExecutor"

    data class ExecutionResult(
        val success: Boolean,
        val output: List<String>,
        val errors: List<String>
    )

    suspend fun isRootAvailable(): Boolean = RootCommandEngine.isRootAvailable()

    suspend fun executeCommands(commands: List<String>): ExecutionResult {
        if (commands.isEmpty()) return ExecutionResult(true, listOf("No commands to execute."), emptyList())

        if (commands.any { RootCommandEngine.isBlockedCommand(it) }) {
            Log.w(TAG, "Blocked unsafe root command batch by safety policy")
            return ExecutionResult(false, emptyList(), listOf("यह कमांड सुरक्षा कारणों से रोक दी गई है।"))
        }

        val output = mutableListOf<String>()
        val errors = mutableListOf<String>()
        var ok = true
        for (cmd in commands) {
            output.add("Executing: $cmd")
            val res = RootCommandEngine.execute(cmd)
            res.stdout.lines().filter { it.isNotBlank() }.forEach { output.add("OUT: $it") }
            res.stderr.lines().filter { it.isNotBlank() }.forEach { errors.add("ERR: $it") }
            if (!res.success) {
                ok = false
                errors.add("Command exited with code ${res.exitCode}: $cmd")
                break   // do not run the rest of a batch after a failure
            }
        }
        return ExecutionResult(ok, output, errors)
    }
}

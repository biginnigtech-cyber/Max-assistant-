package com.example.executor

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import com.example.data.MaxCommandResponse
import com.example.engine.SmartEntityExtractor
import com.example.utils.ContactResolutionResult
import com.example.utils.ContactResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.URLEncoder

object IntentExecutionLayer {
    private const val TAG = "IntentExecutionLayer"

    data class ExecutionResult(
        val success: Boolean,
        val message: String,
        val details: List<String> = emptyList(),
        val spokenOverride: String? = null
    )

    /** "...and turn the volume up" said in the same sentence as a media command. */
    private suspend fun applyFollowupVolume(context: Context, params: Map<String, String>, logs: MutableList<String>) {
        val raw = params["followup_volume"]?.trim()?.lowercase().orEmpty()
        if (raw.isEmpty() || raw == "none" || raw == "null") return
        val pct = raw.removeSuffix("%").toIntOrNull()
        val res = when {
            pct != null -> com.example.engine.DeviceController.setVolume(context, "set", pct)
            raw.contains("max") || raw.contains("full") -> com.example.engine.DeviceController.setVolume(context, "max")
            raw.contains("mute") -> com.example.engine.DeviceController.setVolume(context, "mute")
            raw.contains("down") || raw.contains("low") -> com.example.engine.DeviceController.setVolume(context, "down")
            else -> com.example.engine.DeviceController.setVolume(context, "up")
        }
        logs.add("Follow-up volume: ${res.message}")
    }

    private suspend fun runUiControl(context: Context, params: Map<String, String>, intentName: String, logs: MutableList<String>): String? {
        val action = (params["action"] ?: intentName).lowercase().replace(" ", "_")
        val times = (params["count"]?.toIntOrNull() ?: 1).coerceIn(1, 10)

        // Rooted phone: scroll, swipe, back, home and taps by text go straight through root. No accessibility needed.
        if (com.example.engine.RootCommandEngine.isRootAvailable()) {
            val viaRoot = com.example.engine.RootUi.perform(action, params, times)
            if (viaRoot != null) {
                logs.add("UI control (root) '$action' -> $viaRoot")
                return if (viaRoot) null else "यह स्क्रीन पर नहीं हो पाया, कुछ दिखा नहीं या टैप नहीं हुआ।"
            }
        }
        val a11y = com.example.engine.AccessibilityBootstrap.ensure(context)
            ?: return com.example.engine.AccessibilityBootstrap.NOT_RUNNING_MESSAGE
        var ok = false
        when {
            action.contains("scroll") || action.contains("swipe_up") || action.contains("swipe_down") -> {
                val backward = action.contains("scroll_up") || action.contains("swipe_down")
                repeat(times) {
                    ok = a11y.scrollScreen(forward = !backward)
                    delay(450L)
                }
            }
            action.contains("swipe_left") || action.contains("next") -> ok = a11y.swipeScreen("left")
            action.contains("swipe_right") || action.contains("previous") -> ok = a11y.swipeScreen("right")
            action.contains("tap_nth") || action.contains("tap_first") || action.contains("tap_item") || action.contains("click_nth") -> {
                val idx = params["index"]?.toIntOrNull() ?: 1
                ok = a11y.tapNth(idx)
            }
            action.contains("tap") || action.contains("click") -> {
                val text = params["text"] ?: params["target"] ?: ""
                ok = if (text.isNotBlank()) a11y.tapByText(text) else false
            }
            action.contains("back") -> ok = a11y.pressBack()
            action.contains("home") -> ok = a11y.pressHome()
            action.contains("recent") -> ok = a11y.openRecents()
            action.contains("notification") -> ok = a11y.openNotificationShade()
        }
        logs.add("UI control '$action' -> $ok")
        return if (ok) null else "यह स्क्रीन पर नहीं हो पाया, कुछ दिखा नहीं या टैप नहीं हुआ।"
    }

    suspend fun execute(context: Context, response: MaxCommandResponse): ExecutionResult = withContext(Dispatchers.IO) {
        val intentName = response.intent.trim().uppercase()
        val targetApp = response.target_app.trim()
        val targetModule = response.module.trim().uppercase()
        val capability = response.capability.trim().lowercase()
        val params = response.parameters
        val shellCommands = response.shell_commands
        val logs = mutableListOf<String>()
        var spokenOverrideResult: String? = null

        Log.d(TAG, "Executing Intent Action: '$intentName', Module: '$targetModule', Cap: '$capability', TargetApp: '$targetApp', Params: $params")

        // 0. CHAT GATE — ABSOLUTE RULE: CHAT MUST NEVER TRIGGER MEDIA OR APPS
        val isChatIntent = intentName == "CHAT" || intentName.contains("CONVERSATION") || 
            intentName.contains("GREETING") || intentName.contains("QUESTION") || 
            intentName == "EMPTY QUERY" || intentName == "EXCEPTION" || intentName == "ERROR" || 
            intentName == "RATELIMIT" || intentName.isBlank()
        val isChatModule = targetModule == "CHAT" || capability == "chat.general" || capability.startsWith("chat.")
        if (isChatIntent || isChatModule) {
            Log.d("CHAT_GATE", "Chat intent recognized ('$intentName', module='$targetModule', cap='$capability'). Bypassing all media and app execution.")
            return@withContext ExecutionResult(
                success = true,
                message = "Conversational response processed",
                details = listOf("Chat gate: conversational response"),
                spokenOverride = null
            )
        }

        // Resolve contact name to phone number if applicable
        val rawContact = params["contact"] ?: params["name"]
        val contactName = if (!rawContact.isNullOrBlank()) SmartEntityExtractor.sanitizeContact(rawContact) else null

        val contactResolution = if (!contactName.isNullOrBlank()) {
            ContactResolver.resolveSmart(context, contactName)
        } else null

        if (contactResolution is ContactResolutionResult.MultipleMatches) {
            val names = contactResolution.matches.take(3).joinToString(", ") { it.name }
            return@withContext ExecutionResult(
                success = true,
                message = "Multiple contacts found for $contactName",
                details = listOf("Multiple contacts found: $names"),
                spokenOverride = "$contactName नाम के एक से ज़्यादा कॉन्टैक्ट्स मिल रहे हैं: $names। किस वाले $contactName को मैसेज भेजूँ?"
            )
        }

        val resolvedPhone = when (contactResolution) {
            is ContactResolutionResult.SingleMatch -> contactResolution.contact.phoneNumber
            else -> params["phone"] ?: params["phone_number"] ?: contactName?.let { ContactResolver.getPhoneNumber(context, it) }
        }

        var actionExecuted = false

        // 1. WHATSAPP / MESSAGING / SMS ACTION
        val readOnlyMessageIntent = Regex("READ|LIST|CHECK|NOTIF|SUMMAR|UNREAD|COUNT|SHOW|SEARCH").containsMatchIn(intentName)
        if (!readOnlyMessageIntent && (intentName.contains("WHATSAPP") || targetApp.contains("whatsapp") || intentName.contains("SMS") || intentName.contains("MESSAGE") || intentName.contains("TELEGRAM") || intentName.contains("MESSENGER"))) {
            val message = params["message"] ?: params["text"] ?: ""
            val phoneClean = resolvedPhone?.replace(Regex("[^0-9+]"), "") ?: ""
            // Never invent a recipient: a bare "message" must ask who, not open WhatsApp and claim success.
            if (contactName.isNullOrBlank() && phoneClean.isBlank()) {
                logs.add("Messaging blocked: no recipient understood")
                return@withContext ExecutionResult(
                    success = true,
                    message = "Missing recipient",
                    details = logs,
                    spokenOverride = "किसे मैसेज भेजना है, और क्या लिखना है? नाम और बात दोनों बताइए।"
                )
            }
            val targetName = contactName ?: phoneClean

            try {
                if (intentName.contains("SMS") && phoneClean.isNotBlank()) {
                    val smsUri = Uri.parse("smsto:$phoneClean")
                    val smsIntent = Intent(Intent.ACTION_SENDTO, smsUri).apply {
                        putExtra("sms_body", message)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(smsIntent)
                    logs.add("Opened SMS app to $contactName ($phoneClean) with message: $message")
                    actionExecuted = true

                    // Send via input tap or Enter
                    delay(1200L)
                    RootShellExecutor.executeCommands(listOf(
                        "input keyevent 66",
                        "input keyevent 22"
                    ))
                } else {
                    // Route through Phase 2 AppAutomationEngine
                    val appChoice = when {
                        intentName.contains("TELEGRAM") || targetApp.contains("telegram") -> "telegram"
                        intentName.contains("MESSENGER") || targetApp.contains("orca") -> "messenger"
                        intentName.contains("INSTAGRAM") || targetApp.contains("instagram") -> "instagram"
                        else -> "whatsapp"
                    }

                    val autoResult = com.example.engine.AppAutomationEngine.automateMessaging(
                        context = context,
                        targetApp = appChoice,
                        contactName = targetName,
                        messageText = message,
                        phoneNumber = resolvedPhone
                    )
                    logs.addAll(autoResult.details)
                    actionExecuted = autoResult.success
                    spokenOverrideResult = autoResult.spokenResponse
                }
            } catch (e: Exception) {
                Log.e(TAG, "Messaging action failed: ${e.message}", e)
                logs.add("Messaging action failed: ${e.message}")
            }
        }

        // 1.5 SPOTIFY / AUDIO PLAYBACK
        if (!actionExecuted && (intentName.contains("SPOTIFY") || targetApp.contains("spotify") || (intentName.contains("MUSIC") && !intentName.contains("YOUTUBE") && !targetApp.contains("youtube")))) {
            val query = params["query"] ?: params["song"] ?: params["search"] ?: ""
            try {
                val spotResult = com.example.engine.AudioPlaybackEngine.playTrack(context, query, "spotify")
                logs.add(spotResult.message)
                actionExecuted = spotResult.success
                spokenOverrideResult = if (spotResult.success) "$query स्पॉटिफाई पर चला दिया है।" else "स्पॉटिफाई पर गाना नहीं चल पाया।"
                if (spotResult.success) applyFollowupVolume(context, params, logs)
            } catch (e: Exception) {
                Log.e(TAG, "Spotify playback error: ${e.message}", e)
                logs.add("Spotify playback failed: ${e.message}")
            }
        }

        // 2. YOUTUBE PLAYBACK (Strict YouTube Safety Gate)
        // ABSOLUTE RULE: CHAT MUST NEVER TRIGGER MEDIA. QUERY != YOUTUBE.
        // A generic parameters["query"] MUST NEVER be sufficient to trigger YouTube.
        // YouTube execution is allowed ONLY when intent or capability explicitly represents a YouTube action,
        // and query is non-empty.
        val explicitYouTubeIntent = intentName in setOf(
            "YOUTUBE_PLAY", "PLAY_VIDEO", "PLAY_MUSIC_ON_YOUTUBE", "SEARCH_YOUTUBE",
            "OPEN_YOUTUBE_AND_SEARCH", "YOUTUBE", "PLAY_YOUTUBE"
        ) || (intentName.contains("YOUTUBE") && !intentName.contains("CHAT"))

        val explicitYouTubeCapability = capability == "media.youtube"
        val explicitYouTubeTarget = targetApp.lowercase().contains("youtube") &&
            (intentName.contains("PLAY") || intentName.contains("SEARCH") || intentName.contains("VIDEO") || intentName.contains("MEDIA"))

        val canTriggerYouTube = explicitYouTubeIntent || explicitYouTubeCapability || explicitYouTubeTarget

        if (!actionExecuted && canTriggerYouTube) {
            val query = params["query"] ?: params["search"] ?: params["song"] ?: params["video"] ?: ""
            if (query.isNotBlank()) {
                Log.d("YOUTUBE_GATE", "WHY_YOUTUBE_TRIGGERED: explicitYouTubeIntent=$explicitYouTubeIntent, explicitYouTubeCapability=$explicitYouTubeCapability, query='$query'")
                try {
                    val ytResult = com.example.engine.YouTubeAIEngine.playVideo(context, query)
                    logs.add("YouTube AI Engine: ${ytResult.message} [State: ${ytResult.state}]")
                    actionExecuted = ytResult.success
                    // The spoken answer is the REAL result, said only after the song is verified to play
                    spokenOverrideResult = ytResult.message
                    if (ytResult.success) applyFollowupVolume(context, params, logs)
                } catch (e: Exception) {
                    Log.e(TAG, "YouTube action failed: ${e.message}", e)
                    logs.add("YouTube action failed: ${e.message}")
                }
            } else {
                Log.d("YOUTUBE_GATE", "YOUTUBE_TRIGGER_BLOCKED: query is empty (intent='$intentName', cap='$capability')")
            }
        } else if (!actionExecuted && (params.containsKey("query") || targetApp.lowercase().contains("youtube"))) {
            Log.d("YOUTUBE_GATE", "YOUTUBE_TRIGGER_BLOCKED: Generic query/target without explicit YouTube intent/capability (intent='$intentName', cap='$capability', targetApp='$targetApp')")
        }

        // 2.2 UI CONTROL: scroll / tap / swipe / back / home in whatever app is open
        if (!actionExecuted && (capability == "ui.control" || targetModule == "UI_CONTROL" || intentName.startsWith("UI_"))) {
            val failText = runUiControl(context, params, intentName, logs)
            actionExecuted = true
            if (failText != null) spokenOverrideResult = failText
        }

        // 2.5 FILE SYSTEM AI ACTIONS (Phase 7)
        if (!actionExecuted && (intentName.contains("FILE") || intentName.contains("FOLDER") || intentName.contains("ZIP") || intentName.contains("ARCHIVE"))) {
            try {
                val action = params["action"]?.lowercase() ?: intentName.lowercase()
                val path = params["path"] ?: params["file"] ?: "/sdcard"
                val dest = params["dest"] ?: params["destination"] ?: ""
                val query = params["query"] ?: params["name"] ?: ""

                when {
                    action.contains("search") || action.contains("find") -> {
                        val results = com.example.engine.FileSystemEngine.searchFiles(query.ifBlank { path })
                        logs.add("Found ${results.size} matching files.")
                        spokenOverrideResult = if (results.isEmpty()) "इस नाम की कोई फ़ाइल नहीं मिली।"
                            else "${results.size} फ़ाइलें मिलीं। पहली ये हैं: " + results.take(3).joinToString(", ") { it.name } + "।"
                        actionExecuted = true
                    }
                    action.contains("move") -> {
                        val res = com.example.engine.FileSystemEngine.moveFile(path, dest)
                        logs.add(res.message)
                        spokenOverrideResult = res.spokenResponse
                        actionExecuted = res.success
                    }
                    action.contains("rename") -> {
                        val newName = params["new_name"] ?: dest
                        val res = com.example.engine.FileSystemEngine.renameFile(path, newName)
                        logs.add(res.message)
                        spokenOverrideResult = res.spokenResponse
                        actionExecuted = res.success
                    }
                    action.contains("copy") -> {
                        val res = com.example.engine.FileSystemEngine.copyFile(path, dest)
                        logs.add(res.message)
                        spokenOverrideResult = res.spokenResponse
                        actionExecuted = res.success
                    }
                    action.contains("delete") -> {
                        val res = com.example.engine.FileSystemEngine.deleteFile(path)
                        logs.add(res.message)
                        spokenOverrideResult = res.spokenResponse
                        actionExecuted = res.success
                    }
                    action.contains("zip") || action.contains("compress") -> {
                        val zipOut = if (dest.endsWith(".zip")) dest else "$path.zip"
                        val res = com.example.engine.FileSystemEngine.compressToZip(path, zipOut)
                        logs.add(res.message)
                        spokenOverrideResult = res.spokenResponse
                        actionExecuted = res.success
                    }
                    action.contains("unzip") || action.contains("extract") -> {
                        val extractDest = if (dest.isNotBlank()) dest else path.removeSuffix(".zip")
                        val res = com.example.engine.FileSystemEngine.extractZip(path, extractDest)
                        logs.add(res.message)
                        spokenOverrideResult = res.spokenResponse
                        actionExecuted = res.success
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "File system action error: ${e.message}")
                logs.add("File action error: ${e.message}")
            }
        }

        // 3. PHONE CALL ACTION
        if (!actionExecuted && (intentName.contains("CALL") || intentName.contains("DIAL"))) {
            try {
                val phoneToCall = resolvedPhone ?: contactName
                if (!phoneToCall.isNullOrBlank()) {
                    val cleanNum = phoneToCall.replace(Regex("[^0-9+]"), "")
                    val callUri = Uri.parse("tel:$cleanNum")
                    val callIntent = Intent(Intent.ACTION_CALL, callUri).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(callIntent)
                    logs.add("Initiated phone call to $contactName ($cleanNum).")
                    spokenOverrideResult = "${contactName ?: "इस नंबर"} को कॉल लगा रहा हूँ।"
                    actionExecuted = true
                }
            } catch (e: SecurityException) {
                // Fallback to Dial intent if call permission is restricted
                try {
                    val phoneToCall = resolvedPhone ?: contactName ?: ""
                    val cleanNum = phoneToCall.replace(Regex("[^0-9+]"), "")
                    val dialUri = Uri.parse("tel:$cleanNum")
                    val dialIntent = Intent(Intent.ACTION_DIAL, dialUri).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(dialIntent)
                    logs.add("Opened Phone Dialer for $phoneToCall.")
                    // Truthful: without the call permission only the dialer opens, the green button is the user's.
                    spokenOverrideResult = "डायलर में नंबर खोल दिया है, कॉल का बटन आप दबा दीजिए।"
                    actionExecuted = true
                } catch (ex: Exception) {
                    logs.add("Call/Dial fallback failed: ${ex.message}")
                }
            } catch (e: Exception) {
                logs.add("Call action failed: ${e.message}")
            }
        }

        // 4. INSTAGRAM SEARCH / OPEN ACTION
        if (!actionExecuted && (intentName.contains("INSTAGRAM") || targetApp.contains("instagram"))) {
            val query = params["query"] ?: params["search"] ?: ""
            try {
                if (query.isNotBlank()) {
                    val encodedQuery = URLEncoder.encode(query, "UTF-8")
                    val instaUri = Uri.parse("https://www.instagram.com/$encodedQuery")
                    val instaIntent = Intent(Intent.ACTION_VIEW, instaUri).apply {
                        setPackage("com.instagram.android")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(instaIntent)
                    logs.add("Navigated to Instagram profile/search for '$query'.")
                    actionExecuted = true
                } else {
                    val launchIntent = context.packageManager.getLaunchIntentForPackage("com.instagram.android")
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        logs.add("Opened Instagram app.")
                        actionExecuted = true
                    }
                }
            } catch (e: Exception) {
                logs.add("Instagram action failed: ${e.message}")
            }
        }

        // 5. GENERIC TARGET APP LAUNCH
        if (!actionExecuted && targetApp.isNotBlank()) {
            val isYouTubeApp = targetApp.lowercase().contains("youtube")
            val isExplicitAppLaunch = intentName.contains("OPEN_APP") || intentName.contains("LAUNCH") || intentName.contains("START")
            if (isYouTubeApp && !isExplicitAppLaunch) {
                Log.d("YOUTUBE_GATE", "YOUTUBE_TRIGGER_BLOCKED: Preventing unintentional YouTube launch via generic app fallback (intent='$intentName', targetApp='$targetApp')")
            } else {
                try {
                    val launchResult = com.example.engine.DeviceController.openApp(context, targetApp)
                    logs.add(launchResult.message)
                    actionExecuted = launchResult.success
                } catch (e: Exception) {
                    logs.add("App launch failed for $targetApp: ${e.message}")
                }
            }
        }

        // 6. EXECUTE ANY DIRECT SHELL COMMANDS RETURNED BY GEMINI
        var shellSuccess = true
        if (shellCommands.isNotEmpty()) {
            val interpolatedCommands = shellCommands.map { cmd ->
                var c = cmd
                if (!resolvedPhone.isNullOrBlank()) {
                    val safePhone = resolvedPhone.replace(Regex("[^0-9+]"), "")
                    c = c.replace("<phone>", safePhone).replace("{phone}", safePhone)
                }
                if (!contactName.isNullOrBlank()) {
                    // a contact name must never be able to inject shell syntax
                    val safeName = contactName.replace(Regex("[^\\p{L}\\p{M}\\p{N} ._+-]"), "")
                    c = c.replace("<contact>", safeName).replace("{contact}", safeName)
                }
                c
            }
            val shellResult = RootShellExecutor.executeCommands(interpolatedCommands)
            logs.addAll(shellResult.output)
            logs.addAll(shellResult.errors)
            shellSuccess = shellResult.success
            actionExecuted = true
            if (!shellResult.success && spokenOverrideResult == null) {
                spokenOverrideResult = "कमांड चली तो सही, पर उसमें गड़बड़ी आई। ब्योरा लॉग में है।"
            }
        }

        ExecutionResult(
            success = if (actionExecuted) (shellCommands.isEmpty() || shellSuccess) else true,
            message = if (actionExecuted) "Action completed" else "No matching intent action executed",
            details = logs,
            spokenOverride = spokenOverrideResult
        )
    }
}

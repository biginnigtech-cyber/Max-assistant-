package com.example.data

import android.content.Context

class MessageRepository(private val messageDao: MessageDao) {

    suspend fun saveMessage(role: String, content: String): Long {
        if (content.isBlank()) return -1L
        return messageDao.insertMessage(
            MessageEntity(
                role = role,
                content = content,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun getRecentHistory(limit: Int = 20): List<MessageEntity> {
        return messageDao.getRecentMessages(limit).reversed()
    }

    suspend fun clearHistory() {
        messageDao.clearHistory()
    }

    companion object {
        @Volatile
        private var INSTANCE: MessageRepository? = null

        fun getInstance(context: Context): MessageRepository {
            return INSTANCE ?: synchronized(this) {
                val db = MaxDatabase.getInstance(context)
                val instance = MessageRepository(db.messageDao())
                INSTANCE = instance
                instance
            }
        }
    }
}

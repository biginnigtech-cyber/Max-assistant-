package com.example.data

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class MaxCommandResponse(
    @Json(name = "intent") val intent: String = "",
    @Json(name = "goal") val goal: String = "",
    @Json(name = "module") val module: String = "", // "ROOT", "TERMUX", "KALI", "DEVICE", "NETWORK", "TASK_PLAN", "CHAT", "MESSAGING", "MEDIA", "TEMPORAL"
    @Json(name = "capability") val capability: String = "",
    @Json(name = "target_app") val target_app: String = "",
    @Json(name = "tool_name") val tool_name: String = "",
    @Json(name = "target") val target: String = "",
    @Json(name = "recipient") val recipient: String = "",
    @Json(name = "message_content") val message_content: String = "",
    @Json(name = "search_query") val search_query: String = "",
    @Json(name = "temporal_type") val temporal_type: String = "", // "CURRENT_TIME", "PAST_CONVERSATION_TIME", "ELAPSED_TIME", "DATE_QUERY", "FUTURE_TIME"
    @Json(name = "missing_information") val missing_information: String = "",
    @Json(name = "is_sensitive") val is_sensitive: Boolean = false,
    @Json(name = "requires_confirmation") val requires_confirmation: Boolean = false,
    @Json(name = "risk_level") val risk_level: String = "LOW", // "LOW", "MEDIUM", "HIGH"
    @Json(name = "expected_result") val expected_result: String = "",
    @Json(name = "verification") val verification: String = "",
    @Json(name = "parameters") val parameters: Map<String, String> = emptyMap(),
    @Json(name = "entities") val entities: Map<String, String> = emptyMap(),
    @Json(name = "shell_commands") val shell_commands: List<String> = emptyList(),
    @Json(name = "steps") val steps: List<String> = emptyList(),
    @Json(name = "addressed_to_max") val addressed_to_max: Boolean = true,
    @Json(name = "undo_hint") val undo_hint: String = "",
    @Json(name = "confidence") val confidence: Double = 1.0,
    @Json(name = "spoken_response") val spoken_response: String = ""
)

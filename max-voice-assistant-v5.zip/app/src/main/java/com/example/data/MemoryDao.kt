package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memory_items")
    suspend fun getAllMemoryItems(): List<MemoryItemEntity>

    @Query("SELECT * FROM memory_items")
    fun getAllMemoryItemsFlow(): Flow<List<MemoryItemEntity>>

    @Query("SELECT * FROM memory_items WHERE `key` = :key LIMIT 1")
    suspend fun getMemoryItem(key: String): MemoryItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setMemoryItem(item: MemoryItemEntity)

    @Query("DELETE FROM memory_items WHERE `key` = :key")
    suspend fun deleteMemoryItem(key: String)

    @Query("SELECT * FROM command_history ORDER BY usageCount DESC, timestamp DESC LIMIT :limit")
    suspend fun getFrequentCommands(limit: Int = 20): List<CommandHistoryEntity>

    @Query("SELECT * FROM command_history WHERE command = :command LIMIT 1")
    suspend fun findCommand(command: String): CommandHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateCommand(entry: CommandHistoryEntity)

    @Query("DELETE FROM command_history")
    suspend fun clearCommandHistory()

    @Query("SELECT * FROM contact_memory")
    suspend fun getAllContacts(): List<ContactMemoryEntity>

    @Query("SELECT * FROM contact_memory WHERE contactKey = :key LIMIT 1")
    suspend fun getContact(key: String): ContactMemoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateContact(contact: ContactMemoryEntity)

    @Query("DELETE FROM contact_memory WHERE contactKey = :key")
    suspend fun deleteContact(key: String)
}

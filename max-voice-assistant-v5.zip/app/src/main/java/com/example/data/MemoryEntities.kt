package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memory_items")
data class MemoryItemEntity(
    @PrimaryKey val key: String,
    val value: String,
    val category: String = "general",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "command_history")
data class CommandHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val command: String,
    val module: String, // "ROOT", "TERMUX", "KALI", "DEVICE", "NETWORK"
    val timestamp: Long = System.currentTimeMillis(),
    val exitCode: Int = 0,
    val usageCount: Int = 1
)

@Entity(tableName = "contact_memory")
data class ContactMemoryEntity(
    @PrimaryKey val contactKey: String, // normalized name or phone number
    val displayName: String,
    val relationType: String = "UNKNOWN", // "FAMILY", "WORK", "FRIENDS", "UNKNOWN"
    val notes: String = "",
    val interactionCount: Int = 1,
    val lastUpdated: Long = System.currentTimeMillis()
)


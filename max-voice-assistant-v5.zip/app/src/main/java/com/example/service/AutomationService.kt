package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import com.example.engine.Automations
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Runs one automation rule, then stops. Short-lived on purpose; the microphone service is not needed for it. */
class AutomationService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    companion object {
        private const val TAG = "AutomationService"
        private const val CHANNEL_ID = "MaxAutomationChannel"
        private const val NOTIFICATION_ID = 2001

        fun start(context: Context, ruleId: String, extra: String) {
            val i = Intent(context, AutomationService::class.java)
                .putExtra(Automations.EXTRA_RULE_ID, ruleId).putExtra(Automations.EXTRA_CONTEXT, extra)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i) else context.startService(i)
            } catch (e: Exception) {
                // Background start refused: run it in the app process instead, it still works while the process lives.
                Log.w(TAG, "Foreground start refused (${e.message}); running without the service")
                CoroutineScope(Dispatchers.IO).launch { Automations.fire(context.applicationContext, ruleId, extra) }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra(Automations.EXTRA_RULE_ID)
        val extra = intent?.getStringExtra(Automations.EXTRA_CONTEXT).orEmpty()
        if (!goForeground()) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        scope.launch {
            try {
                if (id != null) Automations.fire(applicationContext, id, extra)
            } catch (e: Exception) {
                Log.e(TAG, "Automation crashed: ${e.message}", e)
            } finally {
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    private fun goForeground(): Boolean {
        return try {
            val nm = getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "MAX automations", NotificationManager.IMPORTANCE_LOW))
            }
            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
            val notification = builder.setContentTitle("MAX automation").setContentText("काम चल रहा है…")
                .setSmallIcon(android.R.drawable.ic_popup_sync).build()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed: ${e.message}", e)
            false
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}

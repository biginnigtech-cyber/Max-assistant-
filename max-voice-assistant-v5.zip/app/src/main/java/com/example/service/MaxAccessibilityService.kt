package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.brain.ContextEngine
import kotlinx.coroutines.delay

/**
 * Phase 2 — MaxAccessibilityService
 *
 * Provides live AccessibilityNodeInfo hierarchy traversal, text injection,
 * and node clicking for automated workflows in WhatsApp, Messenger, Telegram, Instagram, etc.
 */
class MaxAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "MaxAccessibility"

        @Volatile
        var instance: MaxAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "MaxAccessibilityService Connected.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg.isNotBlank() && !pkg.contains("com.android.systemui")) {
            ContextEngine.getInstance(this).updateForegroundApp(pkg)
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "MaxAccessibilityService Interrupted.")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
        }
        Log.d(TAG, "MaxAccessibilityService Destroyed.")
    }

    /**
     * Finds nodes matching search text (case insensitive) in text or contentDescription.
     */
    fun findNodesByText(root: AccessibilityNodeInfo, text: String): List<AccessibilityNodeInfo> {
        val matches = mutableListOf<AccessibilityNodeInfo>()
        traverseAndCollect(root) { node ->
            val nodeText = node.text?.toString() ?: ""
            val nodeDesc = node.contentDescription?.toString() ?: ""
            if (nodeText.contains(text, ignoreCase = true) || nodeDesc.contains(text, ignoreCase = true)) {
                matches.add(node)
            }
        }
        return matches
    }

    /**
     * Finds an editable input node (EditText or node with ACTION_SET_TEXT).
     */
    fun findInputField(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        traverseAndCollect(root) { node ->
            if (found == null && (node.isEditable || node.className?.contains("EditText", ignoreCase = true) == true)) {
                found = node
            }
        }
        return found
    }

    /**
     * Finds Send button by common identifiers, content descriptions, or text across chat apps (WhatsApp, Telegram, SMS, etc.).
     */
    fun findSendButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var sendNode: AccessibilityNodeInfo? = null
        traverseAndCollect(root) { node ->
            if (sendNode != null) return@traverseAndCollect
            val desc = node.contentDescription?.toString()?.lowercase() ?: ""
            val text = node.text?.toString()?.lowercase() ?: ""
            val viewId = node.viewIdResourceName?.lowercase() ?: ""

            if (desc == "send" || desc == "भेजें" || desc.contains("send message") || desc.contains("send audio") ||
                text == "send" || text == "भेजें" ||
                viewId.endsWith(":id/send") || viewId.endsWith(":id/send_btn") ||
                viewId.endsWith(":id/conversation_send_button") || viewId.contains("send_button") ||
                viewId.endsWith(":id/send_button_container") || viewId.contains("entry_action")
            ) {
                sendNode = node
            }
        }
        return sendNode
    }

    /**
     * Finds an existing conversation item matching contactName in the conversation list screen.
     * Searches for visible conversation items on the chat list screen without needing search.
     */
    fun findExistingConversationItem(root: AccessibilityNodeInfo, contactName: String): AccessibilityNodeInfo? {
        if (contactName.isBlank()) return null
        val candidates = findNodesByText(root, contactName)
        for (node in candidates) {
            // Ensure this is not a search bar, action bar title, or input field
            if (node.isEditable) continue
            val viewId = node.viewIdResourceName?.lowercase() ?: ""
            if (viewId.contains("search") || viewId.contains("action_bar") || viewId.contains("toolbar")) continue

            // Check if node is clickable, or find its clickable parent in conversation list
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable) {
                    val pId = current.viewIdResourceName?.lowercase() ?: ""
                    if (!pId.contains("search") && !pId.contains("toolbar")) {
                        return current
                    }
                }
                current = current.parent
            }
        }
        return null
    }

    /**
     * Finds search affordance (search icon or search view) in WhatsApp and chat apps.
     */
    fun findSearchAffordance(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var searchNode: AccessibilityNodeInfo? = null
        traverseAndCollect(root) { node ->
            if (searchNode != null) return@traverseAndCollect
            val desc = node.contentDescription?.toString()?.lowercase() ?: ""
            val text = node.text?.toString()?.lowercase() ?: ""
            val viewId = node.viewIdResourceName?.lowercase() ?: ""

            if (desc == "search" || desc == "खोजें" || desc.contains("search…") || desc.contains("search...") ||
                text == "search" || text == "खोजें" ||
                viewId.endsWith(":id/menuitem_search") || viewId.endsWith(":id/search_button") ||
                viewId.endsWith(":id/search_holder") || viewId.contains("search_src_text")
            ) {
                searchNode = node
            }
        }
        return searchNode
    }

    /**
     * Traverses the node hierarchy recursively.
     */
    private fun traverseAndCollect(node: AccessibilityNodeInfo?, onVisit: (AccessibilityNodeInfo) -> Unit) {
        if (node == null) return
        onVisit(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                traverseAndCollect(child, onVisit)
            }
        }
    }

    /**
     * Injects text into an editable node via Accessibility ACTION_SET_TEXT.
     */
    fun setTextOnNode(node: AccessibilityNodeInfo, text: String): Boolean {
        val arguments = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    /**
     * Clicks a node or traverses to its clickable parent.
     */
    fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var target: AccessibilityNodeInfo? = node
        while (target != null && !target.isClickable) {
            target = target.parent
        }
        return target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    /**
     * Performs a programmatic gesture click at the center of a node.
     */
    fun gestureClickNode(node: AccessibilityNodeInfo): Boolean {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        if (rect.isEmpty) return false

        val x = rect.centerX().toFloat()
        val y = rect.centerY().toFloat()

        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        return dispatchGesture(gesture, null, null)
    }

    // ---------------------------------------------------------------
    // Generic screen control (works in every app)
    // ---------------------------------------------------------------

    private val AD_REGEX = Regex(
        "(?i)(^|[\\s·•|\\-:])(ad|ads|sponsored|promoted)([\\s·•|\\-:.]|$)|विज्ञापन|प्रायोजित|visit advertiser"
    )

    fun screenSize(): Pair<Int, Int> {
        val dm = resources.displayMetrics
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    fun findNodes(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        traverseAndCollect(root) { if (predicate(it)) out.add(it) }
        return out
    }

    fun anyNode(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): Boolean =
        findNodes(root, predicate).isNotEmpty()

    /** True if this node (or anything inside it) is marked as an advertisement / sponsored result. */
    fun isAdNode(node: AccessibilityNodeInfo, depth: Int = 0): Boolean {
        val t = node.text?.toString().orEmpty()
        val d = node.contentDescription?.toString().orEmpty()
        val id = node.viewIdResourceName?.lowercase().orEmpty()
        if (AD_REGEX.containsMatchIn(t) || AD_REGEX.containsMatchIn(d)) return true
        if (id.contains("ad_badge") || id.contains("sponsored") || id.contains("ad_headline") || id.contains(":id/ad_")) return true
        if (depth >= 6) return false
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            if (isAdNode(c, depth + 1)) return true
        }
        return false
    }

    /** Big clickable cards (video results, posts, list rows), ordered from top to bottom of the screen. */
    fun collectContentItems(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val (w, h) = screenSize()
        val items = mutableListOf<Pair<Int, AccessibilityNodeInfo>>()
        val r = Rect()
        traverseAndCollect(root) { n ->
            if (n.isClickable && n.isVisibleToUser) {
                n.getBoundsInScreen(r)
                if (r.width() >= w * 0.45 && r.height() >= h * 0.07 && r.height() <= h * 0.7 && r.top >= 0 && r.top < h) {
                    items.add(Pair(r.top, n))
                }
            }
        }
        return items.sortedBy { it.first }.map { it.second }
    }

    /** Taps the n-th (1-based) real content item on screen, skipping ads. */
    fun tapNth(n: Int): Boolean {
        val root = rootInActiveWindow ?: return false
        val items = collectContentItems(root).filter { !isAdNode(it) }
        val target = items.getOrNull((n - 1).coerceAtLeast(0)) ?: return false
        return clickNode(target) || gestureClickNode(target)
    }

    /** Taps the first visible element whose text or description contains the given text. */
    fun tapByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodesByText(root, text).firstOrNull { it.isVisibleToUser && !it.isEditable } ?: return false
        return clickNode(node) || gestureClickNode(node)
    }

    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openNotificationShade(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    /** direction = direction the FINGER moves: up, down, left, right. */
    fun swipeScreen(direction: String, durationMs: Long = 350L): Boolean {
        val (w, h) = screenSize()
        val cx = w / 2f
        val cy = h / 2f
        val path = Path()
        when (direction.lowercase()) {
            "up" -> { path.moveTo(cx, h * 0.75f); path.lineTo(cx, h * 0.30f) }
            "down" -> { path.moveTo(cx, h * 0.30f); path.lineTo(cx, h * 0.75f) }
            "left" -> { path.moveTo(w * 0.80f, cy); path.lineTo(w * 0.20f, cy) }
            "right" -> { path.moveTo(w * 0.20f, cy); path.lineTo(w * 0.80f, cy) }
            else -> return false
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /** forward = reveal more content (like scrolling down a feed). */
    fun scrollScreen(forward: Boolean): Boolean {
        val root = rootInActiveWindow
        if (root != null) {
            val node = findNodes(root) { it.isScrollable && it.isVisibleToUser }.maxByOrNull { n ->
                val rr = Rect()
                n.getBoundsInScreen(rr)
                rr.width().toLong() * rr.height().toLong()
            }
            if (node != null) {
                val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                if (node.performAction(action)) return true
            }
        }
        return swipeScreen(if (forward) "up" else "down")
    }

    /**
     * Rows in a chat / conversation list or search result list that match a contact name.
     * Returns (label shown on screen, clickable row). Distinct labels only.
     */
    fun findConversationMatches(root: AccessibilityNodeInfo, contact: String): List<Pair<String, AccessibilityNodeInfo>> {
        val out = mutableListOf<Pair<String, AccessibilityNodeInfo>>()
        val seen = mutableSetOf<String>()
        val c = contact.trim().lowercase()
        if (c.isEmpty()) return out
        traverseAndCollect(root) { node ->
            if (node.isEditable) return@traverseAndCollect
            val id = node.viewIdResourceName?.lowercase().orEmpty()
            if (id.contains("search") || id.contains("toolbar") || id.contains("action_bar")) return@traverseAndCollect
            val label = node.text?.toString().orEmpty().trim()
            if (label.isEmpty() || label.length > c.length + 25) return@traverseAndCollect
            if (!label.lowercase().contains(c)) return@traverseAndCollect
            var cur: AccessibilityNodeInfo? = node
            var row: AccessibilityNodeInfo? = null
            while (cur != null) {
                if (cur.isClickable) { row = cur; break }
                cur = cur.parent
            }
            if (row != null && seen.add(label.lowercase())) out.add(Pair(label, row))
        }
        return out
    }
}

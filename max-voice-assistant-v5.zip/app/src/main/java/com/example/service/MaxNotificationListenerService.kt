package com.example.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.brain.MemoryManager
import com.example.engine.Automations
import com.example.brain.NotificationCategory
import com.example.brain.NotificationClassifier
import com.example.brain.PrivacyLevel
import com.example.brain.ReplyManager
import com.example.brain.ReplySessionState
import com.example.tts.TTSManager
import com.example.utils.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

class MaxNotificationListenerService : NotificationListenerService() {

    companion object {
        private const val TAG = "MaxNotifListener"
        private val lastAnnouncedMap = ConcurrentHashMap<String, Long>()
        private const val THROTTLE_WINDOW_MS = 6000L
        private const val CALL_THROTTLE_WINDOW_MS = 20000L

        private val DIALER_HINTS = listOf("dialer", "incallui", "telecom", "contacts", "phone")
        private val ONGOING_CALL_WORDS = Regex(
            "ongoing|in progress|on hold|call ended|call in progress|चालू कॉल|कॉल जारी|जारी कॉल|होल्ड",
            RegexOption.IGNORE_CASE
        )

        @Volatile
        var isConnected: Boolean = false
            private set

        fun isNotificationListenerEnabled(context: Context): Boolean {
            val packageName = context.packageName
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
            if (!flat.isNullOrEmpty()) {
                val names = flat.split(":")
                for (name in names) {
                    val componentName = ComponentName.unflattenFromString(name)
                    if (componentName != null && componentName.packageName == packageName) {
                        return true
                    }
                }
            }
            return false
        }

        fun checkAndPromptPermission(context: Context) {
            if (!isNotificationListenerEnabled(context)) {
                Log.w(TAG, "Notification Listener permission missing. Opening Notification Access settings.")
                MaxVoiceService.logMessage("Notification Listener: Permission missing. Opening Settings...")
                try {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to open Notification Access settings", e)
                }
            }
        }

        fun requestRebindIfDisconnected(context: Context) {
            if (!isConnected && isNotificationListenerEnabled(context)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    try {
                        Log.d(TAG, "Requesting rebind for NotificationListenerService...")
                        requestRebind(ComponentName(context, MaxNotificationListenerService::class.java))
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to request rebind", e)
                    }
                }
            }
        }
    }

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "MaxNotificationListenerService created.")
        TTSManager.getInstance(applicationContext)
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        isConnected = true
        Log.d(TAG, "MaxNotificationListenerService connected successfully.")
        MaxVoiceService.logMessage("Notification Listener: Connected successfully")
        TTSManager.getInstance(applicationContext)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        isConnected = false
        Log.w(TAG, "MaxNotificationListenerService disconnected.")
        MaxVoiceService.logMessage("Notification Listener: Disconnected")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                requestRebind(ComponentName(applicationContext, MaxNotificationListenerService::class.java))
            } catch (e: Exception) {
                Log.e(TAG, "Failed to request rebind on disconnect", e)
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val packageName = sbn.packageName ?: return
        if (packageName == applicationContext.packageName) return

        val notification = sbn.notification ?: return
        val extras = notification.extras ?: return

        // Calls are the one thing that must never be missed. An incoming-call notification is flagged "ongoing"
        // by Android, so the old blanket `isOngoing` filter silently dropped every call.
        val isCall = isCallNotification(packageName, notification)
        if (sbn.isOngoing && !isCall) return
        if (!isCall && (notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim()
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim() ?: ""

        if (title.isBlank() && text.isBlank()) return

        if (isCall) {
            // A call that is already being talked on is not a new call.
            if (ONGOING_CALL_WORDS.containsMatchIn("$title $text")) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val type = extras.getInt("android.callType", 0)   // 1 incoming, 2 ongoing, 3 screening
                if (type == 2) return
            }
        }

        // Throttle duplicate notifications (a ringing call posts updates every second: one announcement is enough)
        val throttleKey = if (isCall) "CALL:$packageName:$title" else "$packageName:$title:$text"
        val currentTime = System.currentTimeMillis()
        val lastTime = lastAnnouncedMap[throttleKey] ?: 0L

        if (currentTime - lastTime < (if (isCall) CALL_THROTTLE_WINDOW_MS else THROTTLE_WINDOW_MS)) {
            return
        }
        lastAnnouncedMap[throttleKey] = currentTime

        // Clean up cache periodically
        if (lastAnnouncedMap.size > 80) {
            val iterator = lastAnnouncedMap.entries.iterator()
            while (iterator.hasNext()) {
                val entry = iterator.next()
                if (currentTime - entry.value > 60000L) {
                    iterator.remove()
                }
            }
        }

        val appName = getAppName(applicationContext, packageName)

        // User-made automations ("when Rahul calls, tell me...") see every notification and call, online or offline.
        try { Automations.onNotification(applicationContext, appName, title, text, isCall) } catch (e: Exception) { Log.w(TAG, "Automation hook failed: ${e.message}") }

        serviceScope.launch(Dispatchers.IO) {
            // ONLINE: the Gemini brain thinks about every notification. OFFLINE: only calls are spoken, with a short fixed line.
            val online = isOnline() && PreferencesManager.getApiKey(applicationContext).isNotBlank()
            if (online) {
                processNotificationSmartBrain(sbn, packageName, appName, title, text, isCall)
            } else {
                processNotificationOffline(packageName, appName, title, text, isCall)
            }
        }
    }

    private fun isCallNotification(packageName: String, notification: Notification): Boolean {
        if (notification.category == Notification.CATEGORY_CALL) return true
        val pkg = packageName.lowercase()
        return DIALER_HINTS.any { pkg.contains(it) } &&
            (pkg.contains("dialer") || pkg.contains("incallui") || pkg.contains("telecom") || pkg.endsWith(".phone"))
    }

    private fun isOnline(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps != null &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            false
        }
    }

    /** No internet (or no API key): stay quiet about everything except calls, and say only who is calling. */
    private suspend fun processNotificationOffline(
        packageName: String,
        appName: String,
        title: String,
        text: String,
        isCall: Boolean
    ) {
        try {
            com.example.brain.NotificationBrain.getInstance(applicationContext)
                .processIncomingNotification(packageName, appName, title, text)
        } catch (_: Exception) {}
        if (!isCall) {
            Log.d(TAG, "Offline: notification from $appName stored silently")
            return
        }
        val allowed = MemoryManager.getInstance(applicationContext).shouldAllowInGamingMode(
            isCall = true, isFamilyMessage = false, isOtp = false, isEmergency = false
        )
        if (!allowed) return
        val line = NotificationClassifier.getInstance(applicationContext).offlineCallAnnouncement(title, text)
        MaxVoiceService.logMessage("[Offline call] $line")
        TTSManager.getInstance(applicationContext).speakIndependent(line)
    }

    private suspend fun processNotificationSmartBrain(
        sbn: StatusBarNotification,
        packageName: String,
        appName: String,
        title: String,
        text: String,
        isCall: Boolean = false
    ) {
        val memoryManager = MemoryManager.getInstance(applicationContext)
        val classifier = NotificationClassifier.getInstance(applicationContext)
        val replyManager = ReplyManager.getInstance(applicationContext)

        // 1. CLASSIFY NOTIFICATION WITH GEMINI SMART BRAIN
        com.example.brain.NotificationBrain.getInstance(applicationContext).processIncomingNotification(
            packageName = packageName,
            appName = appName,
            title = title,
            text = text
        )

        val result = classifier.classifyNotification(
            packageName = packageName,
            appName = appName,
            title = title,
            text = text,
            isCallHint = isCall
        )

        Log.d(TAG, "Classified notification: [${result.category}] [${result.privacyLevel}] app=$appName, sender=${result.sender}")
        MaxVoiceService.logMessage("[Notif ${result.category}] ${result.sender} ($appName): ${result.summary}")

        // 2. CHECK GAMING MODE / DND FILTER
        val isFamily = (result.privacyLevel == PrivacyLevel.FAMILY)
        val isOtp = result.isOtpOrBank
        val isEmergency = result.priority.equals("HIGH", ignoreCase = true)

        val allowedInGamingMode = memoryManager.shouldAllowInGamingMode(
            isCall = isCall,
            isFamilyMessage = isFamily,
            isOtp = isOtp,
            isEmergency = isEmergency
        )

        if (!allowedInGamingMode) {
            Log.d(TAG, "Notification silenced due to active Gaming Mode: $appName")
            MaxVoiceService.logMessage("Gaming Mode: Silenced notification from $appName")
            return
        }

        if (!result.shouldSpeak) {
            Log.d(TAG, "Notification is silent or promo/spam. Stored silently.")
            return
        }

        // 3. EXTRACT INLINE REMOTE INPUT REPLY ACTION IF AVAILABLE
        val replyAction = findDirectReplyAction(sbn.notification)

        // 4. PREPARE ACTIVE REPLY SESSION IF REQUISITE
        if (result.category == NotificationCategory.MESSAGE) {
            val sessionState = when {
                result.isOtpOrBank -> ReplySessionState.AWAITING_OTP_READ_DECISION
                result.isPrivateMessage -> ReplySessionState.AWAITING_PRIVATE_DECISION
                result.replyPossible -> ReplySessionState.AWAITING_REPLY_DECISION
                else -> ReplySessionState.IDLE
            }

            if (sessionState != ReplySessionState.IDLE) {
                replyManager.registerActiveReplySession(
                    appName = appName,
                    packageName = packageName,
                    senderName = result.sender,
                    messageText = text.ifBlank { title },
                    state = sessionState,
                    directReplyAction = replyAction
                )
            }
        }

        // 5. ANNOUNCE WITH MATURE MAX VOICE (TTS)
        val tts = TTSManager.getInstance(applicationContext)
        val announcement = result.announcement

        if (com.example.BuildConfig.DEBUG) Log.d(TAG, "Speaking announcement: \"$announcement\"")
        MaxVoiceService.logMessage("Speaking: \"$announcement\"")
        // speakIndependent keeps the notification voice away from the callbacks of the voice service.
        tts.speakIndependent(announcement) {
            // If a decision / reply is needed from user, trigger active listening window
            if (result.category == NotificationCategory.MESSAGE &&
                (result.replyPossible || result.isPrivateMessage || result.isOtpOrBank)
            ) {
                MaxVoiceService.startVoiceReplyWindow(
                    context = applicationContext,
                    appName = appName,
                    packageName = packageName,
                    senderName = result.sender,
                    notificationText = text
                )
            }
        }
    }

    private fun findDirectReplyAction(notification: Notification): Notification.Action? {
        val actions = notification.actions ?: return null
        for (action in actions) {
            val remoteInputs = action.remoteInputs
            if (remoteInputs != null && remoteInputs.isNotEmpty()) {
                return action
            }
        }
        return null
    }

    private fun getAppName(context: Context, packageName: String): String {
        return try {
            val pm = context.packageManager
            val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            when {
                packageName.contains("whatsapp", ignoreCase = true) -> "WhatsApp"
                packageName.contains("telegram", ignoreCase = true) -> "Telegram"
                packageName.contains("messaging", ignoreCase = true) -> "Messages"
                packageName.contains("instagram", ignoreCase = true) -> "Instagram"
                packageName.contains("facebook", ignoreCase = true) -> "Facebook"
                packageName.contains("youtube", ignoreCase = true) -> "YouTube"
                packageName.contains("chrome", ignoreCase = true) -> "Chrome"
                packageName.contains("vending", ignoreCase = true) -> "Play Store"
                packageName.contains("spotify", ignoreCase = true) -> "Spotify"
                else -> "Application"
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }
}

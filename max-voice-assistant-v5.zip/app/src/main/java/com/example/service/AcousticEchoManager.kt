package com.example.service

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioRecord
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.util.Log
import com.example.engine.YouTubeAIEngine
import kotlin.math.roundToInt

/**
 * Acoustic Echo Cancellation (AEC), Noise Suppression (NS), Automatic Gain Control (AGC),
 * Non-blocking Audio Ducking (AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK), and intelligent
 * Background YouTube & Self-Echo Detection for MAX Voice Assistant.
 */
object AcousticEchoManager {
    private const val TAG = "AcousticEchoManager"

    // Set of interrupt keywords for instant barge-in
    private val INTERRUPT_KEYWORDS = setOf(
        "stop", "wait", "pause", "quiet", "cancel", "hold", "shutup", "shut up",
        "रुको", "रुक", "रुक जाओ", "सुनो", "चुप", "शांत", "बस", "बस करो", "बंद करो",
        "मैक्स रुको", "रुको मैक्स", "मैक्स सुनो", "ठहरो", "मत करो", "रहने दो"
    )

    // Wake word prefixes for direct addressing during conversation (ordered by length descending)
    private val WAKE_WORDS = listOf(
        "wake up max", "hello max", "hey maks", "hey max", "listen max",
        "ok max", "hi max", "yo max", "oye max",
        "सुनो मैक्स", "max सुनो", "उठो मैक्स", "हे मैक्स", "हेय मैक्स", "ओ मैक्स", "अरे मैक्स",
        "मैक्स", "max"
    )

    // Active Audio Effects references to prevent garbage collection
    private var activeAec: AcousticEchoCanceler? = null
    private var activeNs: NoiseSuppressor? = null
    private var activeAgc: AutomaticGainControl? = null
    private var currentAudioSessionId: Int = -1

    // Audio Ducking State
    @Volatile
    var isDucked: Boolean = false
        private set

    @Volatile
    private var savedMediaVolume: Int = -1

    @Volatile
    private var isHardwareAecActive: Boolean = false

    private var activeAudioFocusRequest: Any? = null

    fun isAecAvailable(): Boolean = AcousticEchoCanceler.isAvailable()
    fun isNoiseSuppressorAvailable(): Boolean = NoiseSuppressor.isAvailable()
    fun isAgcAvailable(): Boolean = AutomaticGainControl.isAvailable()

    /**
     * Applies Hardware/Software Audio Effects on a specific audio session ID.
     */
    fun applyAudioEffects(audioSessionId: Int): Triple<AcousticEchoCanceler?, NoiseSuppressor?, AutomaticGainControl?> {
        if (audioSessionId <= 0) return Triple(null, null, null)
        currentAudioSessionId = audioSessionId

        Log.d("MAX_AUDIO_PIPELINE", "AUDIO_SESSION_ID: $audioSessionId")
        Log.d("MAX_AUDIO_PIPELINE", "AEC_AVAILABLE: ${isAecAvailable()}")
        Log.d("MAX_AUDIO_PIPELINE", "NS_AVAILABLE: ${isNoiseSuppressorAvailable()}")
        Log.d("MAX_AUDIO_PIPELINE", "AGC_AVAILABLE: ${isAgcAvailable()}")

        try {
            if (isAecAvailable()) {
                activeAec?.release()
                activeAec = AcousticEchoCanceler.create(audioSessionId)?.apply {
                    enabled = true
                    Log.d(TAG, "AcousticEchoCanceler enabled on session $audioSessionId")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to enable AEC: ${e.message}")
        }
        Log.d("MAX_AUDIO_PIPELINE", "AEC_ENABLED: ${activeAec?.enabled ?: false}")

        try {
            if (isNoiseSuppressorAvailable()) {
                activeNs?.release()
                activeNs = NoiseSuppressor.create(audioSessionId)?.apply {
                    enabled = true
                    Log.d(TAG, "NoiseSuppressor enabled on session $audioSessionId")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to enable NoiseSuppressor: ${e.message}")
        }
        Log.d("MAX_AUDIO_PIPELINE", "NS_ENABLED: ${activeNs?.enabled ?: false}")

        try {
            if (isAgcAvailable()) {
                activeAgc?.release()
                activeAgc = AutomaticGainControl.create(audioSessionId)?.apply {
                    enabled = true
                    Log.d(TAG, "AutomaticGainControl enabled on session $audioSessionId")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to enable AGC: ${e.message}")
        }
        Log.d("MAX_AUDIO_PIPELINE", "AGC_ENABLED: ${activeAgc?.enabled ?: false}")

        return Triple(activeAec, activeNs, activeAgc)
    }

    /**
     * Attaches AcousticEchoCanceler directly to an active AudioRecord stream if available.
     */
    fun attachAecToAudioRecord(audioRecord: AudioRecord): AcousticEchoCanceler? {
        return try {
            if (isAecAvailable()) {
                val aec = AcousticEchoCanceler.create(audioRecord.audioSessionId)?.apply {
                    enabled = true
                    Log.d(TAG, "AcousticEchoCanceler attached to AudioRecord session ${audioRecord.audioSessionId}")
                }
                activeAec = aec
                aec
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to attach AcousticEchoCanceler to AudioRecord: ${e.message}")
            null
        }
    }

    /**
     * Releases active audio effects cleanly.
     */
    fun releaseAudioEffects() {
        try {
            activeAec?.release()
            activeNs?.release()
            activeAgc?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing audio effects: ${e.message}")
        } finally {
            activeAec = null
            activeNs = null
            activeAgc = null
            currentAudioSessionId = -1
        }
    }

    /**
     * Activates Android hardware Acoustic Echo Cancellation by routing audio HAL to MODE_IN_COMMUNICATION.
     * When routing through built-in speaker (no headset/Bluetooth), explicitly configures speakerphone
     * communication routing so the hardware DSP applies the high-attenuation speaker echo cancellation filter.
     */
    fun enableHardwareAec(context: Context) {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (!isHardwareAecActive || audioManager.mode != AudioManager.MODE_IN_COMMUNICATION) {
                audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                isHardwareAecActive = true

                // Check if wired headset or Bluetooth audio is active
                val isHeadsetOrBt = try {
                    @Suppress("DEPRECATION")
                    audioManager.isWiredHeadsetOn || audioManager.isBluetoothA2dpOn || audioManager.isBluetoothScoOn
                } catch (_: Exception) {
                    false
                }

                val routeDescription = if (isHeadsetOrBt) "HEADSET_OR_BT" else "SPEAKERPHONE"

                // If on built-in speaker, set speaker communication device to activate speaker AEC profile
                if (!isHeadsetOrBt) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        try {
                            val speakerDevice = audioManager.availableCommunicationDevices.firstOrNull {
                                it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                            }
                            if (speakerDevice != null) {
                                audioManager.setCommunicationDevice(speakerDevice)
                            }
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to setCommunicationDevice for speaker: ${e.message}")
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        try {
                            if (!audioManager.isSpeakerphoneOn) {
                                audioManager.isSpeakerphoneOn = true
                            }
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to set isSpeakerphoneOn: ${e.message}")
                        }
                    }
                }
                Log.d("MAX_AUDIO_PIPELINE", "AUDIO_MODE: ${audioManager.mode} (MODE_IN_COMMUNICATION)")
                Log.d("MAX_AUDIO_PIPELINE", "AUDIO_ROUTE: $routeDescription")
                Log.d("MAX_AUDIO_PIPELINE", "AEC_AVAILABLE: ${isAecAvailable()}")
                Log.d("MAX_AUDIO_PIPELINE", "NS_AVAILABLE: ${isNoiseSuppressorAvailable()}")
                Log.d(TAG, "Hardware AEC enabled via AudioManager.MODE_IN_COMMUNICATION (headset: $isHeadsetOrBt)")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to enable hardware AEC: ${e.message}")
        }
    }

    /**
     * Restores Android audio mode to normal and clears communication device routing cleanly.
     */
    fun disableHardwareAec(context: Context) {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (isHardwareAecActive) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    try {
                        audioManager.clearCommunicationDevice()
                    } catch (_: Exception) {}
                } else {
                    @Suppress("DEPRECATION")
                    try {
                        audioManager.isSpeakerphoneOn = false
                    } catch (_: Exception) {}
                }
                audioManager.mode = AudioManager.MODE_NORMAL
                isHardwareAecActive = false
                Log.d(TAG, "Hardware AEC disabled (restored AudioManager.MODE_NORMAL)")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to disable hardware AEC: ${e.message}")
        }
    }

    /**
     * Requests Non-blocking Audio Focus with AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK.
     * YouTube and other media applications are instructed to DUCK (lower volume), NOT pause.
     */
    // MAX must never lower the music: the song keeps its full volume while the mic is open
    // and while MAX talks. (The old code set the system music volume to 25% and then
    // restored an old value, which also undid the user's "volume up".)
    private const val KEEP_MEDIA_VOLUME_UNTOUCHED = true

    fun requestDuckedAudioFocus(
        audioManager: AudioManager,
        onFocusChange: (Int) -> Unit = {}
    ): Any? {
        if (KEEP_MEDIA_VOLUME_UNTOUCHED) return null
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()

                val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(audioAttributes)
                    .setAcceptsDelayedFocusGain(true)
                    .setWillPauseWhenDucked(false) // Non-blocking: YouTube playback does not stop or pause
                    .setOnAudioFocusChangeListener { change ->
                        Log.d(TAG, "Audio focus change: $change")
                        onFocusChange(change)
                    }
                    .build()

                activeAudioFocusRequest = focusRequest
                val res = audioManager.requestAudioFocus(focusRequest)
                Log.d(TAG, "Requested ducked audio focus (Android O+), result: $res")
                focusRequest
            } else {
                @Suppress("DEPRECATION")
                val res = audioManager.requestAudioFocus(
                    { change -> onFocusChange(change) },
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
                Log.d(TAG, "Requested ducked audio focus (legacy), result: $res")
                "LEGACY_DUCKED_FOCUS"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting ducked audio focus: ${e.message}", e)
            null
        }
    }

    /**
     * Abandons audio focus cleanly.
     */
    fun abandonDuckedAudioFocus(audioManager: AudioManager, focusRequest: Any? = null) {
        try {
            val req = focusRequest ?: activeAudioFocusRequest
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                (req as? AudioFocusRequest)?.let {
                    audioManager.abandonAudioFocusRequest(it)
                }
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(null)
            }
            activeAudioFocusRequest = null
            Log.d(TAG, "Ducked audio focus abandoned cleanly.")
        } catch (e: Exception) {
            Log.e(TAG, "Error abandoning ducked audio focus: ${e.message}")
        }
    }

    /**
     * Smoothly lowers media stream volume (e.g. YouTube playback) to 20-30% while Max listens.
     */
    @Synchronized
    fun duckAudio(context: Context, targetPercent: Float = 0.25f) {
        if (KEEP_MEDIA_VOLUME_UNTOUCHED) return
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)

            if (!isDucked) {
                savedMediaVolume = currentVol
            }

            // Target 20-30% volume (default 25%)
            val duckedVol = (maxVol * targetPercent.coerceIn(0.20f, 0.30f)).roundToInt().coerceIn(1, maxVol)

            if (currentVol > duckedVol) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, duckedVol, 0)
                Log.d(TAG, "Audio ducked: volume $currentVol -> $duckedVol (max $maxVol)")
            }
            isDucked = true
        } catch (e: Exception) {
            Log.w(TAG, "Failed to duck audio: ${e.message}")
        }
    }

    /**
     * Restores media stream volume back to 100% (the saved user level) after processing.
     */
    @Synchronized
    fun unduckAudio(context: Context) {
        try {
            if (!isDucked) return
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

            if (savedMediaVolume >= 0) {
                val restoreVol = savedMediaVolume.coerceIn(0, maxVol)
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, restoreVol, 0)
                Log.d(TAG, "Audio unducked: volume restored to $restoreVol (max $maxVol)")
            }
            isDucked = false
            savedMediaVolume = -1
        } catch (e: Exception) {
            Log.w(TAG, "Failed to unduck audio: ${e.message}")
            isDucked = false
        }
    }

    /**
     * Determines whether recognized speech is an echo of currently playing YouTube media.
     * Prevents Max from processing its own playing audio as user input.
     */
    fun isMediaEcho(recognizedText: String): Boolean {
        val cleanRec = cleanText(recognizedText)
        if (cleanRec.isBlank()) return true

        val isYouTubePlaying = YouTubeAIEngine.isPlaying()
        val ytQuery = cleanText(YouTubeAIEngine.getCurrentPlayingQuery())

        if (isYouTubePlaying && ytQuery.isNotBlank()) {
            if (cleanRec.length >= 6 && (ytQuery.contains(cleanRec) || (ytQuery.length >= 6 && cleanRec.contains(ytQuery)))) {
                Log.d(TAG, "YouTube media echo detected via substring match: '$cleanRec' inside '$ytQuery'")
                return true
            }

            val recTokens = cleanRec.split(Regex("\\s+")).filter { it.length > 1 }.toSet()
            val ytTokens = ytQuery.split(Regex("\\s+")).filter { it.length > 1 }.toSet()
            if (recTokens.isNotEmpty()) {
                val intersection = recTokens.count { it in ytTokens }
                val ratio = intersection.toDouble() / recTokens.size.toDouble()
                if (ratio >= 0.4) {
                    Log.d(TAG, "YouTube media echo detected via token overlap (${(ratio * 100).toInt()}%): '$cleanRec'")
                    return true
                }
            }
        }

        return false
    }

    /**
     * Normalizes Devanagari characters into canonical phonetic Latin representations.
     * This provides universal script-invariant phonetic comparison so that echo cancellation
     * reliably detects when the microphone transcribes Hindi TTS output phonetically
     * in Roman or Devanagari characters, without altering language or microphone behavior.
     */
    fun toPhonetic(text: String): String {
        if (text.isBlank()) return ""
        val sb = StringBuilder()
        for (ch in text) {
            val mapped = when (ch) {
                'क' -> "k"; 'ख' -> "kh"; 'ग' -> "g"; 'घ' -> "gh"; 'ङ' -> "ng"
                'च' -> "ch"; 'छ' -> "chh"; 'ज' -> "j"; 'झ' -> "jh"; 'ञ' -> "ny"
                'ट' -> "t"; 'ठ' -> "th"; 'ड' -> "d"; 'ढ' -> "dh"; 'ण' -> "n"
                'त' -> "t"; 'थ' -> "th"; 'द' -> "d"; 'ध' -> "dh"; 'न' -> "n"
                'प' -> "p"; 'फ' -> "ph"; 'ब' -> "b"; 'भ' -> "bh"; 'म' -> "m"
                'य' -> "y"; 'र' -> "r"; 'ल' -> "l"; 'व' -> "v"; 'श' -> "sh"; 'ष' -> "sh"; 'स' -> "s"; 'ह' -> "h"
                'ा' -> "a"; 'ि' -> "i"; 'ी' -> "ee"; 'ु' -> "u"; 'ू' -> "oo"; 'े' -> "e"; 'ै' -> "ai"; 'ो' -> "o"; 'ौ' -> "au"
                'अ' -> "a"; 'आ' -> "aa"; 'इ' -> "i"; 'ई' -> "ee"; 'उ' -> "u"; 'ऊ' -> "oo"; 'ए' -> "e"; 'ऐ' -> "ai"; 'ओ' -> "o"; 'औ' -> "au"
                'ऋ' -> "ri"; 'ं' -> "n"; 'ः' -> "h"; 'ँ' -> "n"; '्' -> ""
                else -> ch.toString()
            }
            sb.append(mapped)
        }
        return sb.toString().lowercase().replace(Regex("[^a-z0-9\\s]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    /**
     * Unified check: Tests both TTS self-echo and background YouTube playback echo.
     */
    fun isSelfOrMediaEcho(
        recognizedText: String,
        lastTtsText: String,
        ttsEndTimeMillis: Long,
        isCurrentlySpeakingTts: Boolean
    ): Boolean {
        if (isSelfEcho(recognizedText, lastTtsText, ttsEndTimeMillis, isCurrentlySpeakingTts)) {
            return true
        }
        if (isMediaEcho(recognizedText)) {
            return true
        }
        return false
    }

    /**
     * Determines whether the recognized speech is an echo of the AI's own TTS output.
     * Prevents the infinite loop where the microphone hears the phone's own speaker.
     */
    fun isSelfEcho(
        recognizedText: String,
        lastTtsText: String,
        ttsEndTimeMillis: Long,
        isCurrentlySpeakingTts: Boolean
    ): Boolean {
        val cleanRec = cleanText(recognizedText)
        val cleanTts = cleanText(lastTtsText)

        if (cleanRec.isBlank()) return true
        if (cleanTts.isBlank()) return false

        // If TTS is currently speaking, or completed very recently (< 1500ms cooldown)
        val timeSinceTts = System.currentTimeMillis() - ttsEndTimeMillis
        if (!isCurrentlySpeakingTts && timeSinceTts > 1500L) {
            return false
        }

        // 1. Direct substring check
        // A short "हाँ" / "नहीं" / "रुको" said right after MAX finished is the user answering, not an echo of MAX's own words.
        if (cleanRec.length >= 6 && (cleanTts.contains(cleanRec) || (cleanTts.length >= 6 && cleanRec.contains(cleanTts)))) {
            Log.d("SELF_ECHO_REJECTED", "Self-echo rejected via substring match: '$cleanRec' inside '$cleanTts'")
            return true
        }

        // 2. Token overlap check (Word-level similarity)
        val recTokens = cleanRec.split(Regex("\\s+")).filter { it.length > 1 }.toSet()
        val ttsTokens = cleanTts.split(Regex("\\s+")).filter { it.length > 1 }.toSet()

        if (recTokens.isNotEmpty()) {
            val intersectionCount = recTokens.count { it in ttsTokens }
            val overlapRatio = intersectionCount.toDouble() / recTokens.size.toDouble()

            if (overlapRatio >= 0.30) {
                Log.d("SELF_ECHO_REJECTED", "Self-echo rejected via token overlap (${(overlapRatio * 100).toInt()}%): '$cleanRec'")
                return true
            }
        }

        // 3. Phonetic comparison (bridges Devanagari & Latin transliterations)
        val phoneticRec = toPhonetic(recognizedText)
        val phoneticTts = toPhonetic(lastTtsText)

        if (phoneticRec.isNotBlank() && phoneticTts.isNotBlank()) {
            if (phoneticTts.contains(phoneticRec) || phoneticRec.contains(phoneticTts)) {
                Log.d("SELF_ECHO_REJECTED", "Self-echo rejected via phonetic substring: '$phoneticRec' inside '$phoneticTts'")
                return true
            }

            val pRecTokens = phoneticRec.split(Regex("\\s+")).filter { it.length > 1 }.toSet()
            val pTtsTokens = phoneticTts.split(Regex("\\s+")).filter { it.length > 1 }.toSet()
            if (pRecTokens.isNotEmpty()) {
                val pIntersection = pRecTokens.count { it in pTtsTokens }
                val pRatio = pIntersection.toDouble() / pRecTokens.size.toDouble()
                if (pRatio >= 0.30) {
                    Log.d("SELF_ECHO_REJECTED", "Self-echo rejected via phonetic overlap (${(pRatio * 100).toInt()}%): '$phoneticRec'")
                    return true
                }
            }
        }

        return false
    }

    data class WakeDetectionResult(
        val hasWakeWord: Boolean,
        val command: String
    )

    /**
     * Unifies wake word detection and command extraction into a single atomic check.
     * Prevents split handling of "Hey Max" + command into two separate actions.
     */
    fun detectAndExtractWake(spokenText: String): WakeDetectionResult {
        val clean = cleanText(spokenText)
        for (w in WAKE_WORDS) {
            if (clean.startsWith(w)) {
                val remaining = clean.removePrefix(w)
                    .replace(Regex("^[,\\s.:;!?-]+"), "")
                    .trim()
                return WakeDetectionResult(hasWakeWord = true, command = remaining)
            }
        }
        return WakeDetectionResult(hasWakeWord = false, command = clean)
    }

    /**
     * Determines if a spoken phrase is a deliberate user barge-in / interrupt command
     * while the AI is speaking.
     */
    fun isUserInterruptCommand(spokenText: String): Boolean {
        val clean = cleanText(spokenText)
        val words = clean.split(Regex("\\s+"))
        return INTERRUPT_KEYWORDS.any { clean.contains(it) } || words.any { it in INTERRUPT_KEYWORDS }
    }

    /**
     * Checks if a phrase is explicitly addressed to Max (wake word prefix).
     */
    fun isWakeCommand(spokenText: String): Boolean {
        val clean = cleanText(spokenText)
        return WAKE_WORDS.any { clean.startsWith(it) }
    }

    /**
     * Extracts user command following a wake word prefix.
     */
    fun extractCommandFromWake(spokenText: String): String {
        var clean = cleanText(spokenText)
        for (w in WAKE_WORDS) {
            if (clean.startsWith(w)) {
                clean = clean.removePrefix(w).trim()
                break
            }
        }
        return clean
    }

    /**
     * Determines whether speech detected during TTS playback is a genuine user barge-in (interruption)
     * vs. acoustic echo from the speaker.
     */
    fun isLikelyUserInterruption(
        detectedText: String,
        currentTtsText: String,
        ttsStartTimeMillis: Long,
        isCurrentlySpeakingTts: Boolean
    ): Boolean {
        val clean = cleanText(detectedText)
        if (clean.isBlank()) return false

        // 1. Explicit interrupt command always triggers barge-in
        if (isUserInterruptCommand(clean)) {
            Log.d(TAG, "User interruption triggered by keyword: '$clean'")
            return true
        }

        // 2. Explicit address to Max (wake word) always triggers barge-in
        if (isWakeCommand(clean)) {
            Log.d(TAG, "User interruption triggered by wake prefix: '$clean'")
            return true
        }

        // 3. If TTS is not speaking, this is regular input, not barge-in
        if (!isCurrentlySpeakingTts) {
            return false
        }

        // 4. Initial grace period of 350ms to allow audio output and AEC to stabilize
        val durationSinceTtsStart = System.currentTimeMillis() - ttsStartTimeMillis
        if (durationSinceTtsStart < 350L) {
            return false
        }

        // 5. Must NOT be an echo of current TTS output
        if (isSelfEcho(detectedText, currentTtsText, 0L, true)) {
            Log.d(TAG, "Interruption ignored: detected self-echo of TTS: '$clean'")
            return false
        }

        // 6. Must NOT be background YouTube echo
        if (isMediaEcho(detectedText)) {
            Log.d(TAG, "Interruption ignored: detected media echo: '$clean'")
            return false
        }

        // 7. For un-prefixed distinct speech during active TTS, allow 2+ words (e.g. "YouTube खोलो", "गाना बंद करो", "कॉल करो")
        // while strictly checking against self-echo and media echo
        val words = clean.split(Regex("\\s+")).filter { it.length > 1 }
        if (words.size >= 2 && clean.length >= 6) {
            val ttsTokens = cleanText(currentTtsText).split(Regex("\\s+")).filter { it.length > 1 }.toSet()
            val matchCount = words.count { it in ttsTokens }
            val overlap = matchCount.toDouble() / words.size.toDouble()
            if (overlap < 0.25) {
                Log.d(TAG, "User interruption triggered by substantive distinct speech: '$clean'")
                return true
            }
        }

        return false
    }

    /**
     * Extracts following user command after an interrupt keyword.
     * E.g. "MAX stop, open YouTube" -> "open YouTube"
     * "रुको, समय क्या हुआ है" -> "समय क्या हुआ है"
     */
    fun extractUserIntentFromInterrupt(spokenText: String): String {
        var clean = cleanText(spokenText)
        for (kw in INTERRUPT_KEYWORDS) {
            clean = clean.replace(Regex("\\b${Regex.escape(kw)}\\b", RegexOption.IGNORE_CASE), " ")
        }
        // Remove leading wake words
        clean = clean.replace(Regex("^(hey\\s+)?max\\b", RegexOption.IGNORE_CASE), " ")
        return clean.replace(Regex("\\s+"), " ").trim()
    }

    /**
     * Combines partial words captured during interruption with the final recognized transcript
     * without duplicating words.
     */
    fun combinePartialAndFinal(partial: String, finalResult: String): String {
        val p = partial.trim()
        val f = finalResult.trim()
        if (p.isBlank()) return f
        if (f.isBlank()) return p
        if (f.contains(p, ignoreCase = true)) return f
        if (p.contains(f, ignoreCase = true)) return p

        val pWords = p.split(Regex("\\s+"))
        val fWords = f.split(Regex("\\s+"))
        val combined = (pWords + fWords).distinct().joinToString(" ")
        return combined
    }

    private fun cleanText(text: String): String {
        return text.lowercase()
            .replace(Regex("[.,!?:;\"'\\-–—_]"), " ")
            .trim()
    }
}

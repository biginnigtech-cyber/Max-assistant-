# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile

# --- MAX: JSON models and reflection users (safe to keep even while minify is off) ---
-keep class com.example.data.** { *; }
-keep class com.example.ai.Gemini* { *; }
-keepclassmembers class com.example.** { @com.squareup.moshi.* <methods>; @com.squareup.moshi.* <fields>; }
-keep @com.squareup.moshi.JsonClass class * { *; }
-keep class kotlin.Metadata { *; }
-dontwarn org.slf4j.**

# MAX Voice Assistant (v5)

Rooted-Android voice assistant: Hindi / Hinglish speech in, Gemini decides, root does the work, Gemini words the answer.

Build: open in Android Studio (or give the whole project to your builder) and run `./gradlew assembleRelease`.
Optional companion: `MAX-Assistant-Magisk-Module.zip` (separate file) starts MAX at boot and grants everything.

Layout (one place for each job, no duplicate pipelines)
- `service/`   MaxVoiceService (listening, speaking state), MaxNotificationListenerService, MaxAccessibilityService (optional), AutomationService
- `brain/`     VoiceIntentRouter (the single path: speech -> Gemini -> action -> Gemini-written reply), TaskPlanner (confirmations), Notification*, Memory*, Reply*
- `ai/`        GeminiBrain (prompt, streaming, one-shot helper, reply composer)
- `engine/`    CoreActions (alarm/timer/clock), DeviceController, RootCommandEngine (the only root shell), RootUi + ScreenReader + ScreenAgent (screen),
               CameraCapture, Automations, RootSetup, AccessibilityBootstrap, YouTubeAIEngine, AudioPlaybackEngine, AppAutomationEngine, FileSystemEngine
- `executor/`  IntentExecutionLayer (executes Gemini's intents), RootShellExecutor (thin wrapper over RootCommandEngine)
- `tts/`       TTSManager (+ VoiceStyle: the deep voice), CloudVoice (optional Gemini voice)
- `CHANGES.md` everything that was found and fixed, in order.
